export type Role = "guest" | "merchant" | "supplier" | "admin";
export type Status = "pending" | "approved" | "rejected";
export type OrderStatus = "pending" | "approved" | "preparing" | "out_for_delivery" | "delivered" | "rejected";

export type Category = {
  id: string;
  nameEn: string;
  nameAr?: string;
};

export type Supplier = {
  id: string;
  companyName: string;
  phone: string;
  status: Status;
};

export type Merchant = {
  id: string;
  storeName: string;
  ownerName: string;
  phone: string;
  city: string;
  area: string;
  instagram?: string;
  status: Status;
};

export type Product = {
  id: string;
  supplierId: string;
  supplierName: string;
  categoryId: string;
  nameEn: string;
  nameAr: string;
  brand: string;
  imageUrl: string;
  wholesalePrice: number;
  availableQuantity: number;
  minimumOrderQuantity: number;
  deliveryEta: string;
  coverageAreas: string[];
  active: boolean;
};

export type CartLine = {
  productId: string;
  quantity: number;
};

export type OrderItem = {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
};

export type Order = {
  id: string;
  merchantId: string;
  merchantName: string;
  supplierId: string;
  supplierName: string;
  status: OrderStatus;
  items: OrderItem[];
  total: number;
  createdAt: string;
};

export type SessionUser = {
  role: Role;
  name: string;
  status: Status;
};
