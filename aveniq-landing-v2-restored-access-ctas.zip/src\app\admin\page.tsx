"use client";

import { Trash2 } from "lucide-react";
import { Badge, PageHeader, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { money, statusLabel } from "@/lib/utils";

export default function AdminPage() {
  const { user, merchants, suppliers, products, orders, updateApplication, removeProduct } = useMarketplace();

  if (user.role !== "admin") {
    return (
      <>
        <PageHeader eyebrow="Admin dashboard" title="Admin access is restricted." />
        <section className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
          <p className="rounded-2xl border border-rose/20 bg-mint p-5 font-medium shadow-sm">Platform administrators manage approvals, users, products, and orders.</p>
        </section>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="Admin dashboard" title="Approve users, manage products, and monitor every wholesale order." />
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6">
        <div className="grid gap-4 md:grid-cols-4">
          <Stat label="Merchants" value={merchants.length} />
          <Stat label="Suppliers" value={suppliers.length} />
          <Stat label="Products" value={products.length} />
          <Stat label="Orders" value={orders.length} />
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <Panel title="Merchant applications">
            {merchants.map((merchant) => (
              <div key={merchant.id} className="rounded-2xl border border-line bg-porcelain/50 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div><b>{merchant.storeName}</b><p className="text-sm text-ink/60">{merchant.ownerName} · {merchant.city}, {merchant.area} · {merchant.phone}</p></div>
                  <Badge tone={merchant.status === "approved" ? "good" : merchant.status === "rejected" ? "bad" : "warn"}>{statusLabel(merchant.status)}</Badge>
                </div>
                <div className="mt-3 flex gap-2">
                  <button className={secondaryButtonClass} onClick={() => updateApplication("merchant", merchant.id, "approved")}>Approve</button>
                  <button className={secondaryButtonClass} onClick={() => updateApplication("merchant", merchant.id, "rejected")}>Reject</button>
                </div>
              </div>
            ))}
          </Panel>
          <Panel title="Supplier applications">
            {suppliers.map((supplier) => (
              <div key={supplier.id} className="rounded-2xl border border-line bg-porcelain/50 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div><b>{supplier.companyName}</b><p className="text-sm text-ink/60">{supplier.phone}</p></div>
                  <Badge tone={supplier.status === "approved" ? "good" : supplier.status === "rejected" ? "bad" : "warn"}>{statusLabel(supplier.status)}</Badge>
                </div>
                <div className="mt-3 flex gap-2">
                  <button className={secondaryButtonClass} onClick={() => updateApplication("supplier", supplier.id, "approved")}>Approve</button>
                  <button className={secondaryButtonClass} onClick={() => updateApplication("supplier", supplier.id, "rejected")}>Reject</button>
                </div>
              </div>
            ))}
          </Panel>
        </div>
        <Panel title="Product management">
          {products.map((product) => (
            <div key={product.id} className="grid gap-3 rounded-2xl border border-line bg-porcelain/50 p-4 sm:grid-cols-[1fr_140px_44px]">
              <div><b>{product.nameEn}</b><p className="text-sm text-ink/60">{product.brand} · {product.supplierName} · {money(product.wholesalePrice)} · Stock {product.availableQuantity}</p></div>
              <Badge>{product.deliveryEta}</Badge>
              <button className={secondaryButtonClass + " px-2"} onClick={() => removeProduct(product.id)} aria-label="Remove product"><Trash2 className="size-4" /></button>
            </div>
          ))}
        </Panel>
        <Panel title="Order management">
          {orders.map((order) => (
            <div key={order.id} className="rounded-2xl border border-line bg-porcelain/50 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div><b>{order.id}</b><p className="text-sm text-ink/60">{order.merchantName} → {order.supplierName} · {money(order.total)}</p></div>
                <Badge tone={order.status === "delivered" ? "good" : order.status === "rejected" ? "bad" : "warn"}>{statusLabel(order.status)}</Badge>
              </div>
            </div>
          ))}
        </Panel>
      </section>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur"><p className="text-sm text-ink/55">{label}</p><p className="mt-1 text-3xl font-semibold">{value}</p></div>;
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="space-y-3 rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur"><h2 className="text-lg font-semibold">{title}</h2>{children}</div>;
}
