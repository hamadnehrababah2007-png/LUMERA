create type public.user_role as enum ('merchant', 'supplier', 'admin');
create type public.application_status as enum ('pending', 'approved', 'rejected');
create type public.order_status as enum ('pending', 'approved', 'preparing', 'out_for_delivery', 'delivered', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role user_role not null,
  display_name text not null,
  phone text,
  status application_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.merchants (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  store_name text not null,
  owner_name text not null,
  city text not null,
  area text not null,
  business_license_url text not null,
  commercial_registration_url text not null,
  instagram_page text,
  status application_status not null default 'pending'
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  company_name text not null,
  phone text not null,
  business_license_url text not null,
  commercial_registration_url text not null,
  status application_status not null default 'pending'
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name_en text not null,
  name_ar text,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid not null references public.suppliers(id) on delete cascade,
  category_id uuid not null references public.categories(id),
  name_en text not null,
  name_ar text,
  brand text not null,
  image_url text not null,
  wholesale_price numeric(10,2) not null,
  available_quantity integer not null,
  minimum_order_quantity integer not null,
  delivery_eta text not null,
  coverage_areas text[] not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  merchant_id uuid not null references public.merchants(id),
  supplier_id uuid not null references public.suppliers(id),
  status order_status not null default 'pending',
  total numeric(10,2) not null,
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null,
  unit_price numeric(10,2) not null
);

alter table public.profiles enable row level security;
alter table public.merchants enable row level security;
alter table public.suppliers enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "Profiles are readable by signed in users" on public.profiles for select to authenticated using (true);
create policy "Categories are readable by everyone" on public.categories for select using (true);
create policy "Products public preview" on public.products for select using (active = true);
create policy "Users manage own profile" on public.profiles for update using (auth.uid() = id);
