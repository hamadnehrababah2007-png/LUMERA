import Link from "next/link";
import { ArrowRight, BadgeCheck, BarChart3, LockKeyhole, Search, Truck, Zap } from "lucide-react";
import { buttonClass, secondaryButtonClass } from "@/components/ui";
import { AveniqBrand } from "@/components/brand";

const features = [
  ["Enterprise Security", "Protect commercial pricing, supplier data, and ordering workflows behind verified access.", LockKeyhole],
  ["Lightning Fast Search", "Search products, brands, suppliers, availability, and delivery coverage from one command center.", Search],
  ["Smart Wholesale Ordering", "Validate MOQs, group orders by supplier, and keep fulfillment moving with clear statuses.", Truck],
  ["Business Intelligence", "Give teams the visibility to manage users, suppliers, inventory, and order health.", BarChart3]
] as const;

export default function Home() {
  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_22%_18%,rgba(167,139,250,0.24),transparent_30%),radial-gradient(circle_at_78%_26%,rgba(79,70,229,0.18),transparent_32%),linear-gradient(120deg,rgba(124,58,237,0.14),transparent_34%,rgba(79,70,229,0.10)_70%,transparent)]" />
        <div className="relative mx-auto grid min-h-[84vh] max-w-7xl items-center gap-10 px-4 pb-16 pt-10 sm:px-6 lg:-mt-4 lg:grid-cols-[1.03fr_0.97fr] lg:pb-16 lg:pt-8">
          <div className="animate-rise flex flex-col justify-center">
            <AveniqBrand className="mb-10" />
            <p className="mb-4 inline-flex w-fit items-center rounded-full border border-line bg-panel/76 px-4 py-2 text-sm font-semibold text-rose shadow-sm backdrop-blur">
              <Zap className="mr-2 size-4" /> Intelligent B2B commerce
            </p>
            <h1 className="max-w-4xl text-5xl font-semibold tracking-normal text-ink sm:text-7xl">
              The Operating System for B2B Commerce
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-ink/70 sm:text-xl">
              Powering modern wholesale commerce through one intelligent platform built for trusted business relationships, secure supplier networks, and scalable growth.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/register/merchant" className={buttonClass}>Request Access <ArrowRight className="ml-2 size-4" /></Link>
              <Link href="/products" className={secondaryButtonClass}>Explore platform</Link>
              <Link href="/register/supplier" className={secondaryButtonClass}>Supplier access</Link>
            </div>
            <div className="mt-10 grid max-w-xl grid-cols-3 gap-3 text-sm">
              {[
                ["Verified", "network"],
                ["Real-time", "catalog"],
                ["Role-based", "control"]
              ].map(([value, label]) => (
                <div key={value} className="rounded-2xl border border-line bg-panel/70 p-4 shadow-sm backdrop-blur">
                  <p className="font-semibold text-ink">{value}</p>
                  <p className="mt-1 text-ink/55">{label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="animate-rise grid content-end gap-4 rounded-[2rem] border border-white/10 bg-[#11131f]/95 p-5 text-porcelain shadow-glow backdrop-blur" style={{ animationDelay: "120ms" }}>
            <div className="rounded-[1.5rem] border border-white/10 bg-[radial-gradient(circle_at_85%_0%,rgba(167,139,250,0.25),transparent_34%),linear-gradient(135deg,rgba(255,255,255,0.08),rgba(255,255,255,0.03))] p-5 text-porcelain shadow-soft">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-porcelain/60">Network volume</p>
                  <p className="mt-2 text-3xl font-semibold">JOD 248K</p>
                </div>
                <span className="grid size-11 place-items-center rounded-2xl border border-white/10 bg-rose/20">
                  <BadgeCheck className="size-6 text-apricot" />
                </span>
              </div>
              <div className="mt-6 grid grid-cols-6 items-end gap-2">
                {[42, 58, 36, 74, 66, 92].map((height, index) => (
                  <div key={height + index} className="rounded-full bg-white/10 p-1 ring-1 ring-white/10">
                    <div className="rounded-full bg-gradient-to-t from-rose via-moss to-apricot shadow-[0_0_18px_rgba(167,139,250,0.45)]" style={{ height }} />
                  </div>
                ))}
              </div>
            </div>
            {features.map(([title, text, Icon]) => (
              <div key={String(title)} className="group rounded-2xl border border-white/10 bg-white/[0.055] p-5 shadow-sm transition duration-300 hover:-translate-y-1.5 hover:border-apricot/45 hover:bg-white/[0.085] hover:shadow-glow">
                <span className="mb-3 grid size-10 place-items-center rounded-xl border border-white/10 bg-rose/15 text-apricot transition duration-300 group-hover:scale-105 group-hover:bg-rose/25">
                  <Icon className="size-5" />
                </span>
                <h2 className="font-semibold text-porcelain">{title}</h2>
                <p className="mt-2 text-sm leading-6 text-porcelain/70">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
