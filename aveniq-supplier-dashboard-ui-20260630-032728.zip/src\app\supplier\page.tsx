"use client";

import { useState } from "react";
import type { Dispatch, SetStateAction } from "react";
import { BarChart3, Boxes, CheckCircle2, Clock3, PackagePlus, Pencil, Plus, Save, ShieldCheck, Sparkles, Trash2, Truck, X } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Badge, EmptyState, PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { Category, Order, OrderStatus, Product } from "@/lib/types";
import { money, statusLabel } from "@/lib/utils";

const statusOptions: OrderStatus[] = ["approved", "preparing", "out_for_delivery", "delivered", "rejected"];
const workflowSteps: OrderStatus[] = ["pending", "approved", "preparing", "out_for_delivery", "delivered"];

const defaultDraft = {
  nameEn: "",
  nameAr: "",
  brand: "",
  imageUrl: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?q=80&w=1200&auto=format&fit=crop",
  categoryId: "skincare",
  wholesalePrice: 1,
  availableQuantity: 100,
  minimumOrderQuantity: 12,
  deliveryEta: "24 Hours",
  coverageAreas: "Amman, Irbid"
};

export default function SupplierPage() {
  const { user, products, categories, orders, addProduct, updateProduct, removeProduct, updateOrderStatus } = useMarketplace();
  const [draft, setDraft] = useState(defaultDraft);
  const [modalOpen, setModalOpen] = useState(false);
  const supplierProducts = products.filter((product) => product.supplierId === "s-1");
  const supplierOrders = orders.filter((order) => order.supplierId === "s-1");
  const activeOrders = supplierOrders.filter((order) => !["delivered", "rejected"].includes(order.status)).length;
  const pendingOrders = supplierOrders.filter((order) => order.status === "pending").length;
  const estimatedRevenue = supplierOrders.filter((order) => order.status !== "rejected").reduce((sum, order) => sum + order.total, 0);
  const coverageAreas = Array.from(new Set(supplierProducts.flatMap((product) => product.coverageAreas))).slice(0, 4);

  if (user.role !== "supplier" || user.status !== "approved") {
    return (
      <>
        <PageHeader eyebrow="Supplier dashboard" title="Supplier access requires approval." />
        <section className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
          <p className="rounded-2xl border border-rose/20 bg-mint p-5 font-medium shadow-sm">Only approved suppliers can create listings, update stock, and respond to orders.</p>
        </section>
      </>
    );
  }

  const handleCreateProduct = () => {
    addProduct({ ...draft, coverageAreas: draft.coverageAreas.split(",").map((area) => area.trim()).filter(Boolean) });
    setDraft((current) => ({ ...current, nameEn: "", nameAr: "", brand: "" }));
    setModalOpen(false);
  };

  return (
    <>
      <PageHeader eyebrow="Supplier dashboard" title="Command center for products, stock, and incoming wholesale orders.">
        <div className="flex flex-wrap gap-3">
          <button className={buttonClass + " gap-2"} onClick={() => setModalOpen(true)}><Plus className="size-4" />Add Product</button>
          <span className="inline-flex min-h-11 items-center rounded-2xl border border-line bg-panel/80 px-4 text-sm font-semibold text-ink/70">Live supplier workspace</span>
        </div>
      </PageHeader>
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <MetricCard icon={Boxes} label="Total Products" value={supplierProducts.length.toString()} helper="Live inventory listings" />
          <MetricCard icon={Truck} label="Active Orders" value={activeOrders.toString()} helper="Orders still in motion" />
          <MetricCard icon={Clock3} label="Pending Orders" value={pendingOrders.toString()} helper="Awaiting supplier action" />
          <MetricCard icon={BarChart3} label="Estimated Revenue / GMV" value={money(estimatedRevenue)} helper="Non-rejected order value" />
        </div>

        <div className="grid gap-6 xl:grid-cols-[340px_1fr]">
          <SupplierProfileCard supplierName={user.name} status={user.status} coverageAreas={coverageAreas} />
          <InventoryPanel products={supplierProducts} onSave={updateProduct} onRemove={removeProduct} onAdd={() => setModalOpen(true)} />
        </div>

        <OrdersPanel orders={supplierOrders} onUpdateStatus={updateOrderStatus} />
      </section>

      {modalOpen ? (
        <ProductModal
          draft={draft}
          categories={categories}
          setDraft={setDraft}
          onClose={() => setModalOpen(false)}
          onSubmit={handleCreateProduct}
        />
      ) : null}
    </>
  );
}

function MetricCard({ icon: Icon, label, value, helper }: { icon: LucideIcon; label: string; value: string; helper: string }) {
  return (
    <div className="group rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur transition duration-200 hover:-translate-y-1 hover:border-rose/35 hover:shadow-glow">
      <div className="flex items-start justify-between gap-4">
        <div className="rounded-2xl border border-line bg-porcelain/70 p-3 text-rose"><Icon className="size-5" /></div>
        <Sparkles className="size-4 text-ink/25 transition group-hover:text-rose" />
      </div>
      <p className="mt-5 text-sm font-medium text-ink/55">{label}</p>
      <p className="mt-1 text-3xl font-semibold tracking-normal text-ink">{value}</p>
      <p className="mt-2 text-sm text-ink/50">{helper}</p>
    </div>
  );
}

function SupplierProfileCard({ supplierName, status, coverageAreas }: { supplierName: string; status: string; coverageAreas: string[] }) {
  return (
    <aside className="h-fit rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-rose">Supplier profile</p>
          <h2 className="mt-2 text-2xl font-semibold">{supplierName}</h2>
        </div>
        <div className="rounded-2xl bg-rose/10 p-3 text-rose"><ShieldCheck className="size-5" /></div>
      </div>
      <div className="mt-5 space-y-4">
        <ProfileRow label="Verification Status"><Badge tone="good">{statusLabel(status)}</Badge></ProfileRow>
        <ProfileRow label="Verified Badge"><span className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700"><CheckCircle2 className="size-4" />Verified supplier</span></ProfileRow>
        <ProfileRow label="Coverage Areas">
          <div className="flex flex-wrap gap-2">
            {(coverageAreas.length ? coverageAreas : ["Amman", "Irbid"]).map((area) => <span key={area} className="rounded-full border border-line bg-porcelain px-3 py-1 text-xs font-semibold text-ink/65">{area}</span>)}
          </div>
        </ProfileRow>
        <ProfileRow label="Response Time"><span className="text-sm font-semibold text-ink">Under 2 hours</span></ProfileRow>
      </div>
    </aside>
  );
}

function ProfileRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-line bg-porcelain/50 p-4">
      <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-ink/45">{label}</p>
      {children}
    </div>
  );
}

function InventoryPanel({ products, onSave, onRemove, onAdd }: { products: Product[]; onSave: (product: Product) => void; onRemove: (id: string) => void; onAdd: () => void }) {
  return (
    <div className="rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-rose">Inventory</p>
          <h2 className="mt-1 text-2xl font-semibold">Product inventory</h2>
        </div>
        <button className={secondaryButtonClass + " gap-2"} onClick={onAdd}><PackagePlus className="size-4" />Add Product</button>
      </div>
      {products.length ? (
        <div className="mt-5 overflow-x-auto">
          <table className="w-full min-w-[860px] border-separate border-spacing-y-2 text-left text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-[0.14em] text-ink/45">
                <th className="px-3 py-2 font-semibold">Product Name</th>
                <th className="px-3 py-2 font-semibold">Price</th>
                <th className="px-3 py-2 font-semibold">Stock</th>
                <th className="px-3 py-2 font-semibold">MOQ</th>
                <th className="px-3 py-2 font-semibold">Delivery ETA</th>
                <th className="px-3 py-2 font-semibold">Status</th>
                <th className="px-3 py-2 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => <EditableProductRow key={product.id} product={product} onSave={onSave} onRemove={onRemove} />)}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="mt-5">
          <EmptyState title="No products yet">Create your first listing to make it available to verified merchants.</EmptyState>
        </div>
      )}
    </div>
  );
}

function EditableProductRow({ product, onSave, onRemove }: { product: Product; onSave: (product: Product) => void; onRemove: (id: string) => void }) {
  const [draft, setDraft] = useState(product);
  const [editing, setEditing] = useState(false);
  const fieldClass = inputClass + (!editing ? " pointer-events-none border-transparent bg-transparent px-0 shadow-none" : "");

  return (
    <tr className="group rounded-2xl bg-porcelain/50 shadow-sm transition hover:-translate-y-0.5 hover:bg-porcelain">
      <td className="rounded-l-2xl border-y border-l border-line px-3 py-3"><input className={fieldClass} value={draft.nameEn} onChange={(e) => setDraft({ ...draft, nameEn: e.target.value })} aria-label="Product name" /></td>
      <td className="border-y border-line px-3 py-3"><input className={fieldClass} type="number" step="0.01" value={draft.wholesalePrice} onChange={(e) => setDraft({ ...draft, wholesalePrice: Number(e.target.value) })} aria-label="Price" /></td>
      <td className="border-y border-line px-3 py-3"><input className={fieldClass} type="number" value={draft.availableQuantity} onChange={(e) => setDraft({ ...draft, availableQuantity: Number(e.target.value) })} aria-label="Stock" /></td>
      <td className="border-y border-line px-3 py-3"><input className={fieldClass} type="number" value={draft.minimumOrderQuantity} onChange={(e) => setDraft({ ...draft, minimumOrderQuantity: Number(e.target.value) })} aria-label="Minimum order quantity" /></td>
      <td className="border-y border-line px-3 py-3">
        {editing ? (
          <select className={inputClass} value={draft.deliveryEta} onChange={(e) => setDraft({ ...draft, deliveryEta: e.target.value })} aria-label="Delivery ETA">
            <option>Same Day</option><option>24 Hours</option><option>48 Hours</option><option>Custom ETA</option>
          </select>
        ) : <span className="font-medium text-ink/75">{draft.deliveryEta}</span>}
      </td>
      <td className="border-y border-line px-3 py-3"><Badge tone={draft.active ? "good" : "bad"}>{draft.active ? "Active" : "Inactive"}</Badge></td>
      <td className="rounded-r-2xl border-y border-r border-line px-3 py-3">
        <div className="flex gap-2">
          <button className={secondaryButtonClass + " min-h-10 px-3"} onClick={() => setEditing(true)} aria-label="Edit product"><Pencil className="size-4" /></button>
          <button className={secondaryButtonClass + " min-h-10 px-3"} onClick={() => { onSave(draft); setEditing(false); }} aria-label="Save product"><Save className="size-4" /></button>
          <button className={secondaryButtonClass + " min-h-10 px-3"} onClick={() => onRemove(product.id)} aria-label="Delete product"><Trash2 className="size-4" /></button>
        </div>
      </td>
    </tr>
  );
}

function OrdersPanel({ orders, onUpdateStatus }: { orders: Order[]; onUpdateStatus: (orderId: string, status: OrderStatus) => void }) {
  return (
    <div className="rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-rose">Orders</p>
          <h2 className="mt-1 text-2xl font-semibold">Incoming orders</h2>
        </div>
        <span className="rounded-full border border-line bg-porcelain px-3 py-1 text-sm font-semibold text-ink/65">{orders.length} total</span>
      </div>
      {orders.length ? (
        <div className="mt-5 grid gap-4">
          {orders.map((order) => (
            <article key={order.id} className="rounded-2xl border border-line bg-porcelain/50 p-4 shadow-sm transition hover:-translate-y-0.5 hover:bg-porcelain">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-ink/45">{order.id}</p>
                  <h3 className="mt-1 text-lg font-semibold">{order.merchantName}</h3>
                  <p className="mt-1 text-sm text-ink/55">Order Total: <span className="font-semibold text-ink">{money(order.total)}</span></p>
                </div>
                <Badge tone={order.status === "delivered" ? "good" : order.status === "rejected" ? "bad" : "warn"}>{statusLabel(order.status)}</Badge>
              </div>
              <Workflow status={order.status} />
              <div className="mt-4 flex flex-wrap gap-2">
                {statusOptions.map((status) => <button key={status} className={secondaryButtonClass + " min-h-10"} onClick={() => onUpdateStatus(order.id, status)}>{statusLabel(status)}</button>)}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-5">
          <EmptyState title="No incoming orders">New merchant orders will appear here with status controls and workflow progress.</EmptyState>
        </div>
      )}
    </div>
  );
}

function Workflow({ status }: { status: OrderStatus }) {
  const currentIndex = workflowSteps.indexOf(status);
  return (
    <div className="mt-4 grid gap-2 sm:grid-cols-5">
      {workflowSteps.map((step, index) => {
        const complete = currentIndex >= index && currentIndex !== -1;
        return (
          <div key={step} className="flex items-center gap-2 rounded-xl border border-line bg-panel/70 px-3 py-2">
            <span className={"size-2 rounded-full " + (complete ? "bg-rose shadow-glow" : "bg-ink/20")} />
            <span className={"text-xs font-semibold " + (complete ? "text-ink" : "text-ink/45")}>{statusLabel(step)}</span>
          </div>
        );
      })}
    </div>
  );
}

function ProductModal({
  draft,
  categories,
  setDraft,
  onClose,
  onSubmit
}: {
  draft: typeof defaultDraft;
  categories: Category[];
  setDraft: Dispatch<SetStateAction<typeof defaultDraft>>;
  onClose: () => void;
  onSubmit: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 px-4 py-6 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Create product listing">
      <form
        className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-line bg-panel p-5 shadow-glow"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <div className="flex items-start justify-between gap-4 border-b border-line pb-4">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.16em] text-rose">Create listing</p>
            <h2 className="mt-1 text-2xl font-semibold">Add product</h2>
          </div>
          <button type="button" className={secondaryButtonClass + " min-h-10 px-3"} onClick={onClose} aria-label="Close add product modal"><X className="size-4" /></button>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <input required className={inputClass} placeholder="Product Name" value={draft.nameEn} onChange={(e) => setDraft({ ...draft, nameEn: e.target.value })} />
          <input required className={inputClass} placeholder="Arabic Product Name" value={draft.nameAr} onChange={(e) => setDraft({ ...draft, nameAr: e.target.value })} />
          <input required className={inputClass} placeholder="Brand" value={draft.brand} onChange={(e) => setDraft({ ...draft, brand: e.target.value })} />
          <input required className={inputClass} placeholder="Product Image URL" value={draft.imageUrl} onChange={(e) => setDraft({ ...draft, imageUrl: e.target.value })} />
          <select className={inputClass} value={draft.categoryId} onChange={(e) => setDraft({ ...draft, categoryId: e.target.value })}>{categories.map((item) => <option key={item.id} value={item.id}>{item.nameEn}</option>)}</select>
          <input className={inputClass} type="number" step="0.01" placeholder="Wholesale Price" value={draft.wholesalePrice} onChange={(e) => setDraft({ ...draft, wholesalePrice: Number(e.target.value) })} />
          <input className={inputClass} type="number" placeholder="Available Quantity" value={draft.availableQuantity} onChange={(e) => setDraft({ ...draft, availableQuantity: Number(e.target.value) })} />
          <input className={inputClass} type="number" placeholder="Minimum Order Quantity" value={draft.minimumOrderQuantity} onChange={(e) => setDraft({ ...draft, minimumOrderQuantity: Number(e.target.value) })} />
          <select className={inputClass} value={draft.deliveryEta} onChange={(e) => setDraft({ ...draft, deliveryEta: e.target.value })}>
            <option>Same Day</option><option>24 Hours</option><option>48 Hours</option><option>Custom ETA</option>
          </select>
          <input className={inputClass} placeholder="Coverage Areas" value={draft.coverageAreas} onChange={(e) => setDraft({ ...draft, coverageAreas: e.target.value })} />
        </div>
        <div className="mt-5 flex flex-wrap justify-end gap-3">
          <button type="button" className={secondaryButtonClass} onClick={onClose}>Cancel</button>
          <button className={buttonClass + " gap-2"}><Plus className="size-4" />Add product</button>
        </div>
      </form>
    </div>
  );
}
