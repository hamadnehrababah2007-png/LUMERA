"use client";

import Link from "next/link";
import { Trash2 } from "lucide-react";
import { EmptyState, PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { money } from "@/lib/utils";
import { useState } from "react";

export default function CartPage() {
  const { user, cart, products, updateCart, removeFromCart, submitOrder } = useMarketplace();
  const [message, setMessage] = useState("");
  const lines = cart.map((line) => ({ ...line, product: products.find((product) => product.id === line.productId)! })).filter((line) => line.product);
  const total = lines.reduce((sum, line) => sum + line.quantity * line.product.wholesalePrice, 0);
  const locked = user.role !== "merchant" || user.status !== "approved";

  return (
    <>
      <PageHeader eyebrow="Cart" title="Build wholesale orders with MOQ and stock validation." />
      <section className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        {locked ? (
          <EmptyState title="Cart is available after approval">Wholesale prices are available only for verified cosmetics businesses.</EmptyState>
        ) : lines.length === 0 ? (
          <EmptyState title="Your cart is empty">Add products from the catalog to create supplier orders.</EmptyState>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
            <div className="space-y-3">
              {lines.map((line) => (
                <div key={line.productId} className="grid gap-3 rounded-md border border-ink/10 bg-white p-4 sm:grid-cols-[1fr_120px_40px]">
                  <div>
                    <h2 className="font-bold">{line.product.nameEn}</h2>
                    <p className="text-sm text-ink/60">{line.product.supplierName} · MOQ {line.product.minimumOrderQuantity} · Stock {line.product.availableQuantity}</p>
                    <p className="mt-1 text-sm font-semibold">{money(line.product.wholesalePrice)} each</p>
                  </div>
                  <input
                    className={inputClass}
                    type="number"
                    min={line.product.minimumOrderQuantity}
                    max={line.product.availableQuantity}
                    value={line.quantity}
                    onChange={(event) => setMessage(updateCart(line.productId, Number(event.target.value)) ?? "")}
                  />
                  <button className={secondaryButtonClass + " px-2"} aria-label="Remove item" onClick={() => removeFromCart(line.productId)}>
                    <Trash2 className="size-4" />
                  </button>
                </div>
              ))}
            </div>
            <aside className="h-fit rounded-md border border-ink/10 bg-white p-5">
              <p className="text-sm text-ink/60">Order total</p>
              <p className="mt-1 text-3xl font-bold">{money(total)}</p>
              {message ? <p className="mt-3 rounded bg-rose/10 p-3 text-sm text-rose">{message}</p> : null}
              <button className={buttonClass + " mt-5 w-full"} onClick={() => setMessage(submitOrder() ?? "Order submitted to supplier.")}>Submit order</button>
              <Link href="/orders" className={secondaryButtonClass + " mt-3 w-full"}>Track orders</Link>
            </aside>
          </div>
        )}
      </section>
    </>
  );
}
