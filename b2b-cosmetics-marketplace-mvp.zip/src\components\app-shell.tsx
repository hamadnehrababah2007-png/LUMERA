"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { PackageSearch, ShoppingCart, ClipboardList, ShieldCheck, Store, UserRoundCheck } from "lucide-react";
import { useMarketplace } from "@/lib/store";
import { cn, statusLabel } from "@/lib/utils";

const links = [
  { href: "/products", label: "Products", icon: PackageSearch },
  { href: "/cart", label: "Cart", icon: ShoppingCart },
  { href: "/orders", label: "Orders", icon: ClipboardList },
  { href: "/supplier", label: "Supplier", icon: Store },
  { href: "/admin", label: "Admin", icon: ShieldCheck }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, cart, loginAs } = useMarketplace();

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-ink/10 bg-porcelain/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <Link href="/" className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-md bg-ink text-sm font-black text-white">CM</span>
            <span>
              <span className="block text-base font-bold leading-tight">CosmoMarket Jordan</span>
              <span className="text-xs text-ink/60">Private wholesale cosmetics</span>
            </span>
          </Link>
          <nav className="flex max-w-full gap-1 overflow-x-auto rounded-md border border-ink/10 bg-white p-1">
            {links.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className={cn(
                  "flex min-h-10 items-center gap-2 rounded px-3 text-sm font-medium text-ink/70 transition hover:bg-mint/60 hover:text-ink",
                  pathname === href && "bg-ink text-white hover:bg-ink hover:text-white"
                )}
              >
                <Icon className="size-4" />
                <span>{label}</span>
                {href === "/cart" && cart.length > 0 ? (
                  <span className="rounded bg-rose px-1.5 text-xs text-white">{cart.length}</span>
                ) : null}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <div className="hidden rounded-md border border-ink/10 bg-white px-3 py-2 text-xs sm:block">
              <span className="font-semibold">{user.name}</span>
              <span className="ml-2 text-ink/55">{statusLabel(user.role)} · {statusLabel(user.status)}</span>
            </div>
            <select
              aria-label="Demo role"
              className="focus-ring rounded-md border border-ink/10 bg-white px-3 py-2 text-sm"
              value={`${user.role}:${user.status}`}
              onChange={(event) => {
                const [role, status] = event.target.value.split(":");
                loginAs(role as Parameters<typeof loginAs>[0], status as Parameters<typeof loginAs>[1]);
              }}
            >
              <option value="guest:pending">Guest preview</option>
              <option value="merchant:pending">Pending merchant</option>
              <option value="merchant:approved">Approved merchant</option>
              <option value="supplier:approved">Supplier</option>
              <option value="admin:approved">Admin</option>
            </select>
            <Link href="/register/merchant" className="focus-ring hidden rounded-md bg-rose px-4 py-2 text-sm font-semibold text-white sm:inline-flex">
              <UserRoundCheck className="mr-2 size-4" /> Apply
            </Link>
          </div>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}
