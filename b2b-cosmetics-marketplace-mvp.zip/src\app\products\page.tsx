"use client";

import { useMemo, useState } from "react";
import { Filter, Search } from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { inputClass, PageHeader } from "@/components/ui";
import { useMarketplace } from "@/lib/store";

export default function ProductsPage() {
  const { products, categories } = useMarketplace();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [availableOnly, setAvailableOnly] = useState(false);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return products.filter((product) => {
      const matchesQuery = !normalized || [product.nameEn, product.nameAr, product.brand].some((value) => value.toLowerCase().includes(normalized));
      const matchesCategory = category === "all" || product.categoryId === category;
      const matchesAvailability = !availableOnly || product.availableQuantity > 0;
      return product.active && matchesQuery && matchesCategory && matchesAvailability;
    });
  }, [availableOnly, category, products, query]);

  return (
    <>
      <PageHeader eyebrow="Marketplace catalog" title="Discover products, brands, suppliers, and delivery options." />
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="mb-6 grid gap-3 rounded-md border border-ink/10 bg-white p-4 md:grid-cols-[1fr_220px_auto]">
          <label className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink/45" />
            <input className={inputClass + " pl-10"} placeholder="Search by product name, Arabic name, or brand" value={query} onChange={(event) => setQuery(event.target.value)} />
          </label>
          <label className="relative">
            <Filter className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink/45" />
            <select className={inputClass + " pl-10"} value={category} onChange={(event) => setCategory(event.target.value)}>
              <option value="all">All categories</option>
              {categories.map((item) => <option key={item.id} value={item.id}>{item.nameEn}</option>)}
            </select>
          </label>
          <label className="flex min-h-10 items-center gap-2 rounded-md border border-ink/10 px-3 text-sm font-medium">
            <input type="checkbox" checked={availableOnly} onChange={(event) => setAvailableOnly(event.target.checked)} />
            Available only
          </label>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.map((product) => <ProductCard key={product.id} product={product} />)}
        </div>
      </section>
    </>
  );
}
