"use client";

import Image from "next/image";
import Link from "next/link";
import { ShoppingCart } from "lucide-react";
import { Badge, buttonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { Product } from "@/lib/types";
import { money } from "@/lib/utils";

export function ProductCard({ product }: { product: Product }) {
  const { user, addToCart } = useMarketplace();
  const verifiedMerchant = user.role === "merchant" && user.status === "approved";

  return (
    <article className="overflow-hidden rounded-md border border-ink/10 bg-white shadow-sm">
      <Link href={`/products/${product.id}`} className="block">
        <div className="relative aspect-[4/3] bg-mint">
          <Image src={product.imageUrl} alt={product.nameEn} fill className="object-cover" sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw" />
        </div>
      </Link>
      <div className="space-y-4 p-4">
        <div>
          <div className="mb-2 flex items-center justify-between gap-2">
            <Badge>{product.brand}</Badge>
            <span className="text-xs text-ink/55">{product.nameAr}</span>
          </div>
          <Link href={`/products/${product.id}`} className="text-lg font-bold leading-6 hover:text-rose">
            {product.nameEn}
          </Link>
          <p className="mt-1 text-sm text-ink/60">{product.supplierName}</p>
        </div>
        {verifiedMerchant ? (
          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="rounded bg-porcelain p-2"><b>{money(product.wholesalePrice)}</b><br />Wholesale</span>
            <span className="rounded bg-porcelain p-2"><b>{product.availableQuantity}</b><br />In stock</span>
            <span className="rounded bg-porcelain p-2"><b>{product.minimumOrderQuantity}</b><br />MOQ</span>
            <span className="rounded bg-porcelain p-2"><b>{product.deliveryEta}</b><br />Delivery</span>
          </div>
        ) : (
          <p className="rounded-md bg-apricot/20 p-3 text-sm font-medium text-amber-900">
            Wholesale prices are available only for verified cosmetics businesses.
          </p>
        )}
        {verifiedMerchant ? (
          <button className={buttonClass + " w-full"} onClick={() => addToCart(product.id, product.minimumOrderQuantity)}>
            <ShoppingCart className="mr-2 size-4" /> Add MOQ to cart
          </button>
        ) : null}
      </div>
    </article>
  );
}
