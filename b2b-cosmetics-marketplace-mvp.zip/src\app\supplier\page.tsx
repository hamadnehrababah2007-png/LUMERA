"use client";

import { useState } from "react";
import { Plus, Save, Trash2 } from "lucide-react";
import { Badge, PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { OrderStatus, Product } from "@/lib/types";
import { money, statusLabel } from "@/lib/utils";

const statusOptions: OrderStatus[] = ["approved", "preparing", "out_for_delivery", "delivered", "rejected"];

export default function SupplierPage() {
  const { user, products, categories, orders, addProduct, updateProduct, removeProduct, updateOrderStatus } = useMarketplace();
  const [draft, setDraft] = useState({
    nameEn: "",
    nameAr: "",
    brand: "",
    imageUrl: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?q=80&w=1200&auto=format&fit=crop",
    categoryId: "skincare",
    wholesalePrice: 1,
    availableQuantity: 100,
    minimumOrderQuantity: 12,
    deliveryEta: "24 Hours",
    coverageAreas: "Amman, Irbid"
  });
  const supplierProducts = products.filter((product) => product.supplierId === "s-1");
  const supplierOrders = orders.filter((order) => order.supplierId === "s-1");

  if (user.role !== "supplier" || user.status !== "approved") {
    return (
      <>
        <PageHeader eyebrow="Supplier dashboard" title="Supplier access requires approval." />
        <section className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
          <p className="rounded-md border border-apricot/40 bg-apricot/20 p-5 font-medium">Only approved suppliers can create listings, update stock, and respond to orders.</p>
        </section>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="Supplier dashboard" title="Manage products, pricing, stock, delivery, and incoming orders." />
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[380px_1fr]">
        <form
          className="h-fit rounded-md border border-ink/10 bg-white p-5"
          onSubmit={(event) => {
            event.preventDefault();
            addProduct({ ...draft, coverageAreas: draft.coverageAreas.split(",").map((area) => area.trim()).filter(Boolean) });
            setDraft((current) => ({ ...current, nameEn: "", nameAr: "", brand: "" }));
          }}
        >
          <h2 className="mb-4 text-lg font-bold">Create product listing</h2>
          <div className="grid gap-3">
            <input required className={inputClass} placeholder="Product Name" value={draft.nameEn} onChange={(e) => setDraft({ ...draft, nameEn: e.target.value })} />
            <input required className={inputClass} placeholder="Arabic Product Name" value={draft.nameAr} onChange={(e) => setDraft({ ...draft, nameAr: e.target.value })} />
            <input required className={inputClass} placeholder="Brand" value={draft.brand} onChange={(e) => setDraft({ ...draft, brand: e.target.value })} />
            <input required className={inputClass} placeholder="Product Image URL" value={draft.imageUrl} onChange={(e) => setDraft({ ...draft, imageUrl: e.target.value })} />
            <select className={inputClass} value={draft.categoryId} onChange={(e) => setDraft({ ...draft, categoryId: e.target.value })}>{categories.map((item) => <option key={item.id} value={item.id}>{item.nameEn}</option>)}</select>
            <input className={inputClass} type="number" step="0.01" placeholder="Wholesale Price" value={draft.wholesalePrice} onChange={(e) => setDraft({ ...draft, wholesalePrice: Number(e.target.value) })} />
            <input className={inputClass} type="number" placeholder="Available Quantity" value={draft.availableQuantity} onChange={(e) => setDraft({ ...draft, availableQuantity: Number(e.target.value) })} />
            <input className={inputClass} type="number" placeholder="Minimum Order Quantity" value={draft.minimumOrderQuantity} onChange={(e) => setDraft({ ...draft, minimumOrderQuantity: Number(e.target.value) })} />
            <select className={inputClass} value={draft.deliveryEta} onChange={(e) => setDraft({ ...draft, deliveryEta: e.target.value })}>
              <option>Same Day</option><option>24 Hours</option><option>48 Hours</option><option>Custom ETA</option>
            </select>
            <input className={inputClass} placeholder="Coverage Areas" value={draft.coverageAreas} onChange={(e) => setDraft({ ...draft, coverageAreas: e.target.value })} />
            <button className={buttonClass}><Plus className="mr-2 size-4" /> Add product</button>
          </div>
        </form>
        <div className="space-y-6">
          <div className="rounded-md border border-ink/10 bg-white p-5">
            <h2 className="mb-4 text-lg font-bold">Product inventory</h2>
            <div className="space-y-3">
              {supplierProducts.map((product) => <EditableProduct key={product.id} product={product} onSave={updateProduct} onRemove={removeProduct} />)}
            </div>
          </div>
          <div className="rounded-md border border-ink/10 bg-white p-5">
            <h2 className="mb-4 text-lg font-bold">Incoming orders</h2>
            <div className="space-y-3">
              {supplierOrders.map((order) => (
                <div key={order.id} className="rounded border border-ink/10 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div><b>{order.id}</b><p className="text-sm text-ink/60">{order.merchantName} · {money(order.total)}</p></div>
                    <Badge tone={order.status === "rejected" ? "bad" : "warn"}>{statusLabel(order.status)}</Badge>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {statusOptions.map((status) => <button key={status} className={secondaryButtonClass} onClick={() => updateOrderStatus(order.id, status)}>{statusLabel(status)}</button>)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function EditableProduct({ product, onSave, onRemove }: { product: Product; onSave: (product: Product) => void; onRemove: (id: string) => void }) {
  const [draft, setDraft] = useState(product);
  return (
    <div className="grid gap-2 rounded border border-ink/10 p-3 md:grid-cols-[1fr_100px_100px_90px]">
      <input className={inputClass} value={draft.nameEn} onChange={(e) => setDraft({ ...draft, nameEn: e.target.value })} />
      <input className={inputClass} type="number" value={draft.wholesalePrice} onChange={(e) => setDraft({ ...draft, wholesalePrice: Number(e.target.value) })} />
      <input className={inputClass} type="number" value={draft.availableQuantity} onChange={(e) => setDraft({ ...draft, availableQuantity: Number(e.target.value) })} />
      <div className="flex gap-2">
        <button className={secondaryButtonClass + " px-2"} onClick={() => onSave(draft)} aria-label="Save product"><Save className="size-4" /></button>
        <button className={secondaryButtonClass + " px-2"} onClick={() => onRemove(product.id)} aria-label="Remove product"><Trash2 className="size-4" /></button>
      </div>
    </div>
  );
}
