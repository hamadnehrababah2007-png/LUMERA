# B2B Wholesale Cosmetics Marketplace

Private B2B wholesale marketplace MVP for verified cosmetics merchants and suppliers in Jordan.

## Stack

- Next.js 15 App Router
- TypeScript
- Tailwind CSS
- Supabase Auth, Database, and Storage-ready integration

## Run Locally

```bash
pnpm install
pnpm dev
```

The app includes a local demo data layer so the complete MVP can be reviewed before Supabase credentials are added. Add `.env.local` from `.env.example` to connect Supabase.

## Supabase

Run `supabase/schema.sql` in your Supabase SQL editor, then create a public Storage bucket named `documents` and another named `products`.
