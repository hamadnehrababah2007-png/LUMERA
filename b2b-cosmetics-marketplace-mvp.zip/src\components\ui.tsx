import { cn } from "@/lib/utils";

export function PageHeader({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: React.ReactNode }) {
  return (
    <section className="border-b border-ink/10 bg-white">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        {eyebrow ? <p className="mb-2 text-sm font-semibold uppercase tracking-[0.18em] text-rose">{eyebrow}</p> : null}
        <h1 className="max-w-4xl text-3xl font-bold tracking-normal text-ink sm:text-5xl">{title}</h1>
        {children ? <div className="mt-4 max-w-3xl text-base leading-7 text-ink/70">{children}</div> : null}
      </div>
    </section>
  );
}

export function Badge({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "good" | "warn" | "bad" }) {
  return (
    <span
      className={cn(
        "inline-flex rounded px-2 py-1 text-xs font-semibold",
        tone === "neutral" && "bg-mint text-ink",
        tone === "good" && "bg-emerald-100 text-emerald-800",
        tone === "warn" && "bg-apricot/30 text-amber-900",
        tone === "bad" && "bg-rose/15 text-rose"
      )}
    >
      {children}
    </span>
  );
}

export function EmptyState({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md border border-dashed border-ink/20 bg-white p-8 text-center">
      <h2 className="text-lg font-bold">{title}</h2>
      <p className="mt-2 text-sm leading-6 text-ink/65">{children}</p>
    </div>
  );
}

export const inputClass = "focus-ring w-full rounded-md border border-ink/10 bg-white px-3 py-2 text-sm";
export const buttonClass = "focus-ring inline-flex min-h-10 items-center justify-center rounded-md bg-ink px-4 py-2 text-sm font-semibold text-white transition hover:bg-moss";
export const secondaryButtonClass = "focus-ring inline-flex min-h-10 items-center justify-center rounded-md border border-ink/15 bg-white px-4 py-2 text-sm font-semibold text-ink transition hover:bg-mint/60";
