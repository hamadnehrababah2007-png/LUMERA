"use client";

import Image from "next/image";
import Link from "next/link";
import { notFound, useParams } from "next/navigation";
import { ShoppingCart } from "lucide-react";
import { Badge, buttonClass, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { money } from "@/lib/utils";

export default function ProductDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { products, categories, user, addToCart } = useMarketplace();
  const product = products.find((item) => item.id === id);
  if (!product) notFound();
  const category = categories.find((item) => item.id === product.categoryId);
  const verifiedMerchant = user.role === "merchant" && user.status === "approved";

  return (
    <section className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
      <div className="relative aspect-[4/3] overflow-hidden rounded-md bg-mint shadow-soft">
        <Image src={product.imageUrl} alt={product.nameEn} fill className="object-cover" priority sizes="(min-width: 1024px) 45vw, 100vw" />
      </div>
      <div>
        <div className="mb-4 flex flex-wrap gap-2">
          <Badge>{product.brand}</Badge>
          <Badge>{category?.nameEn}</Badge>
          <Badge>{product.nameAr}</Badge>
        </div>
        <h1 className="text-3xl font-bold sm:text-5xl">{product.nameEn}</h1>
        <p className="mt-3 text-lg text-ink/65">{product.supplierName}</p>
        {verifiedMerchant ? (
          <>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {[
                ["Wholesale Price", money(product.wholesalePrice)],
                ["Available Quantity", product.availableQuantity],
                ["Minimum Order Quantity", product.minimumOrderQuantity],
                ["Delivery ETA", product.deliveryEta],
                ["Coverage Areas", product.coverageAreas.join(", ")],
                ["Category", category?.nameEn ?? "Category"]
              ].map(([label, value]) => (
                <div key={label} className="rounded-md border border-ink/10 bg-white p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-ink/45">{label}</p>
                  <p className="mt-2 text-lg font-bold">{value}</p>
                </div>
              ))}
            </div>
            <button className={buttonClass + " mt-6"} onClick={() => addToCart(product.id, product.minimumOrderQuantity)}>
              <ShoppingCart className="mr-2 size-4" /> Add minimum order
            </button>
          </>
        ) : (
          <div className="mt-8 rounded-md border border-apricot/40 bg-apricot/20 p-5">
            <p className="font-semibold">Wholesale prices are available only for verified cosmetics businesses.</p>
            <p className="mt-2 text-sm text-ink/65">You can preview product image, name, brand, and category while your application is pending.</p>
            <Link href="/register/merchant" className={secondaryButtonClass + " mt-4"}>Apply as merchant</Link>
          </div>
        )}
      </div>
    </section>
  );
}
