import Link from "next/link";
import { ArrowRight, BadgeCheck, LockKeyhole, Search, Truck } from "lucide-react";
import { buttonClass, secondaryButtonClass } from "@/components/ui";

const features = [
  ["Verified access", "Wholesale data is hidden until a business is approved.", LockKeyhole],
  ["Arabic and English search", "Find products by English or Arabic names and brands.", Search],
  ["Wholesale ordering", "MOQ validation, supplier grouped orders, and status tracking.", Truck],
  ["Admin control", "Approve users, manage products, and monitor every order.", BadgeCheck]
] as const;

export default function Home() {
  return (
    <>
      <section className="bg-white">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-16">
          <div className="flex flex-col justify-center">
            <p className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-rose">Private B2B marketplace</p>
            <h1 className="text-4xl font-bold tracking-normal text-ink sm:text-6xl">CosmoMarket Jordan</h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-ink/70">
              A closed wholesale platform where approved cosmetics stores discover suppliers, compare prices and delivery times, and place orders in one place.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/products" className={buttonClass}>Browse catalog <ArrowRight className="ml-2 size-4" /></Link>
              <Link href="/register/merchant" className={secondaryButtonClass}>Merchant application</Link>
              <Link href="/register/supplier" className={secondaryButtonClass}>Supplier application</Link>
            </div>
          </div>
          <div className="grid content-end gap-3 rounded-md bg-ink p-5 text-white shadow-soft">
            {features.map(([title, text, Icon]) => (
              <div key={String(title)} className="rounded bg-white/10 p-4">
                <Icon className="mb-3 size-5 text-apricot" />
                <h2 className="font-semibold">{title}</h2>
                <p className="mt-1 text-sm leading-6 text-white/75">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
