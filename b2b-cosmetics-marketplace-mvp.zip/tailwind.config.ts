import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#17201b",
        moss: "#55705f",
        mint: "#d9eadf",
        rose: "#d97987",
        apricot: "#f2b36d",
        porcelain: "#f8faf7"
      },
      boxShadow: {
        soft: "0 18px 50px rgba(23, 32, 27, 0.12)"
      }
    }
  },
  plugins: []
};

export default config;
