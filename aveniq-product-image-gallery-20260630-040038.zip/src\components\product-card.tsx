"use client";

import Link from "next/link";
import { ShoppingCart } from "lucide-react";
import { Badge, buttonClass } from "@/components/ui";
import { getProductImage, getProductImages } from "@/lib/product-images";
import { useMarketplace } from "@/lib/store";
import { Product } from "@/lib/types";
import { money } from "@/lib/utils";

export function ProductCard({ product }: { product: Product }) {
  const { user, addToCart } = useMarketplace();
  const verifiedMerchant = user.role === "merchant" && user.status === "approved";
  const images = getProductImages(product);

  return (
    <article className="overflow-hidden rounded-2xl border border-line bg-panel/88 shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-soft">
      <Link href={`/products/${product.id}`} className="block">
        <div className="relative aspect-[4/3] bg-mint">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={getProductImage(product)} alt={product.nameEn} className="h-full w-full object-cover" />
          {images.length > 1 ? <span className="absolute right-3 top-3 rounded-full bg-ink/70 px-3 py-1 text-xs font-semibold text-white backdrop-blur">+{images.length - 1} images</span> : null}
        </div>
      </Link>
      <div className="space-y-4 p-4">
        <div>
          <div className="mb-2 flex items-center justify-between gap-2">
            <Badge>{product.brand}</Badge>
            <span className="text-xs text-ink/55">{product.nameAr}</span>
          </div>
          <Link href={`/products/${product.id}`} className="text-lg font-semibold leading-6 hover:text-rose">
            {product.nameEn}
          </Link>
          <p className="mt-1 text-sm text-ink/60">{product.supplierName}</p>
        </div>
        {verifiedMerchant ? (
          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="rounded-xl bg-porcelain p-2"><b>{money(product.wholesalePrice)}</b><br />Wholesale</span>
            <span className="rounded-xl bg-porcelain p-2"><b>{product.availableQuantity}</b><br />In stock</span>
            <span className="rounded-xl bg-porcelain p-2"><b>{product.minimumOrderQuantity}</b><br />MOQ</span>
            <span className="rounded-xl bg-porcelain p-2"><b>{product.deliveryEta}</b><br />Delivery</span>
          </div>
        ) : (
          <p className="rounded-lg bg-mint p-3 text-sm font-medium text-ink">
            Wholesale prices are available only for verified businesses.
          </p>
        )}
        {verifiedMerchant ? (
          <button className={buttonClass + " w-full"} onClick={() => addToCart(product.id, product.minimumOrderQuantity)}>
            <ShoppingCart className="mr-2 size-4" /> Add MOQ to cart
          </button>
        ) : null}
      </div>
    </article>
  );
}
