import Link from "next/link";
import { ArrowRight, BadgeCheck, BarChart3, LockKeyhole, Search, Truck, Zap } from "lucide-react";
import { buttonClass, secondaryButtonClass } from "@/components/ui";
import { AveniqBrand } from "@/components/brand";

const features = [
  ["Enterprise Security", "Protect commercial pricing, supplier data, and ordering workflows behind verified access.", LockKeyhole],
  ["Lightning Fast Search", "Search products, brands, suppliers, availability, and delivery coverage from one command center.", Search],
  ["Smart Wholesale Ordering", "Validate MOQs, group orders by supplier, and keep fulfillment moving with clear statuses.", Truck],
  ["Business Intelligence", "Give teams the visibility to manage users, suppliers, inventory, and order health.", BarChart3]
] as const;

export default function Home() {
  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(124,58,237,0.16),transparent_34%,rgba(79,70,229,0.12)_70%,transparent)]" />
        <div className="relative mx-auto grid min-h-[86vh] max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.02fr_0.98fr] lg:py-20">
          <div className="animate-rise flex flex-col justify-center">
            <AveniqBrand className="mb-10" />
            <p className="mb-4 inline-flex w-fit items-center rounded-full border border-line bg-panel/76 px-4 py-2 text-sm font-semibold text-rose shadow-sm backdrop-blur">
              <Zap className="mr-2 size-4" /> Intelligent B2B commerce
            </p>
            <h1 className="max-w-4xl text-5xl font-semibold tracking-normal text-ink sm:text-7xl">
              The Operating System for B2B Commerce
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-ink/70 sm:text-xl">
              Connecting retailers, suppliers, and distributors through one intelligent platform built for verified trade, fast discovery, and scalable wholesale operations.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/register/merchant" className={buttonClass}>Join Aveniq <ArrowRight className="ml-2 size-4" /></Link>
              <Link href="/products" className={secondaryButtonClass}>Explore platform</Link>
              <Link href="/register/supplier" className={secondaryButtonClass}>Supplier access</Link>
            </div>
            <div className="mt-10 grid max-w-xl grid-cols-3 gap-3 text-sm">
              {[
                ["Verified", "network"],
                ["Real-time", "catalog"],
                ["Role-based", "control"]
              ].map(([value, label]) => (
                <div key={value} className="rounded-2xl border border-line bg-panel/70 p-4 shadow-sm backdrop-blur">
                  <p className="font-semibold text-ink">{value}</p>
                  <p className="mt-1 text-ink/55">{label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="animate-rise grid content-end gap-4 rounded-[2rem] border border-line bg-panel/72 p-5 shadow-soft backdrop-blur" style={{ animationDelay: "120ms" }}>
            <div className="rounded-[1.5rem] bg-ink p-5 text-porcelain shadow-glow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-porcelain/60">Network volume</p>
                  <p className="mt-2 text-3xl font-semibold">JOD 248K</p>
                </div>
                <BadgeCheck className="size-9 text-apricot" />
              </div>
              <div className="mt-6 grid grid-cols-6 items-end gap-2">
                {[42, 58, 36, 74, 66, 92].map((height, index) => (
                  <div key={height + index} className="rounded-full bg-white/10 p-1">
                    <div className="rounded-full bg-gradient-to-t from-rose to-apricot" style={{ height }} />
                  </div>
                ))}
              </div>
            </div>
            {features.map(([title, text, Icon]) => (
              <div key={String(title)} className="group rounded-2xl border border-line bg-panel/84 p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-soft">
                <Icon className="mb-3 size-5 text-apricot" />
                <h2 className="font-semibold text-ink">{title}</h2>
                <p className="mt-2 text-sm leading-6 text-ink/65">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
