"use client";

import { useState } from "react";
import Link from "next/link";
import { Upload } from "lucide-react";
import { PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";

export default function MerchantRegistrationPage() {
  const { registerMerchant, loginAs } = useMarketplace();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ storeName: "", ownerName: "", phone: "", city: "", area: "", instagram: "" });

  return (
    <>
      <PageHeader eyebrow="Merchant registration" title="Apply for verified B2B commerce access." />
      <section className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {submitted ? (
          <div className="rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur">
            <h2 className="text-xl font-bold">Application submitted</h2>
            <p className="mt-2 text-ink/65">Your merchant application is pending admin approval.</p>
            <Link href="/products" className={secondaryButtonClass + " mt-5"}>Preview products</Link>
          </div>
        ) : (
          <form
            className="grid gap-4 rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur"
            onSubmit={(event) => {
              event.preventDefault();
              registerMerchant(form);
              loginAs("merchant", "pending");
              setSubmitted(true);
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <input required className={inputClass} placeholder="Store Name" value={form.storeName} onChange={(e) => setForm({ ...form, storeName: e.target.value })} />
              <input required className={inputClass} placeholder="Owner Name" value={form.ownerName} onChange={(e) => setForm({ ...form, ownerName: e.target.value })} />
              <input required className={inputClass} placeholder="Phone Number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <input required className={inputClass} placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              <input required className={inputClass} placeholder="Area" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} />
              <input className={inputClass} placeholder="Instagram Page (Optional)" value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} />
            </div>
            <FileField label="Business License Upload" />
            <FileField label="Commercial Registration Upload" />
            <button className={buttonClass}>Submit merchant application</button>
          </form>
        )}
      </section>
    </>
  );
}

function FileField({ label }: { label: string }) {
  return <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-xl border border-dashed border-line bg-porcelain px-4 text-sm font-medium transition hover:bg-mint"><Upload className="size-4" />{label}<input required type="file" className="sr-only" /></label>;
}
