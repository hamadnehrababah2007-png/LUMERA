import type { Metadata } from "next";
import localFont from "next/font/local";
import "@/app/globals.css";
import { StoreProvider } from "@/lib/store";
import { AppShell } from "@/components/app-shell";
import { ThemeProvider } from "@/lib/theme";

const geist = localFont({
  src: "./fonts/geist-latin.woff2",
  variable: "--font-geist",
  display: "swap"
});

export const metadata: Metadata = {
  title: "Aveniq",
  description: "Aveniq is the operating system for B2B commerce, connecting businesses with trusted suppliers through one intelligent platform.",
  icons: {
    icon: "/aveniq-favicon.png",
    apple: "/aveniq-favicon.png"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={geist.className}>
        <ThemeProvider>
          <StoreProvider>
            <AppShell>{children}</AppShell>
          </StoreProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
