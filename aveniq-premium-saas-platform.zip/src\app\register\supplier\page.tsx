"use client";

import { useState } from "react";
import Link from "next/link";
import { Upload } from "lucide-react";
import { PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { useMarketplace } from "@/lib/store";

export default function SupplierRegistrationPage() {
  const { registerSupplier, loginAs } = useMarketplace();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ companyName: "", phone: "" });

  return (
    <>
      <PageHeader eyebrow="Supplier registration" title="Apply to sell wholesale products through Aveniq." />
      <section className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {submitted ? (
          <div className="rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur">
            <h2 className="text-xl font-bold">Application submitted</h2>
            <p className="mt-2 text-ink/65">Your supplier application is pending admin approval.</p>
            <Link href="/products" className={secondaryButtonClass + " mt-5"}>Return to catalog</Link>
          </div>
        ) : (
          <form
            className="grid gap-4 rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur"
            onSubmit={(event) => {
              event.preventDefault();
              registerSupplier(form);
              loginAs("supplier", "pending");
              setSubmitted(true);
            }}
          >
            <input required className={inputClass} placeholder="Company Name" value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
            <input required className={inputClass} placeholder="Phone Number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <FileField label="Business License Upload" />
            <FileField label="Commercial Registration Upload" />
            <button className={buttonClass}>Submit supplier application</button>
          </form>
        )}
      </section>
    </>
  );
}

function FileField({ label }: { label: string }) {
  return <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-xl border border-dashed border-line bg-porcelain px-4 text-sm font-medium transition hover:bg-mint"><Upload className="size-4" />{label}<input required type="file" className="sr-only" /></label>;
}
