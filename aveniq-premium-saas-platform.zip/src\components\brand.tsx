import Image from "next/image";
import { cn } from "@/lib/utils";

export function AveniqBrand({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-3", className)}>
      <span className="relative grid size-11 place-items-center overflow-hidden rounded-xl bg-[#111827] shadow-glow ring-1 ring-white/10">
        <Image src="/aveniq-favicon.png" alt="" fill className="object-cover" sizes="40px" priority />
      </span>
      {!compact ? (
        <span>
          <span className="block text-lg font-semibold leading-tight tracking-normal text-ink">Aveniq</span>
          <span className="block text-xs font-medium text-ink/55">B2B commerce operating system</span>
        </span>
      ) : null}
    </span>
  );
}
