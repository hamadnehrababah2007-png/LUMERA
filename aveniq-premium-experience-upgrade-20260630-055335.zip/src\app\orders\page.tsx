"use client";

import { Badge, EmptyState, PageHeader } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { money, statusLabel } from "@/lib/utils";

export default function OrdersPage() {
  const { orders, user } = useMarketplace();
  const visibleOrders = user.role === "supplier" ? orders.filter((order) => order.supplierId === "s-1") : orders;

  return (
    <>
      <PageHeader eyebrow="Orders" title="Track wholesale orders from pending through delivery." />
      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        {visibleOrders.length === 0 ? (
          <EmptyState title="No orders yet">Submitted orders will appear here with supplier and delivery status.</EmptyState>
        ) : (
          <div className="space-y-4">
            {visibleOrders.map((order) => (
              <article key={order.id} className="rounded-[1.75rem] border border-line bg-panel/88 p-5 shadow-sm backdrop-blur transition duration-300 hover:-translate-y-0.5 hover:border-rose/25 hover:shadow-soft">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.16em] text-ink/40">Wholesale order</p>
                    <h2 className="mt-1 text-2xl font-semibold tracking-tight">{order.id}</h2>
                    <p className="text-sm text-ink/60">{order.merchantName}{" -> "}{order.supplierName} · {order.createdAt}</p>
                  </div>
                  <Badge tone={order.status === "rejected" ? "bad" : order.status === "delivered" ? "good" : "warn"}>{statusLabel(order.status)}</Badge>
                </div>
                <div className="mt-5 overflow-x-auto rounded-2xl border border-line bg-porcelain/40">
                  <table className="w-full min-w-[560px] text-left text-sm">
                    <thead className="border-b border-line bg-panel/60 text-ink/50">
                      <tr><th className="px-4 py-3">Product</th><th>Qty</th><th>Unit</th><th className="px-4 text-right">Line total</th></tr>
                    </thead>
                    <tbody>
                      {order.items.map((item) => (
                        <tr key={item.productId} className="border-b border-line/60 last:border-0">
                          <td className="px-4 py-3 font-medium">{item.productName}</td>
                          <td>{item.quantity}</td>
                          <td>{money(item.unitPrice)}</td>
                          <td className="px-4 text-right font-semibold">{money(item.quantity * item.unitPrice)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="mt-4 text-right text-xl font-semibold tracking-tight">{money(order.total)}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
