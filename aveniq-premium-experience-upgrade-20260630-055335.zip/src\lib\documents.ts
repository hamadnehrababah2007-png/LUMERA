import { hasSupabaseEnv, supabase } from "@/lib/supabase/client";
import { VerificationDocument } from "@/lib/types";

type ApplicationKind = "merchant" | "supplier";

const DOCUMENT_BUCKET = "verification-documents";
const LOCAL_DOCUMENT_PREFIX = "aveniq-local-document:";
const LOCAL_DB_NAME = "aveniq-verification-documents";
const LOCAL_STORE_NAME = "documents";
const objectUrlCache = new Map<string, string>();

export function formatFileSize(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export function isImageDocument(document: VerificationDocument) {
  return document.fileType.startsWith("image/");
}

export function storageObjectUrl(storagePath?: string) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!supabaseUrl || !storagePath || isLocalDocumentReference(storagePath)) return undefined;
  return `${supabaseUrl}/storage/v1/object/authenticated/${DOCUMENT_BUCKET}/${storagePath}`;
}

export async function createVerificationDocument(file: File, label: string, applicationKind: ApplicationKind): Promise<VerificationDocument> {
  const id = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const previewUrl = URL.createObjectURL(file);
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
  let storagePath: string | undefined;
  let url = previewUrl;

  if (hasSupabaseEnv && supabase) {
    const { data } = await supabase.auth.getUser();
    const ownerId = data.user?.id ?? "pending-user";
    const candidatePath = `${applicationKind}/${ownerId}/${id}-${safeName}`;
    const { error } = await supabase.storage.from(DOCUMENT_BUCKET).upload(candidatePath, file, {
      cacheControl: "3600",
      contentType: file.type || "application/octet-stream",
      upsert: true
    });

    if (!error) {
      storagePath = candidatePath;
      url = "";
    }
  }

  if (!storagePath) {
    const localId = `${applicationKind}/${id}-${safeName}`;
    try {
      await storeLocalDocument(localId, file);
      url = `${LOCAL_DOCUMENT_PREFIX}${localId}`;
      storagePath = url;
    } catch {
      url = previewUrl;
    }
  }

  return {
    id,
    label,
    fileName: file.name,
    fileType: file.type || "application/octet-stream",
    size: file.size,
    uploadedAt: new Date().toISOString(),
    url: url || undefined,
    previewUrl,
    storagePath
  };
}

export function sanitizeVerificationDocument(document: VerificationDocument): VerificationDocument {
  return {
    id: document.id,
    label: document.label,
    fileName: document.fileName,
    fileType: document.fileType,
    size: document.size,
    uploadedAt: document.uploadedAt,
    url: isTemporaryDocumentUrl(document.url) ? undefined : document.url,
    storagePath: document.storagePath
  };
}

export async function resolveVerificationDocumentUrl(document: VerificationDocument) {
  if (document.previewUrl) return document.previewUrl;

  const reference = document.url ?? document.storagePath;
  if (reference && isLocalDocumentReference(reference)) {
    return resolveLocalDocumentUrl(reference);
  }

  if (document.storagePath && hasSupabaseEnv && supabase) {
    const { data, error } = await supabase.storage.from(DOCUMENT_BUCKET).createSignedUrl(document.storagePath, 60 * 10);
    if (!error && data.signedUrl) return data.signedUrl;
  }

  return document.url ?? storageObjectUrl(document.storagePath);
}

function isLocalDocumentReference(url: string) {
  return url.startsWith(LOCAL_DOCUMENT_PREFIX);
}

function isTemporaryDocumentUrl(url?: string) {
  return Boolean(url?.startsWith("blob:") || url?.startsWith("data:"));
}

async function resolveLocalDocumentUrl(reference: string) {
  const cached = objectUrlCache.get(reference);
  if (cached) return cached;

  const blob = await getLocalDocument(reference.slice(LOCAL_DOCUMENT_PREFIX.length));
  if (!blob) return undefined;

  const objectUrl = URL.createObjectURL(blob);
  objectUrlCache.set(reference, objectUrl);
  return objectUrl;
}

function openLocalDocumentDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(LOCAL_DB_NAME, 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(LOCAL_STORE_NAME);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function storeLocalDocument(id: string, file: File) {
  if (typeof indexedDB === "undefined") throw new Error("Local document storage is unavailable.");
  const db = await openLocalDocumentDb();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(LOCAL_STORE_NAME, "readwrite");
    transaction.objectStore(LOCAL_STORE_NAME).put(file, id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  db.close();
}

async function getLocalDocument(id: string) {
  if (typeof indexedDB === "undefined") return null;
  const db = await openLocalDocumentDb();
  const blob = await new Promise<Blob | null>((resolve, reject) => {
    const transaction = db.transaction(LOCAL_STORE_NAME, "readonly");
    const request = transaction.objectStore(LOCAL_STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error);
  });
  db.close();
  return blob;
}
