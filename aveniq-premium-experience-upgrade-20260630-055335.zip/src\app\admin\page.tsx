"use client";

import { useEffect, useState } from "react";
import { Download, ExternalLink, FileText, ImageIcon, Trash2, X } from "lucide-react";
import { ProductImage } from "@/components/product-image";
import { Badge, PageHeader, secondaryButtonClass } from "@/components/ui";
import { formatFileSize, isImageDocument, resolveVerificationDocumentUrl } from "@/lib/documents";
import { getProductImage, getProductImages } from "@/lib/product-images";
import { useMarketplace } from "@/lib/store";
import { VerificationDocument } from "@/lib/types";
import { money, statusLabel } from "@/lib/utils";

export default function AdminPage() {
  const { user, merchants, suppliers, products, orders, updateApplication, removeProduct } = useMarketplace();
  const [documentModal, setDocumentModal] = useState<{ title: string; documents: VerificationDocument[] } | null>(null);

  if (user.role !== "admin") {
    return (
      <>
        <PageHeader eyebrow="Admin dashboard" title="Admin access is restricted." />
        <section className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
          <p className="rounded-2xl border border-rose/20 bg-mint p-5 font-medium shadow-sm">Platform administrators manage approvals, users, products, and orders.</p>
        </section>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="Admin dashboard" title="Approve users, manage products, and monitor every wholesale order." />
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6">
        <div className="grid gap-4 md:grid-cols-4">
          <Stat label="Merchants" value={merchants.length} />
          <Stat label="Suppliers" value={suppliers.length} />
          <Stat label="Products" value={products.length} />
          <Stat label="Orders" value={orders.length} />
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <Panel title="Merchant applications">
            {merchants.map((merchant) => (
              <div key={merchant.id} className="rounded-2xl border border-line bg-porcelain/50 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <b>{merchant.storeName}</b>
                    <p className="text-sm text-ink/60">{merchant.ownerName} - {merchant.city}, {merchant.area} - {merchant.phone}</p>
                  </div>
                  <Badge tone={merchant.status === "approved" ? "good" : merchant.status === "rejected" ? "bad" : "warn"}>{statusLabel(merchant.status)}</Badge>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className={secondaryButtonClass} onClick={() => setDocumentModal({ title: `${merchant.storeName} documents`, documents: merchant.documents ?? [] })}>View Documents</button>
                  <button className={secondaryButtonClass} onClick={() => updateApplication("merchant", merchant.id, "approved")}>Approve</button>
                  <button className={secondaryButtonClass} onClick={() => updateApplication("merchant", merchant.id, "rejected")}>Reject</button>
                </div>
              </div>
            ))}
          </Panel>
          <Panel title="Supplier applications">
            {suppliers.map((supplier) => (
              <div key={supplier.id} className="rounded-2xl border border-line bg-porcelain/50 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <b>{supplier.companyName}</b>
                    <p className="text-sm text-ink/60">{supplier.phone}</p>
                  </div>
                  <Badge tone={supplier.status === "approved" ? "good" : supplier.status === "rejected" ? "bad" : "warn"}>{statusLabel(supplier.status)}</Badge>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className={secondaryButtonClass} onClick={() => setDocumentModal({ title: `${supplier.companyName} documents`, documents: supplier.documents ?? [] })}>View Documents</button>
                  <button className={secondaryButtonClass} onClick={() => updateApplication("supplier", supplier.id, "approved")}>Approve</button>
                  <button className={secondaryButtonClass} onClick={() => updateApplication("supplier", supplier.id, "rejected")}>Reject</button>
                </div>
              </div>
            ))}
          </Panel>
        </div>
        <Panel title="Product management">
          {products.map((product) => (
            <div key={product.id} className="grid gap-3 rounded-2xl border border-line bg-porcelain/50 p-4 sm:grid-cols-[72px_1fr_140px_44px]">
              <div className="relative size-16 overflow-hidden rounded-2xl bg-mint">
                <ProductImage src={getProductImage(product)} alt={product.nameEn} className="h-full w-full object-cover" />
              </div>
              <div>
                <b>{product.nameEn}</b>
                <p className="text-sm text-ink/60">{product.brand} - {product.supplierName} - {money(product.wholesalePrice)} - Stock {product.availableQuantity}</p>
                {getProductImages(product).length > 1 ? <p className="mt-1 text-xs font-semibold text-rose">+{getProductImages(product).length - 1} additional images</p> : null}
              </div>
              <Badge>{product.deliveryEta}</Badge>
              <button className={secondaryButtonClass + " px-2"} onClick={() => removeProduct(product.id)} aria-label="Remove product"><Trash2 className="size-4" /></button>
            </div>
          ))}
        </Panel>
        <Panel title="Order management">
          {orders.map((order) => (
            <div key={order.id} className="rounded-2xl border border-line bg-porcelain/50 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <b>{order.id}</b>
                  <p className="text-sm text-ink/60">{order.merchantName}{" -> "}{order.supplierName} - {money(order.total)}</p>
                </div>
                <Badge tone={order.status === "delivered" ? "good" : order.status === "rejected" ? "bad" : "warn"}>{statusLabel(order.status)}</Badge>
              </div>
            </div>
          ))}
        </Panel>
      </section>
      {documentModal ? <DocumentModal title={documentModal.title} documents={documentModal.documents} onClose={() => setDocumentModal(null)} /> : null}
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur"><p className="text-sm text-ink/55">{label}</p><p className="mt-1 text-3xl font-semibold">{value}</p></div>;
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="space-y-3 rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur"><h2 className="text-lg font-semibold">{title}</h2>{children}</div>;
}

function DocumentModal({ title, documents, onClose }: { title: string; documents: VerificationDocument[]; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 px-4 py-6 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={title}>
      <div className="max-h-[90vh] w-full max-w-4xl overflow-hidden rounded-2xl border border-line bg-panel shadow-glow">
        <div className="flex items-center justify-between gap-4 border-b border-line px-5 py-4">
          <div>
            <h2 className="text-lg font-semibold">{title}</h2>
            <p className="text-sm text-ink/60">Uploaded verification documents are visible to admins only.</p>
          </div>
          <button className={secondaryButtonClass + " min-h-10 px-3"} onClick={onClose} aria-label="Close document preview"><X className="size-4" /></button>
        </div>
        <div className="max-h-[calc(90vh-88px)] overflow-y-auto p-5">
          {documents.length ? (
            <div className="grid gap-4 md:grid-cols-2">
              {documents.map((document) => <DocumentCard key={document.id} document={document} />)}
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-line bg-porcelain/50 p-8 text-center">
              <FileText className="mx-auto size-8 text-ink/35" />
              <h3 className="mt-3 font-semibold">No documents uploaded</h3>
              <p className="mt-1 text-sm text-ink/60">This application does not have verification files attached yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DocumentCard({ document }: { document: VerificationDocument }) {
  const [openUrl, setOpenUrl] = useState<string | undefined>(document.previewUrl ?? document.url);

  useEffect(() => {
    let active = true;
    resolveVerificationDocumentUrl(document)
      .then((url) => {
        if (active) setOpenUrl(url);
      })
      .catch(() => {
        if (active) setOpenUrl(document.url);
      });
    return () => {
      active = false;
    };
  }, [document]);

  return (
    <article className="overflow-hidden rounded-2xl border border-line bg-porcelain/55 shadow-sm">
      <div className="flex aspect-video items-center justify-center bg-ink/5">
        {isImageDocument(document) && openUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={openUrl} alt={`${document.label} preview`} className="h-full w-full object-cover" />
        ) : (
          <div className="grid place-items-center gap-2 text-ink/55">
            {isImageDocument(document) ? <ImageIcon className="size-8" /> : <FileText className="size-8" />}
            <span className="text-sm font-medium">Preview available in new tab</span>
          </div>
        )}
      </div>
      <div className="space-y-3 p-4">
        <div>
          <p className="font-semibold">{document.label}</p>
          <p className="truncate text-sm text-ink/60">{document.fileName}</p>
          <p className="text-xs text-ink/45">{formatFileSize(document.size)} - {new Date(document.uploadedAt).toLocaleString()}</p>
          <p className="text-xs text-ink/45">{document.fileType || "application/octet-stream"}</p>
          {document.storagePath ? <p className="mt-1 truncate text-xs text-ink/40">Storage: {document.storagePath}</p> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          {openUrl ? (
            <>
              <a className={secondaryButtonClass + " min-h-10 gap-2 px-3"} href={openUrl} target="_blank" rel="noreferrer"><ExternalLink className="size-4" />Open</a>
              <a className={secondaryButtonClass + " min-h-10 gap-2 px-3"} href={openUrl} download={document.fileName}><Download className="size-4" />Download</a>
            </>
          ) : (
            <span className="rounded-xl border border-line bg-panel px-3 py-2 text-sm text-ink/55">Stored privately in Supabase</span>
          )}
        </div>
      </div>
    </article>
  );
}
