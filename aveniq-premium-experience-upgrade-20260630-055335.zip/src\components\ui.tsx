import { cn } from "@/lib/utils";

export function PageHeader({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: React.ReactNode }) {
  return (
    <section className="relative overflow-hidden border-b border-line/70 bg-panel/78 backdrop-blur-2xl">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_15%_0%,rgba(124,58,237,0.16),transparent_28rem),radial-gradient(circle_at_82%_0%,rgba(79,70,229,0.1),transparent_24rem)]" />
      <div className="relative mx-auto max-w-7xl px-4 py-14 sm:px-6">
        {eyebrow ? <p className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-rose">{eyebrow}</p> : null}
        <h1 className="max-w-4xl text-3xl font-semibold tracking-tight text-ink sm:text-5xl">{title}</h1>
        {children ? <div className="mt-5 max-w-3xl text-base leading-7 text-ink/70">{children}</div> : null}
      </div>
    </section>
  );
}

export function Badge({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "good" | "warn" | "bad" }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-full px-2.5 py-1 text-xs font-semibold shadow-sm ring-1 ring-inset",
        tone === "neutral" && "bg-mint text-ink ring-line/70",
        tone === "good" && "bg-emerald-100 text-emerald-800 ring-emerald-500/20",
        tone === "warn" && "bg-apricot/30 text-amber-900 ring-amber-500/20",
        tone === "bad" && "bg-rose/15 text-rose ring-rose/20"
      )}
    >
      {children}
    </span>
  );
}

export function EmptyState({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-[1.75rem] border border-dashed border-line bg-panel/86 p-8 text-center shadow-soft backdrop-blur transition duration-300 hover:-translate-y-0.5 hover:border-rose/25">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mt-2 text-sm leading-6 text-ink/65">{children}</p>
    </div>
  );
}

export const inputClass = "focus-ring w-full rounded-2xl border border-line bg-panel/90 px-3.5 py-2.5 text-sm text-ink shadow-sm transition duration-200 placeholder:text-ink/35 hover:border-rose/25";
export const buttonClass = "focus-ring inline-flex min-h-11 items-center justify-center rounded-2xl bg-gradient-to-br from-rose to-violet-700 px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition duration-300 hover:-translate-y-0.5 hover:shadow-soft";
export const secondaryButtonClass = "focus-ring inline-flex min-h-11 items-center justify-center rounded-2xl border border-line bg-panel/88 px-5 py-2.5 text-sm font-semibold text-ink shadow-sm transition duration-300 hover:-translate-y-0.5 hover:border-rose/25 hover:bg-mint";
