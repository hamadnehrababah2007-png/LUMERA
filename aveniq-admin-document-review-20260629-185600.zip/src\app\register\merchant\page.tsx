"use client";

import { useState } from "react";
import Link from "next/link";
import { FileCheck2, Upload } from "lucide-react";
import { PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { createVerificationDocument, formatFileSize } from "@/lib/documents";
import { useMarketplace } from "@/lib/store";
import { VerificationDocument } from "@/lib/types";

const requiredDocuments = ["Business License", "Commercial Registration"];

export default function MerchantRegistrationPage() {
  const { registerMerchant, loginAs } = useMarketplace();
  const [submitted, setSubmitted] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [documentError, setDocumentError] = useState("");
  const [documents, setDocuments] = useState<VerificationDocument[]>([]);
  const [form, setForm] = useState({ storeName: "", ownerName: "", phone: "", city: "", area: "", instagram: "" });

  const upsertDocument = (document: VerificationDocument) => {
    setDocuments((current) => [document, ...current.filter((item) => item.label !== document.label)]);
    setDocumentError("");
  };

  return (
    <>
      <PageHeader eyebrow="Merchant registration" title="Request verified B2B commerce access." />
      <section className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {submitted ? (
          <div className="rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur">
            <h2 className="text-xl font-bold">Application submitted</h2>
            <p className="mt-2 text-ink/65">Your merchant application is pending admin approval.</p>
            <Link href="/products" className={secondaryButtonClass + " mt-5"}>Preview products</Link>
          </div>
        ) : (
          <form
            className="grid gap-4 rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur"
            onSubmit={(event) => {
              event.preventDefault();
              const missingDocument = requiredDocuments.find((label) => !documents.some((document) => document.label === label));
              if (missingDocument) {
                setDocumentError(`Please upload ${missingDocument}.`);
                return;
              }
              registerMerchant({ ...form, documents });
              loginAs("merchant", "pending");
              setSubmitted(true);
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <input required className={inputClass} placeholder="Store Name" value={form.storeName} onChange={(e) => setForm({ ...form, storeName: e.target.value })} />
              <input required className={inputClass} placeholder="Owner Name" value={form.ownerName} onChange={(e) => setForm({ ...form, ownerName: e.target.value })} />
              <input required className={inputClass} placeholder="Phone Number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <input required className={inputClass} placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              <input required className={inputClass} placeholder="Area" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} />
              <input className={inputClass} placeholder="Instagram Page (Optional)" value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <FileField label="Business License" required document={documents.find((item) => item.label === "Business License")} onUpload={upsertDocument} setUploading={setIsUploading} />
              <FileField label="Commercial Registration" required document={documents.find((item) => item.label === "Commercial Registration")} onUpload={upsertDocument} setUploading={setIsUploading} />
              <FileField label="Store License" document={documents.find((item) => item.label === "Store License")} onUpload={upsertDocument} setUploading={setIsUploading} />
              <FileField label="Other Verification Document" document={documents.find((item) => item.label === "Other Verification Document")} onUpload={upsertDocument} setUploading={setIsUploading} />
            </div>
            {documentError ? <p className="text-sm font-medium text-rose">{documentError}</p> : null}
            <button className={buttonClass} disabled={isUploading}>{isUploading ? "Preparing documents..." : "Submit merchant application"}</button>
          </form>
        )}
      </section>
    </>
  );
}

function FileField({
  label,
  required,
  document,
  onUpload,
  setUploading
}: {
  label: string;
  required?: boolean;
  document?: VerificationDocument;
  onUpload: (document: VerificationDocument) => void;
  setUploading: (value: boolean) => void;
}) {
  return (
    <label className="group flex min-h-20 cursor-pointer items-center gap-3 rounded-xl border border-dashed border-line bg-porcelain px-4 py-3 text-sm font-medium transition hover:border-violet/45 hover:bg-mint">
      {document ? <FileCheck2 className="size-5 text-emerald" /> : <Upload className="size-5 text-violet" />}
      <span className="min-w-0">
        <span className="block text-ink">{label}{required ? " *" : ""}</span>
        <span className="mt-1 block truncate text-xs font-normal text-ink/55">{document ? `${document.fileName} - ${formatFileSize(document.size)}` : "Upload image or document"}</span>
      </span>
      <input
        type="file"
        required={required && !document}
        accept="image/*,.pdf,.doc,.docx"
        className="sr-only"
        onChange={async (event) => {
          const file = event.target.files?.[0];
          if (!file) return;
          setUploading(true);
          try {
            onUpload(await createVerificationDocument(file, label, "merchant"));
          } finally {
            setUploading(false);
          }
        }}
      />
    </label>
  );
}
