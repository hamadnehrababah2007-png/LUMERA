create function public.admin_approve_merchant_application(p_application_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  application public.merchant_applications;
begin
  if not public.is_admin() then
    raise exception 'Only admins can approve merchant applications.';
  end if;

  select * into application
  from public.merchant_applications
  where id = p_application_id
  for update;

  if application.id is null then
    raise exception 'Merchant application not found.';
  end if;

  update public.merchant_applications
  set
    status = 'approved',
    reviewed_by = auth.uid(),
    reviewed_at = now(),
    rejection_reason = null
  where id = application.id;

  update public.profiles
  set approval_status = 'approved'
  where id = application.user_id;

  insert into public.merchants (
    profile_id,
    application_id,
    store_name,
    owner_name,
    phone_number,
    city,
    area,
    instagram_page
  )
  values (
    application.user_id,
    application.id,
    application.store_name,
    application.owner_name,
    application.phone_number,
    application.city,
    application.area,
    application.instagram_page
  )
  on conflict (profile_id) do update set
    application_id = excluded.application_id,
    store_name = excluded.store_name,
    owner_name = excluded.owner_name,
    phone_number = excluded.phone_number,
    city = excluded.city,
    area = excluded.area,
    instagram_page = excluded.instagram_page;

  insert into public.notifications (recipient_id, type, title, body)
  values (
    application.user_id,
    'application_status',
    'Merchant account approved',
    'Your Lumera merchant account has been approved. Wholesale prices and ordering are now available.'
  );
end;
$$;

create function public.admin_reject_merchant_application(p_application_id uuid, p_rejection_reason text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  application public.merchant_applications;
begin
  if not public.is_admin() then
    raise exception 'Only admins can reject merchant applications.';
  end if;

  select * into application
  from public.merchant_applications
  where id = p_application_id
  for update;

  if application.id is null then
    raise exception 'Merchant application not found.';
  end if;

  update public.merchant_applications
  set
    status = 'rejected',
    reviewed_by = auth.uid(),
    reviewed_at = now(),
    rejection_reason = p_rejection_reason
  where id = application.id;

  update public.profiles
  set approval_status = 'rejected'
  where id = application.user_id;

  insert into public.notifications (recipient_id, type, title, body)
  values (
    application.user_id,
    'application_status',
    'Merchant application rejected',
    coalesce(p_rejection_reason, 'Your merchant application was rejected. Please contact Lumera support for details.')
  );
end;
$$;

create function public.admin_approve_supplier_application(p_application_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  application public.supplier_applications;
begin
  if not public.is_admin() then
    raise exception 'Only admins can approve supplier applications.';
  end if;

  select * into application
  from public.supplier_applications
  where id = p_application_id
  for update;

  if application.id is null then
    raise exception 'Supplier application not found.';
  end if;

  update public.supplier_applications
  set
    status = 'approved',
    reviewed_by = auth.uid(),
    reviewed_at = now(),
    rejection_reason = null
  where id = application.id;

  update public.profiles
  set approval_status = 'approved'
  where id = application.user_id;

  insert into public.suppliers (
    profile_id,
    application_id,
    company_name,
    phone_number
  )
  values (
    application.user_id,
    application.id,
    application.company_name,
    application.phone_number
  )
  on conflict (profile_id) do update set
    application_id = excluded.application_id,
    company_name = excluded.company_name,
    phone_number = excluded.phone_number;

  insert into public.notifications (recipient_id, type, title, body)
  values (
    application.user_id,
    'application_status',
    'Supplier account approved',
    'Your Lumera supplier account has been approved. Product listing tools are now available.'
  );
end;
$$;

create function public.admin_reject_supplier_application(p_application_id uuid, p_rejection_reason text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  application public.supplier_applications;
begin
  if not public.is_admin() then
    raise exception 'Only admins can reject supplier applications.';
  end if;

  select * into application
  from public.supplier_applications
  where id = p_application_id
  for update;

  if application.id is null then
    raise exception 'Supplier application not found.';
  end if;

  update public.supplier_applications
  set
    status = 'rejected',
    reviewed_by = auth.uid(),
    reviewed_at = now(),
    rejection_reason = p_rejection_reason
  where id = application.id;

  update public.profiles
  set approval_status = 'rejected'
  where id = application.user_id;

  insert into public.notifications (recipient_id, type, title, body)
  values (
    application.user_id,
    'application_status',
    'Supplier application rejected',
    coalesce(p_rejection_reason, 'Your supplier application was rejected. Please contact Lumera support for details.')
  );
end;
$$;

grant execute on function public.admin_approve_merchant_application(uuid) to authenticated;
grant execute on function public.admin_reject_merchant_application(uuid, text) to authenticated;
grant execute on function public.admin_approve_supplier_application(uuid) to authenticated;
grant execute on function public.admin_reject_supplier_application(uuid, text) to authenticated;
