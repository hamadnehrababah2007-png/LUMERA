export const productDecisions = [
  {
    area: "Access",
    title: "Closed marketplace",
    summary:
      "Wholesale prices, inventory, cart, and order placement are reserved for approved cosmetics businesses.",
  },
  {
    area: "Catalog",
    title: "Supplier-owned products",
    summary:
      "Suppliers manage prices, stock, minimum order quantities, delivery ETAs, and coverage areas.",
  },
  {
    area: "Operations",
    title: "Admin-led approvals",
    summary:
      "Admins approve merchants and suppliers, manage categories, monitor products, and oversee orders.",
  },
] as const;
