"use server";

import { redirect } from "next/navigation";

import { authRedirect } from "@/lib/auth/messages";
import { requireRole } from "@/lib/auth/guards";
import { routes } from "@/lib/routes";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { CoverageCity } from "@/types/domain";

const cities = new Set<CoverageCity>(["amman", "irbid", "zarqa", "other"]);

function readRequired(formData: FormData, key: string) {
  const value = formData.get(key);

  return typeof value === "string" ? value.trim() : "";
}

function readOptional(formData: FormData, key: string) {
  const value = readRequired(formData, key);

  return value ? value : null;
}

function readCity(formData: FormData): CoverageCity {
  const value = readRequired(formData, "city");

  return cities.has(value as CoverageCity) ? (value as CoverageCity) : "other";
}

function readFile(formData: FormData, key: string) {
  const value = formData.get(key);

  return value instanceof File && value.size > 0 ? value : null;
}

async function uploadBusinessDocument(userId: string, folder: string, file: File) {
  const supabase = await createSupabaseServerClient();
  const extension = file.name.split(".").pop()?.toLowerCase() ?? "bin";
  const path = `${userId}/${folder}/${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from("business-documents").upload(path, file, {
    contentType: file.type || "application/octet-stream",
    upsert: false,
  });

  if (error) {
    throw new Error(error.message);
  }

  return path;
}

export async function submitMerchantApplicationAction(formData: FormData) {
  const profile = await requireRole("merchant");
  const storeName = readRequired(formData, "storeName");
  const ownerName = readRequired(formData, "ownerName");
  const phoneNumber = readRequired(formData, "phoneNumber");
  const area = readRequired(formData, "area");
  const city = readCity(formData);
  const instagramPage = readOptional(formData, "instagramPage");
  const businessLicense = readFile(formData, "businessLicense");
  const commercialRegistration = readFile(formData, "commercialRegistration");

  if (!storeName || !ownerName || !phoneNumber || !area || !businessLicense || !commercialRegistration) {
    redirect(authRedirect(routes.merchantOnboarding, "error", "All required merchant fields must be completed."));
  }

  try {
    const businessLicensePath = await uploadBusinessDocument(profile.id, "merchant", businessLicense);
    const commercialRegistrationPath = await uploadBusinessDocument(
      profile.id,
      "merchant",
      commercialRegistration,
    );
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.from("merchant_applications").upsert(
      {
        user_id: profile.id,
        store_name: storeName,
        owner_name: ownerName,
        phone_number: phoneNumber,
        city,
        area,
        business_license_path: businessLicensePath,
        commercial_registration_path: commercialRegistrationPath,
        instagram_page: instagramPage,
        status: "pending",
      },
      { onConflict: "user_id" },
    );

    if (error) {
      throw new Error(error.message);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : "Merchant application could not be submitted.";
    redirect(authRedirect(routes.merchantOnboarding, "error", message));
  }

  redirect(authRedirect(routes.pendingApproval, "status", "Merchant application submitted for admin review."));
}

export async function submitSupplierApplicationAction(formData: FormData) {
  const profile = await requireRole("supplier");
  const companyName = readRequired(formData, "companyName");
  const phoneNumber = readRequired(formData, "phoneNumber");
  const businessLicense = readFile(formData, "businessLicense");
  const commercialRegistration = readFile(formData, "commercialRegistration");

  if (!companyName || !phoneNumber || !businessLicense || !commercialRegistration) {
    redirect(authRedirect(routes.supplierOnboarding, "error", "All required supplier fields must be completed."));
  }

  try {
    const businessLicensePath = await uploadBusinessDocument(profile.id, "supplier", businessLicense);
    const commercialRegistrationPath = await uploadBusinessDocument(
      profile.id,
      "supplier",
      commercialRegistration,
    );
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.from("supplier_applications").upsert(
      {
        user_id: profile.id,
        company_name: companyName,
        phone_number: phoneNumber,
        business_license_path: businessLicensePath,
        commercial_registration_path: commercialRegistrationPath,
        status: "pending",
      },
      { onConflict: "user_id" },
    );

    if (error) {
      throw new Error(error.message);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : "Supplier application could not be submitted.";
    redirect(authRedirect(routes.supplierOnboarding, "error", message));
  }

  redirect(authRedirect(routes.pendingApproval, "status", "Supplier application submitted for admin review."));
}
