export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string | null;
          role: Database["public"]["Enums"]["user_role"];
          approval_status: Database["public"]["Enums"]["approval_status"];
          display_name: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email?: string | null;
          role?: Database["public"]["Enums"]["user_role"];
          approval_status?: Database["public"]["Enums"]["approval_status"];
          display_name?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          email?: string | null;
          role?: Database["public"]["Enums"]["user_role"];
          approval_status?: Database["public"]["Enums"]["approval_status"];
          display_name?: string | null;
          updated_at?: string;
        };
      };
      merchant_applications: {
        Row: {
          id: string;
          user_id: string;
          store_name: string;
          owner_name: string;
          phone_number: string;
          city: Database["public"]["Enums"]["coverage_city"];
          area: string;
          business_license_path: string;
          commercial_registration_path: string;
          instagram_page: string | null;
          status: Database["public"]["Enums"]["approval_status"];
          reviewed_by: string | null;
          reviewed_at: string | null;
          rejection_reason: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          store_name: string;
          owner_name: string;
          phone_number: string;
          city: Database["public"]["Enums"]["coverage_city"];
          area: string;
          business_license_path: string;
          commercial_registration_path: string;
          instagram_page?: string | null;
          status?: Database["public"]["Enums"]["approval_status"];
          reviewed_by?: string | null;
          reviewed_at?: string | null;
          rejection_reason?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["merchant_applications"]["Insert"]>;
      };
      supplier_applications: {
        Row: {
          id: string;
          user_id: string;
          company_name: string;
          phone_number: string;
          business_license_path: string;
          commercial_registration_path: string;
          status: Database["public"]["Enums"]["approval_status"];
          reviewed_by: string | null;
          reviewed_at: string | null;
          rejection_reason: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          company_name: string;
          phone_number: string;
          business_license_path: string;
          commercial_registration_path: string;
          status?: Database["public"]["Enums"]["approval_status"];
          reviewed_by?: string | null;
          reviewed_at?: string | null;
          rejection_reason?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["supplier_applications"]["Insert"]>;
      };
      merchants: {
        Row: {
          id: string;
          profile_id: string;
          application_id: string | null;
          store_name: string;
          owner_name: string;
          phone_number: string;
          city: Database["public"]["Enums"]["coverage_city"];
          area: string;
          instagram_page: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          profile_id: string;
          application_id?: string | null;
          store_name: string;
          owner_name: string;
          phone_number: string;
          city: Database["public"]["Enums"]["coverage_city"];
          area: string;
          instagram_page?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["merchants"]["Insert"]>;
      };
      suppliers: {
        Row: {
          id: string;
          profile_id: string;
          application_id: string | null;
          company_name: string;
          phone_number: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          profile_id: string;
          application_id?: string | null;
          company_name: string;
          phone_number: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["suppliers"]["Insert"]>;
      };
      categories: {
        Row: {
          id: string;
          slug: string;
          name_en: string;
          name_ar: string | null;
          product_category: Database["public"]["Enums"]["product_category"];
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          slug: string;
          name_en: string;
          name_ar?: string | null;
          product_category?: Database["public"]["Enums"]["product_category"];
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["categories"]["Insert"]>;
      };
      coverage_areas: {
        Row: {
          id: string;
          city: Database["public"]["Enums"]["coverage_city"];
          area: string | null;
          label: string;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          city: Database["public"]["Enums"]["coverage_city"];
          area?: string | null;
          label: string;
          is_active?: boolean;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["coverage_areas"]["Insert"]>;
      };
      products: {
        Row: {
          id: string;
          supplier_id: string;
          category_id: string;
          name_en: string;
          name_ar: string | null;
          image_path: string;
          brand: string;
          wholesale_price: number;
          available_quantity: number;
          minimum_order_quantity: number;
          delivery_eta: Database["public"]["Enums"]["delivery_eta"];
          custom_delivery_eta: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          supplier_id: string;
          category_id: string;
          name_en: string;
          name_ar?: string | null;
          image_path: string;
          brand: string;
          wholesale_price: number;
          available_quantity?: number;
          minimum_order_quantity?: number;
          delivery_eta?: Database["public"]["Enums"]["delivery_eta"];
          custom_delivery_eta?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["products"]["Insert"]>;
      };
      product_coverage_areas: {
        Row: {
          product_id: string;
          coverage_area_id: string;
        };
        Insert: {
          product_id: string;
          coverage_area_id: string;
        };
        Update: Partial<Database["public"]["Tables"]["product_coverage_areas"]["Insert"]>;
      };
      carts: {
        Row: {
          id: string;
          merchant_id: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          merchant_id: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["carts"]["Insert"]>;
      };
      cart_items: {
        Row: {
          id: string;
          cart_id: string;
          product_id: string;
          quantity: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          cart_id: string;
          product_id: string;
          quantity: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["cart_items"]["Insert"]>;
      };
      orders: {
        Row: {
          id: string;
          merchant_id: string;
          supplier_id: string;
          status: Database["public"]["Enums"]["order_status"];
          delivery_city: Database["public"]["Enums"]["coverage_city"];
          delivery_area: string;
          delivery_address: string | null;
          notes: string | null;
          total_amount: number;
          accepted_at: string | null;
          rejected_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          merchant_id: string;
          supplier_id: string;
          status?: Database["public"]["Enums"]["order_status"];
          delivery_city: Database["public"]["Enums"]["coverage_city"];
          delivery_area: string;
          delivery_address?: string | null;
          notes?: string | null;
          total_amount?: number;
          accepted_at?: string | null;
          rejected_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["orders"]["Insert"]>;
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string;
          product_name: string;
          brand: string;
          unit_price: number;
          quantity: number;
          line_total: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          order_id: string;
          product_id: string;
          product_name: string;
          brand: string;
          unit_price: number;
          quantity: number;
          line_total: number;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["order_items"]["Insert"]>;
      };
      notifications: {
        Row: {
          id: string;
          recipient_id: string;
          type: Database["public"]["Enums"]["notification_type"];
          title: string;
          body: string;
          read_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          recipient_id: string;
          type: Database["public"]["Enums"]["notification_type"];
          title: string;
          body: string;
          read_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["notifications"]["Insert"]>;
      };
    };
    Views: {
      product_public_cards: {
        Row: {
          id: string | null;
          name_en: string | null;
          name_ar: string | null;
          image_path: string | null;
          brand: string | null;
          category_name_en: string | null;
          category_name_ar: string | null;
          created_at: string | null;
        };
      };
      merchant_product_catalog: {
        Row: {
          id: string | null;
          name_en: string | null;
          name_ar: string | null;
          image_path: string | null;
          brand: string | null;
          wholesale_price: number | null;
          available_quantity: number | null;
          minimum_order_quantity: number | null;
          delivery_eta: Database["public"]["Enums"]["delivery_eta"] | null;
          custom_delivery_eta: string | null;
          is_active: boolean | null;
          created_at: string | null;
          category_id: string | null;
          category_name_en: string | null;
          category_name_ar: string | null;
          supplier_id: string | null;
          supplier_name: string | null;
          coverage_area_labels: string[] | null;
        };
      };
    };
    Functions: {
      current_approval_status: {
        Args: Record<PropertyKey, never>;
        Returns: Database["public"]["Enums"]["approval_status"];
      };
      current_user_role: {
        Args: Record<PropertyKey, never>;
        Returns: Database["public"]["Enums"]["user_role"];
      };
      is_admin: {
        Args: Record<PropertyKey, never>;
        Returns: boolean;
      };
      is_approved_merchant: {
        Args: Record<PropertyKey, never>;
        Returns: boolean;
      };
      admin_approve_merchant_application: {
        Args: { p_application_id: string };
        Returns: undefined;
      };
      admin_reject_merchant_application: {
        Args: { p_application_id: string; p_rejection_reason?: string | null };
        Returns: undefined;
      };
      admin_approve_supplier_application: {
        Args: { p_application_id: string };
        Returns: undefined;
      };
      admin_reject_supplier_application: {
        Args: { p_application_id: string; p_rejection_reason?: string | null };
        Returns: undefined;
      };
      checkout_merchant_cart: {
        Args: {
          p_delivery_city: Database["public"]["Enums"]["coverage_city"];
          p_delivery_area: string;
          p_delivery_address?: string | null;
          p_notes?: string | null;
        };
        Returns: string[];
      };
    };
    Enums: {
      approval_status: "pending" | "approved" | "rejected";
      coverage_city: "amman" | "irbid" | "zarqa" | "other";
      delivery_eta: "same_day" | "24_hours" | "48_hours" | "custom";
      notification_type: "application_status" | "order_status" | "supplier_order" | "admin_alert";
      order_status: "pending" | "approved" | "preparing" | "out_for_delivery" | "delivered" | "rejected";
      product_category: "skincare" | "haircare" | "makeup" | "fragrances" | "beauty_tools" | "other";
      user_role: "merchant" | "supplier" | "admin";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};
