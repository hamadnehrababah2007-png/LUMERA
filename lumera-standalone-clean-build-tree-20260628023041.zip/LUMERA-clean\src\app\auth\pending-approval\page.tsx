import Link from "next/link";

import { AuthMessage } from "@/components/auth/auth-message";
import { getCurrentProfile } from "@/lib/auth/session";
import { getAuthMessage } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";

type PendingApprovalPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function PendingApprovalPage({ searchParams }: PendingApprovalPageProps) {
  const params = await searchParams;
  const profile = await getCurrentProfile();

  return (
    <main className="mx-auto flex min-h-screen max-w-3xl items-center px-5 py-10">
      <section className="w-full rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
        <AuthMessage status={getAuthMessage(params?.status)} />
        <p className="mt-6 text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
          Approval required
        </p>
        <h1 className="mt-3 text-3xl font-semibold">Wholesale access is pending review.</h1>
        <p className="mt-4 leading-7 text-[color:var(--muted)]">
          Wholesale prices are available only for verified cosmetics businesses. Admin approval will unlock
          role-specific access for your account.
        </p>
        {profile ? (
          <div className="mt-6 rounded border border-[color:var(--line)] bg-white p-4 text-sm">
            <p>
              Signed in as <span className="font-semibold">{profile.email}</span>
            </p>
            <p className="mt-1 text-[color:var(--muted)]">
              Role: {profile.role} - Status: {profile.approvalStatus}
            </p>
          </div>
        ) : null}
        <div className="mt-6 flex flex-wrap gap-3">
          <Link className="rounded bg-[color:var(--brand)] px-4 py-2 font-semibold text-white" href={routes.home}>
            Back to home
          </Link>
          <Link className="rounded border border-[color:var(--line)] px-4 py-2 font-semibold" href={routes.signIn}>
            Sign in
          </Link>
        </div>
      </section>
    </main>
  );
}
