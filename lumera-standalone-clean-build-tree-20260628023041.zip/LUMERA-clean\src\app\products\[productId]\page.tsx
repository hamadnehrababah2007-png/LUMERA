import Link from "next/link";

import { addToCartAction } from "@/app/shop/actions";
import { AuthMessage } from "@/components/auth/auth-message";
import { ShopShell } from "@/components/shop/shop-shell";
import { requireRole } from "@/lib/auth/guards";
import { getAuthMessage } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";
import { getMerchantForProfile, getProductDetail } from "@/lib/shop/queries";
import { getPublicStorageUrl } from "@/lib/supabase/storage";

type ProductDetailPageProps = {
  params: Promise<{ productId: string }>;
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ProductDetailPage({ params, searchParams }: ProductDetailPageProps) {
  const [{ productId }, queryParams] = await Promise.all([params, searchParams]);
  const profile = await requireRole("merchant");
  const merchant = await getMerchantForProfile(profile.id);
  const approved = profile.approvalStatus === "approved" && Boolean(merchant);
  const { product, limitedProduct } = await getProductDetail(productId, approved);
  const displayProduct = product ?? limitedProduct;
  const imageUrl = getPublicStorageUrl("product-images", displayProduct?.image_path);

  return (
    <ShopShell
      description="Inspect product details. Wholesale fields and cart access require approved merchant status."
      profile={profile}
      title={displayProduct?.name_en ?? "Product detail"}
    >
      <AuthMessage error={getAuthMessage(queryParams?.error)} status={getAuthMessage(queryParams?.status)} />
      <article className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm">
        <p className="text-sm font-semibold text-[color:var(--accent)]">{displayProduct?.category_name_en}</p>
        <h2 className="mt-2 text-3xl font-semibold">{displayProduct?.name_en}</h2>
        {displayProduct?.name_ar ? <p className="mt-2 text-[color:var(--muted)]">{displayProduct.name_ar}</p> : null}
        <p className="mt-3 text-[color:var(--muted)]">Brand: {displayProduct?.brand}</p>
        <div className="mt-6 aspect-[16/9] max-h-[420px] overflow-hidden rounded border border-[color:var(--line)] bg-white">
          {imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img alt={displayProduct?.name_en ?? "Product image"} className="h-full w-full object-cover" src={imageUrl} />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-[color:var(--muted)]">
              Product image
            </div>
          )}
        </div>

        {product ? (
          <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_320px]">
            <div className="rounded border border-[color:var(--line)] bg-white p-4">
              <h3 className="font-semibold">Supplier and delivery</h3>
              <p className="mt-2 text-sm text-[color:var(--muted)]">Supplier: {product.supplier_name}</p>
              <p className="text-sm text-[color:var(--muted)]">
                Coverage: {product.coverage_area_labels?.join(", ") || "Not specified"}
              </p>
              <p className="text-sm text-[color:var(--muted)]">
                Delivery ETA: {product.delivery_eta?.replaceAll("_", " ") ?? "Not specified"}
              </p>
              {product.custom_delivery_eta ? (
                <p className="text-sm text-[color:var(--muted)]">Custom ETA: {product.custom_delivery_eta}</p>
              ) : null}
            </div>
            <form action={addToCartAction} className="rounded border border-[color:var(--line)] bg-white p-4">
              <input name="productId" type="hidden" value={product.id ?? ""} />
              <input name="returnPath" type="hidden" value={`${routes.products}/${product.id}`} />
              <p className="text-2xl font-semibold">{(product.wholesale_price ?? 0).toFixed(3)} JOD</p>
              <p className="mt-2 text-sm text-[color:var(--muted)]">Available quantity: {product.available_quantity}</p>
              <p className="text-sm text-[color:var(--muted)]">Minimum order quantity: {product.minimum_order_quantity}</p>
              <label className="mt-4 block">
                <span className="text-sm font-medium">Quantity</span>
                <input
                  className="mt-2 w-full rounded border border-[color:var(--line)] px-3 py-2"
                  defaultValue={product.minimum_order_quantity ?? 1}
                  min={product.minimum_order_quantity ?? 1}
                  name="quantity"
                  required
                  type="number"
                />
              </label>
              <button className="mt-4 w-full rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white">
                Add to cart
              </button>
            </form>
          </div>
        ) : (
          <div className="mt-6 rounded border border-amber-200 bg-amber-50 p-4 text-amber-900">
            Wholesale prices are available only for verified cosmetics businesses.
          </div>
        )}

        <Link className="mt-6 inline-flex rounded border border-[color:var(--line)] px-4 py-2 text-sm font-semibold" href={routes.products}>
          Back to catalog
        </Link>
      </article>
    </ShopShell>
  );
}
