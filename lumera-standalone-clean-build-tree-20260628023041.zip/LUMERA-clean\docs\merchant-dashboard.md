# Merchant Dashboard

Milestone 6 implements the merchant workspace required by the PRD.

## Merchant Access

Merchant purchasing tools are available only after:

- the user role is `merchant`
- the profile approval status is `approved`
- a `merchants` record exists for the account

Pending merchants see the required PRD message:

```text
Wholesale prices are available only for verified cosmetics businesses.
```

Unverified merchants can view only limited product preview data:

- product image path
- product name
- brand
- category

## Catalog Discovery

Approved merchants can:

- browse active wholesale products
- search by English name, Arabic name, brand, or supplier
- filter by category
- filter by available products
- compare supplier, wholesale price, stock, MOQ, delivery ETA, and coverage areas

The dashboard reads from `merchant_product_catalog`, a security-invoker Supabase view that keeps Row Level Security active.

## Order Tracking

Approved merchants can view their own orders and current statuses.

Cart creation and checkout are intentionally left for the Orders milestone.
