import { AuthMessage } from "@/components/auth/auth-message";
import { StatusPill } from "@/components/admin/status-pill";
import { EmptyState } from "@/components/shop/empty-state";
import { ShopShell } from "@/components/shop/shop-shell";
import { requireRole } from "@/lib/auth/guards";
import { getAuthMessage } from "@/lib/auth/messages";
import { getMerchantForProfile, getMerchantOrders } from "@/lib/shop/queries";

type OrdersPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function OrdersPage({ searchParams }: OrdersPageProps) {
  const params = await searchParams;
  const profile = await requireRole("merchant");
  const merchant = await getMerchantForProfile(profile.id);
  const orders = merchant ? await getMerchantOrders(merchant.id) : [];

  return (
    <ShopShell
      description="Track submitted wholesale orders and supplier fulfillment statuses."
      profile={profile}
      title="Orders"
    >
      <AuthMessage error={getAuthMessage(params?.error)} status={getAuthMessage(params?.status)} />
      {orders.length === 0 ? <EmptyState label="No orders have been placed yet." /> : null}
      <div className="grid gap-4">
        {orders.map((order) => (
          <article className="rounded border border-[color:var(--line)] bg-white p-4" key={order.id}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="font-semibold">Order {order.id.slice(0, 8)}</h2>
                  <StatusPill value={order.status} />
                </div>
                <p className="mt-2 text-sm text-[color:var(--muted)]">
                  {order.delivery_city} / {order.delivery_area} - {order.total_amount.toFixed(3)} JOD
                </p>
                {order.items.length > 0 ? (
                  <ul className="mt-3 grid gap-1 text-sm text-[color:var(--muted)]">
                    {order.items.map((item) => (
                      <li key={item.id}>
                        {item.quantity} x {item.product_name} - {item.line_total.toFixed(3)} JOD
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
              <p className="text-sm text-[color:var(--muted)]">{new Date(order.created_at).toLocaleDateString()}</p>
            </div>
          </article>
        ))}
      </div>
    </ShopShell>
  );
}
