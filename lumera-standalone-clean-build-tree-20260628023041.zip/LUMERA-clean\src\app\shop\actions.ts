"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { requireAuth, requireRole } from "@/lib/auth/guards";
import { authRedirect } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";
import { getMerchantForProfile } from "@/lib/shop/queries";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { CoverageCity } from "@/types/domain";

const cities = new Set<CoverageCity>(["amman", "irbid", "zarqa", "other"]);

function readRequired(formData: FormData, key: string) {
  const value = formData.get(key);

  return typeof value === "string" ? value.trim() : "";
}

function readOptional(formData: FormData, key: string) {
  const value = readRequired(formData, key);

  return value ? value : null;
}

function readQuantity(formData: FormData) {
  const value = Number(readRequired(formData, "quantity"));

  return Number.isInteger(value) && value > 0 ? value : null;
}

function shopError(path: string, message: string): never {
  redirect(authRedirect(path, "error", message));
}

async function getApprovedMerchantContext(returnPath: string) {
  const profile = await requireRole("merchant");

  if (profile.approvalStatus !== "approved") {
    shopError(returnPath, "Wholesale prices are available only for verified cosmetics businesses.");
  }

  const merchant = await getMerchantForProfile(profile.id);

  if (!merchant) {
    shopError(returnPath, "No approved merchant record was found for this account.");
  }

  const supabase = await createSupabaseServerClient();

  return { profile, merchant, supabase };
}

export async function addToCartAction(formData: FormData) {
  const productId = readRequired(formData, "productId");
  const quantity = readQuantity(formData);
  const returnPath = readRequired(formData, "returnPath") || routes.products;

  if (!productId || quantity === null) {
    shopError(returnPath, "Select a valid product quantity.");
  }

  const { merchant, supabase } = await getApprovedMerchantContext(returnPath);
  const { data: product, error: productError } = await supabase
    .from("merchant_product_catalog")
    .select("id,minimum_order_quantity,available_quantity")
    .eq("id", productId)
    .single();

  if (productError || !product) {
    shopError(returnPath, "Product is not available.");
  }

  if (quantity < (product.minimum_order_quantity ?? 1)) {
    shopError(returnPath, "Quantity must meet the minimum order quantity.");
  }

  if (quantity > (product.available_quantity ?? 0)) {
    shopError(returnPath, "Quantity exceeds available stock.");
  }

  const { data: cart, error: cartError } = await supabase
    .from("carts")
    .upsert({ merchant_id: merchant.id }, { onConflict: "merchant_id" })
    .select("id")
    .single();

  if (cartError || !cart) {
    shopError(returnPath, cartError?.message ?? "Cart could not be created.");
  }

  const { data: existingItem } = await supabase
    .from("cart_items")
    .select("id,quantity")
    .eq("cart_id", cart.id)
    .eq("product_id", productId)
    .maybeSingle();
  const nextQuantity = (existingItem?.quantity ?? 0) + quantity;

  if (nextQuantity > (product.available_quantity ?? 0)) {
    shopError(returnPath, "Cart quantity exceeds available stock.");
  }

  const { error } = await supabase.from("cart_items").upsert(
    {
      cart_id: cart.id,
      product_id: productId,
      quantity: nextQuantity,
    },
    { onConflict: "cart_id,product_id" },
  );

  if (error) {
    shopError(returnPath, error.message);
  }

  revalidatePath(routes.cart);
  redirect(authRedirect(routes.cart, "status", "Product added to cart."));
}

export async function updateCartItemAction(formData: FormData) {
  const cartItemId = readRequired(formData, "cartItemId");
  const quantity = readQuantity(formData);

  if (!cartItemId || quantity === null) {
    shopError(routes.cart, "Enter a valid cart quantity.");
  }

  const { supabase } = await getApprovedMerchantContext(routes.cart);
  const { error } = await supabase.from("cart_items").update({ quantity }).eq("id", cartItemId);

  if (error) {
    shopError(routes.cart, error.message);
  }

  revalidatePath(routes.cart);
}

export async function removeCartItemAction(formData: FormData) {
  const cartItemId = readRequired(formData, "cartItemId");

  if (!cartItemId) {
    shopError(routes.cart, "Cart item is required.");
  }

  const { supabase } = await getApprovedMerchantContext(routes.cart);
  const { error } = await supabase.from("cart_items").delete().eq("id", cartItemId);

  if (error) {
    shopError(routes.cart, error.message);
  }

  revalidatePath(routes.cart);
}

export async function checkoutCartAction(formData: FormData) {
  const cityValue = readRequired(formData, "deliveryCity");
  const deliveryCity = cities.has(cityValue as CoverageCity) ? (cityValue as CoverageCity) : "other";
  const deliveryArea = readRequired(formData, "deliveryArea");
  const deliveryAddress = readOptional(formData, "deliveryAddress");
  const notes = readOptional(formData, "notes");

  if (!deliveryArea) {
    shopError(routes.cart, "Delivery area is required.");
  }

  const { supabase } = await getApprovedMerchantContext(routes.cart);
  const { error } = await supabase.rpc("checkout_merchant_cart", {
    p_delivery_city: deliveryCity,
    p_delivery_area: deliveryArea,
    p_delivery_address: deliveryAddress,
    p_notes: notes,
  });

  if (error) {
    shopError(routes.cart, error.message);
  }

  revalidatePath(routes.cart);
  revalidatePath(routes.orders);
  redirect(authRedirect(routes.orders, "status", "Order submitted to supplier for review."));
}

export async function markNotificationReadAction(formData: FormData) {
  const notificationId = readRequired(formData, "notificationId");
  await requireAuth();
  const supabase = await createSupabaseServerClient();

  if (!notificationId) {
    shopError(routes.notifications, "Notification is required.");
  }

  const { error } = await supabase
    .from("notifications")
    .update({ read_at: new Date().toISOString() })
    .eq("id", notificationId);

  if (error) {
    shopError(routes.notifications, error.message);
  }

  revalidatePath(routes.notifications);
}
