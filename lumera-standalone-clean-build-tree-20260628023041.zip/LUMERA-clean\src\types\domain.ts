export type UserRole = "merchant" | "supplier" | "admin";

export type ApprovalStatus = "pending" | "approved" | "rejected";

export type AuthProfile = {
  id: string;
  email: string | null;
  role: UserRole;
  approvalStatus: ApprovalStatus;
  displayName: string | null;
};

export type DeliveryEta = "same_day" | "24_hours" | "48_hours" | "custom";

export type OrderStatus =
  | "pending"
  | "approved"
  | "preparing"
  | "out_for_delivery"
  | "delivered"
  | "rejected";

export type ProductCategory =
  | "skincare"
  | "haircare"
  | "makeup"
  | "fragrances"
  | "beauty_tools"
  | "other";

export type CoverageCity = "amman" | "irbid" | "zarqa" | "other";
