import { submitSupplierApplicationAction } from "@/app/onboarding/actions";
import { AuthMessage } from "@/components/auth/auth-message";
import { getAuthMessage } from "@/lib/auth/messages";
import { requireRole } from "@/lib/auth/guards";

type SupplierOnboardingPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function SupplierOnboardingPage({ searchParams }: SupplierOnboardingPageProps) {
  const params = await searchParams;
  await requireRole("supplier");

  return (
    <main className="mx-auto max-w-3xl px-5 py-10">
      <section className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
        <AuthMessage error={getAuthMessage(params?.error)} />
        <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
          Supplier application
        </p>
        <h1 className="mt-3 text-3xl font-semibold">Supplier approval details</h1>
        <p className="mt-3 leading-7 text-[color:var(--muted)]">
          Submit company details for admin review. Product listing and order response tools unlock after
          approval.
        </p>
        <form action={submitSupplierApplicationAction} className="mt-6 grid gap-4" encType="multipart/form-data">
          <label className="block">
            <span className="text-sm font-medium">Company Name</span>
            <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="companyName" required />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Phone Number</span>
            <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="phoneNumber" required />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Business License Upload</span>
            <input accept="application/pdf,image/jpeg,image/png,image/webp" className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="businessLicense" required type="file" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Commercial Registration Upload</span>
            <input accept="application/pdf,image/jpeg,image/png,image/webp" className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="commercialRegistration" required type="file" />
          </label>
          <button className="rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white">
            Submit supplier application
          </button>
        </form>
      </section>
    </main>
  );
}
