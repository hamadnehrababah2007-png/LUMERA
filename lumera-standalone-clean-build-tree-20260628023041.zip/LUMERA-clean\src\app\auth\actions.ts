"use server";

import { redirect } from "next/navigation";

import { authRedirect } from "@/lib/auth/messages";
import { profileFromUser } from "@/lib/auth/profile";
import { roleHomeRoutes, routes } from "@/lib/routes";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { UserRole } from "@/types/domain";

function readRequired(formData: FormData, key: string) {
  const value = formData.get(key);

  return typeof value === "string" ? value.trim() : "";
}

function readSignupRole(formData: FormData): Exclude<UserRole, "admin"> {
  const value = readRequired(formData, "role");

  return value === "supplier" ? "supplier" : "merchant";
}

export async function signInAction(formData: FormData) {
  const email = readRequired(formData, "email");
  const password = readRequired(formData, "password");

  if (!email || !password) {
    redirect(authRedirect(routes.signIn, "error", "Email and password are required."));
  }

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });

  if (error || !data.user) {
    redirect(authRedirect(routes.signIn, "error", "Invalid email or password."));
  }

  const profile = profileFromUser(data.user);
  redirect(roleHomeRoutes[profile.role]);
}

export async function signUpAction(formData: FormData) {
  const email = readRequired(formData, "email");
  const password = readRequired(formData, "password");
  const displayName = readRequired(formData, "displayName");
  const role = readSignupRole(formData);

  if (!email || !password || !displayName) {
    redirect(authRedirect(routes.signUp, "error", "Name, email, and password are required."));
  }

  if (password.length < 8) {
    redirect(authRedirect(routes.signUp, "error", "Password must be at least 8 characters."));
  }

  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        display_name: displayName,
        role,
        approval_status: "pending",
      },
    },
  });

  if (error) {
    redirect(authRedirect(routes.signUp, "error", error.message));
  }

  redirect(authRedirect(routes.pendingApproval, "status", "Account created. Complete approval details next."));
}
