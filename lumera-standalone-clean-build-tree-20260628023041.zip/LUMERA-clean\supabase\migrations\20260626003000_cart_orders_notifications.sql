create function public.checkout_merchant_cart(
  p_delivery_city public.coverage_city,
  p_delivery_area text,
  p_delivery_address text default null,
  p_notes text default null
)
returns setof uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  merchant_record public.merchants;
  cart_record public.carts;
  supplier_record record;
  order_id uuid;
  item_record record;
begin
  if not public.is_approved_merchant() then
    raise exception 'Only approved merchants can place orders.';
  end if;

  select * into merchant_record
  from public.merchants
  where profile_id = auth.uid();

  if merchant_record.id is null then
    raise exception 'Merchant record not found.';
  end if;

  select * into cart_record
  from public.carts
  where merchant_id = merchant_record.id
  for update;

  if cart_record.id is null then
    raise exception 'Cart is empty.';
  end if;

  if not exists (select 1 from public.cart_items where cart_id = cart_record.id) then
    raise exception 'Cart is empty.';
  end if;

  if exists (
    select 1
    from public.cart_items
    join public.products on products.id = cart_items.product_id
    where cart_items.cart_id = cart_record.id
    and (
      products.is_active = false
      or cart_items.quantity < products.minimum_order_quantity
      or cart_items.quantity > products.available_quantity
    )
  ) then
    raise exception 'Cart contains unavailable products or quantities below MOQ.';
  end if;

  for supplier_record in
    select products.supplier_id, sum(cart_items.quantity * products.wholesale_price) as supplier_total
    from public.cart_items
    join public.products on products.id = cart_items.product_id
    where cart_items.cart_id = cart_record.id
    group by products.supplier_id
  loop
    insert into public.orders (
      merchant_id,
      supplier_id,
      status,
      delivery_city,
      delivery_area,
      delivery_address,
      notes,
      total_amount
    )
    values (
      merchant_record.id,
      supplier_record.supplier_id,
      'pending',
      p_delivery_city,
      p_delivery_area,
      p_delivery_address,
      p_notes,
      supplier_record.supplier_total
    )
    returning id into order_id;

    for item_record in
      select
        cart_items.product_id,
        cart_items.quantity,
        products.name_en,
        products.brand,
        products.wholesale_price
      from public.cart_items
      join public.products on products.id = cart_items.product_id
      where cart_items.cart_id = cart_record.id
      and products.supplier_id = supplier_record.supplier_id
      for update of products
    loop
      insert into public.order_items (
        order_id,
        product_id,
        product_name,
        brand,
        unit_price,
        quantity,
        line_total
      )
      values (
        order_id,
        item_record.product_id,
        item_record.name_en,
        item_record.brand,
        item_record.wholesale_price,
        item_record.quantity,
        item_record.quantity * item_record.wholesale_price
      );

      update public.products
      set available_quantity = available_quantity - item_record.quantity
      where id = item_record.product_id;
    end loop;

    insert into public.notifications (recipient_id, type, title, body)
    select
      suppliers.profile_id,
      'supplier_order',
      'New wholesale order',
      'A merchant placed a new wholesale order for your products.'
    from public.suppliers
    where suppliers.id = supplier_record.supplier_id;

    return next order_id;
  end loop;

  delete from public.cart_items where cart_id = cart_record.id;
end;
$$;

grant execute on function public.checkout_merchant_cart(public.coverage_city, text, text, text) to authenticated;
