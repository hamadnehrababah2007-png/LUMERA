import type { Metadata } from "next";

import "./globals.css";

export const metadata: Metadata = {
  title: "Lumera",
  description: "Private B2B wholesale cosmetics marketplace for Jordan.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
