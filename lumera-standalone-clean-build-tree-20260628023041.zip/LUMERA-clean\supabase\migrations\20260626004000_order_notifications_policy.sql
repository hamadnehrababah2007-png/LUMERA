create policy "Suppliers can create order status notifications"
on public.notifications for insert
to authenticated
with check (
  type = 'order_status'
  and public.current_user_role() = 'supplier'
  and exists (
    select 1
    from public.suppliers
    join public.orders on orders.supplier_id = suppliers.id
    join public.merchants on merchants.id = orders.merchant_id
    where suppliers.profile_id = auth.uid()
    and merchants.profile_id = notifications.recipient_id
  )
);
