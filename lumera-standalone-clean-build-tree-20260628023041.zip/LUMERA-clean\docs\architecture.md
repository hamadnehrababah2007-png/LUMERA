# Lumera MVP Architecture

Lumera is a private B2B wholesale cosmetics marketplace for verified cosmetics businesses in Jordan.

## Product Boundaries

- The marketplace is closed to approved business users.
- Unverified users can see only product image, product name, brand, and category.
- Wholesale prices, inventory, cart, and ordering require approved merchant access.
- Suppliers manage their own products, prices, stock, delivery ETAs, and coverage areas.
- Admins manage approvals, categories, products, users, and order visibility.

## Technical Stack

- Frontend: Next.js, TypeScript, Tailwind CSS
- Backend: Supabase Auth, Supabase Postgres, Supabase Storage
- Deployment: Vercel

## Application Areas

- Public limited catalog
- Merchant registration and dashboard
- Supplier registration and dashboard
- Admin dashboard
- Product catalog and search
- Cart and order flow

## Data Model Draft

- profiles
- merchant_applications
- supplier_applications
- suppliers
- merchants
- products
- categories
- coverage_areas
- product_coverage_areas
- carts
- cart_items
- orders
- order_items
- notifications

## Milestone 3 Data Model

Milestone 3 implements the data model as a Supabase migration under `supabase/migrations`.

Important implementation choices:

- `profiles` is the durable source for role and approval status.
- `merchant_applications` and `supplier_applications` store verification submissions.
- `business-documents` stores private uploaded approval documents.
- `product-images` stores public product media.
- Full `products` rows are protected because they include wholesale price and inventory.
- `product_public_cards` exposes the limited product data allowed for unapproved users.

## Access Strategy

Supabase Row Level Security will enforce role and approval rules. The app should also hide restricted UI affordances, but database policies are the source of truth for protected data.

## Authentication Strategy

Milestone 2 stores the selected account role and approval status in Supabase Auth user metadata so the UI can route users before the database schema exists.

Milestone 3 moves durable profile, application, and approval state into Postgres tables with Row Level Security policies. Auth metadata remains a convenience cache, not the source of truth for protected business data.

## Admin Operations

Milestone 4 implements the admin dashboard on top of the Supabase schema.

Admin actions are server actions guarded by `requireRole("admin")`. Approval and rejection flows call Supabase RPC functions so related database changes complete transactionally.

Approval flow:

- Approving a merchant application marks the application approved, updates the profile approval status, and upserts the `merchants` record.
- Approving a supplier application marks the application approved, updates the profile approval status, and upserts the `suppliers` record.
- Rejections preserve the application with a rejection reason and set the profile approval status to rejected.
- Notifications are created for approval and rejection outcomes.

## Supplier Operations

Milestone 5 implements the approved supplier workspace.

Supplier dashboard actions are server actions guarded by `requireRole("supplier")` and an approved profile status. Supplier product and order writes use the regular Supabase server client so Row Level Security continues to enforce ownership.

Supplier product listings include:

- product image
- English and optional Arabic product name
- brand
- category
- wholesale price
- available quantity
- minimum order quantity
- delivery ETA
- coverage areas

Suppliers can update their own products and respond to their own orders.

## Merchant Operations

Milestone 6 implements the approved merchant workspace.

Merchant dashboard access is guarded by `requireRole("merchant")`. Wholesale catalog access requires an approved merchant profile and a `merchants` record.

Unapproved merchants can only see limited product preview data from `product_public_cards`.

Approved merchants read from `merchant_product_catalog`, a security-invoker view that exposes supplier comparison data while preserving Row Level Security.

## Checkout And Notifications

Checkout is handled by the `checkout_merchant_cart` database function so stock validation, MOQ validation, supplier-split order creation, order-item snapshots, stock reduction, cart clearing, and supplier notifications happen transactionally.

The notifications table powers the signed-in notifications UI. Application approval/rejection, new supplier orders, and merchant order status changes create notification records.
