"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { requireRole } from "@/lib/auth/guards";
import { authRedirect } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Database } from "@/types/database";

type DeliveryEta = Database["public"]["Enums"]["delivery_eta"];
type OrderStatus = Database["public"]["Enums"]["order_status"];

const deliveryEtas = new Set<DeliveryEta>(["same_day", "24_hours", "48_hours", "custom"]);
const supplierOrderStatuses = new Set<OrderStatus>(["approved", "rejected", "preparing", "out_for_delivery", "delivered"]);

function readRequired(formData: FormData, key: string) {
  const value = formData.get(key);

  return typeof value === "string" ? value.trim() : "";
}

function readOptional(formData: FormData, key: string) {
  const value = readRequired(formData, key);

  return value ? value : null;
}

function readNumber(formData: FormData, key: string) {
  const raw = readRequired(formData, key);
  const value = Number(raw);

  return Number.isFinite(value) ? value : null;
}

function readFile(formData: FormData, key: string) {
  const value = formData.get(key);

  return value instanceof File && value.size > 0 ? value : null;
}

function supplierError(message: string): never {
  redirect(authRedirect(routes.supplier, "error", message));
}

async function getSupplierContext() {
  const profile = await requireRole("supplier");

  if (profile.approvalStatus !== "approved") {
    supplierError("Supplier tools unlock after admin approval.");
  }

  const supabase = await createSupabaseServerClient();
  const { data: supplier, error } = await supabase
    .from("suppliers")
    .select("*")
    .eq("profile_id", profile.id)
    .maybeSingle();

  if (error) {
    supplierError(error.message);
  }

  if (!supplier) {
    supplierError("No approved supplier record was found for this account.");
  }

  return { profile, supplier, supabase };
}

async function uploadProductImage(supplierId: string, file: File) {
  const supabase = await createSupabaseServerClient();
  const extension = file.name.split(".").pop()?.toLowerCase() ?? "bin";
  const path = `${supplierId}/${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from("product-images").upload(path, file, {
    contentType: file.type || "application/octet-stream",
    upsert: false,
  });

  if (error) {
    throw new Error(error.message);
  }

  return path;
}

async function replaceProductCoverage(productId: string, coverageAreaIds: string[]) {
  const supabase = await createSupabaseServerClient();
  const { error: deleteError } = await supabase
    .from("product_coverage_areas")
    .delete()
    .eq("product_id", productId);

  if (deleteError) {
    throw new Error(deleteError.message);
  }

  if (coverageAreaIds.length === 0) {
    return;
  }

  const { error: insertError } = await supabase.from("product_coverage_areas").insert(
    coverageAreaIds.map((coverageAreaId) => ({
      product_id: productId,
      coverage_area_id: coverageAreaId,
    })),
  );

  if (insertError) {
    throw new Error(insertError.message);
  }
}

export async function createSupplierProductAction(formData: FormData) {
  const { supplier, supabase } = await getSupplierContext();
  const nameEn = readRequired(formData, "nameEn");
  const nameAr = readOptional(formData, "nameAr");
  const brand = readRequired(formData, "brand");
  const categoryId = readRequired(formData, "categoryId");
  const wholesalePrice = readNumber(formData, "wholesalePrice");
  const availableQuantity = readNumber(formData, "availableQuantity");
  const minimumOrderQuantity = readNumber(formData, "minimumOrderQuantity");
  const deliveryEtaValue = readRequired(formData, "deliveryEta");
  const deliveryEta = deliveryEtas.has(deliveryEtaValue as DeliveryEta) ? (deliveryEtaValue as DeliveryEta) : "24_hours";
  const customDeliveryEta = readOptional(formData, "customDeliveryEta");
  const coverageAreaIds = formData.getAll("coverageAreaIds").filter((value): value is string => typeof value === "string");
  const image = readFile(formData, "image");

  if (!nameEn || !brand || !categoryId || wholesalePrice === null || availableQuantity === null || minimumOrderQuantity === null || !image) {
    supplierError("Product name, image, brand, category, price, stock, and MOQ are required.");
  }

  if (minimumOrderQuantity <= 0 || availableQuantity < 0 || wholesalePrice < 0) {
    supplierError("Price, stock, and minimum order quantity must be valid positive values.");
  }

  try {
    const imagePath = await uploadProductImage(supplier.id, image);
    const { data: product, error } = await supabase
      .from("products")
      .insert({
        supplier_id: supplier.id,
        category_id: categoryId,
        name_en: nameEn,
        name_ar: nameAr,
        image_path: imagePath,
        brand,
        wholesale_price: wholesalePrice,
        available_quantity: availableQuantity,
        minimum_order_quantity: minimumOrderQuantity,
        delivery_eta: deliveryEta,
        custom_delivery_eta: deliveryEta === "custom" ? customDeliveryEta : null,
      })
      .select("id")
      .single();

    if (error || !product) {
      throw new Error(error?.message ?? "Product could not be created.");
    }

    await replaceProductCoverage(product.id, coverageAreaIds);
  } catch (error) {
    supplierError(error instanceof Error ? error.message : "Product could not be created.");
  }

  revalidatePath(routes.supplier);
}

export async function updateSupplierProductAction(formData: FormData) {
  const { supplier, supabase } = await getSupplierContext();
  const productId = readRequired(formData, "productId");
  const wholesalePrice = readNumber(formData, "wholesalePrice");
  const availableQuantity = readNumber(formData, "availableQuantity");
  const minimumOrderQuantity = readNumber(formData, "minimumOrderQuantity");
  const deliveryEtaValue = readRequired(formData, "deliveryEta");
  const deliveryEta = deliveryEtas.has(deliveryEtaValue as DeliveryEta) ? (deliveryEtaValue as DeliveryEta) : "24_hours";
  const customDeliveryEta = readOptional(formData, "customDeliveryEta");
  const coverageAreaIds = formData.getAll("coverageAreaIds").filter((value): value is string => typeof value === "string");

  if (!productId || wholesalePrice === null || availableQuantity === null || minimumOrderQuantity === null) {
    supplierError("Product, price, stock, and MOQ are required.");
  }

  if (minimumOrderQuantity <= 0 || availableQuantity < 0 || wholesalePrice < 0) {
    supplierError("Price, stock, and minimum order quantity must be valid positive values.");
  }

  const { error } = await supabase
    .from("products")
    .update({
      wholesale_price: wholesalePrice,
      available_quantity: availableQuantity,
      minimum_order_quantity: minimumOrderQuantity,
      delivery_eta: deliveryEta,
      custom_delivery_eta: deliveryEta === "custom" ? customDeliveryEta : null,
    })
    .eq("id", productId)
    .eq("supplier_id", supplier.id);

  if (error) {
    supplierError(error.message);
  }

  try {
    await replaceProductCoverage(productId, coverageAreaIds);
  } catch (coverageError) {
    supplierError(coverageError instanceof Error ? coverageError.message : "Coverage areas could not be updated.");
  }

  revalidatePath(routes.supplier);
}

export async function toggleSupplierProductAction(formData: FormData) {
  const { supplier, supabase } = await getSupplierContext();
  const productId = readRequired(formData, "productId");
  const isActive = readRequired(formData, "isActive") === "true";
  const { error } = await supabase
    .from("products")
    .update({ is_active: !isActive })
    .eq("id", productId)
    .eq("supplier_id", supplier.id);

  if (error) {
    supplierError(error.message);
  }

  revalidatePath(routes.supplier);
}

export async function updateSupplierOrderStatusAction(formData: FormData) {
  const { supplier, supabase } = await getSupplierContext();
  const orderId = readRequired(formData, "orderId");
  const statusValue = readRequired(formData, "status");

  if (!supplierOrderStatuses.has(statusValue as OrderStatus)) {
    supplierError("Invalid order status.");
  }

  const status = statusValue as OrderStatus;
  const timestamp = new Date().toISOString();
  const { data: order, error: fetchError } = await supabase
    .from("orders")
    .select("id,merchant_id")
    .eq("id", orderId)
    .eq("supplier_id", supplier.id)
    .single();

  if (fetchError || !order) {
    supplierError("Order could not be found.");
  }

  const { error } = await supabase
    .from("orders")
    .update({
      status,
      accepted_at: status === "approved" ? timestamp : undefined,
      rejected_at: status === "rejected" ? timestamp : undefined,
    })
    .eq("id", orderId)
    .eq("supplier_id", supplier.id);

  if (error) {
    supplierError(error.message);
  }

  const { data: merchant } = await supabase
    .from("merchants")
    .select("profile_id")
    .eq("id", order.merchant_id)
    .single();

  if (merchant) {
    await supabase.from("notifications").insert({
      recipient_id: merchant.profile_id,
      type: "order_status",
      title: "Order status updated",
      body: `Your order ${order.id.slice(0, 8)} is now ${status.replaceAll("_", " ")}.`,
    });
  }

  revalidatePath(routes.supplier);
}
