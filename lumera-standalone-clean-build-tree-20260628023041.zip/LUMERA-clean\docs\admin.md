# Admin Dashboard

Milestone 4 implements the first operational admin workspace.

## Sections

- Platform metrics
- Merchant application review
- Supplier application review
- User management
- Category management
- Product moderation
- Order management

## Approval Behavior

Approval and rejection flows are implemented as Supabase RPC functions so related updates run in one database transaction.

Merchant approval:

- updates `merchant_applications.status`
- updates `profiles.approval_status`
- creates or updates a `merchants` record
- creates an approval notification

Supplier approval:

- updates `supplier_applications.status`
- updates `profiles.approval_status`
- creates or updates a `suppliers` record
- creates an approval notification

Rejected applications keep their application row and store the rejection reason.

## Product Management

Admins can edit marketplace product fields required for operations:

- Product name
- Brand
- Category
- Wholesale price
- Available quantity
- Minimum order quantity
- Delivery ETA
- Custom ETA

Admin product removal is implemented as a soft moderation action by toggling `products.is_active`. This preserves product history for future orders and reporting.

## Order Management

Admins can update order status across the PRD-defined status set:

- Pending
- Approved
- Preparing
- Out For Delivery
- Delivered
- Rejected
