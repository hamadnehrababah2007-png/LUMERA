import Link from "next/link";
import type { ReactNode } from "react";

import { roleHomeRoutes, routes } from "@/lib/routes";
import type { AuthProfile } from "@/types/domain";

type ShopShellProps = {
  profile: AuthProfile;
  title: string;
  description: string;
  children: ReactNode;
};

export function ShopShell({ profile, title, description, children }: ShopShellProps) {
  return (
    <main className="min-h-screen">
      <header className="border-b border-[color:var(--line)] bg-[color:var(--panel)]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
          <div>
            <Link className="text-xl font-semibold" href={routes.home}>
              Lumera
            </Link>
            <p className="mt-1 text-sm text-[color:var(--muted)]">{profile.role} workspace</p>
          </div>
          <nav className="flex flex-wrap items-center gap-2 text-sm">
            <Link className="rounded border border-[color:var(--line)] bg-white px-3 py-2" href={roleHomeRoutes[profile.role]}>
              Dashboard
            </Link>
            {profile.role === "merchant" ? (
              <>
                <Link className="rounded border border-[color:var(--line)] bg-white px-3 py-2" href={routes.products}>
                  Products
                </Link>
                <Link className="rounded border border-[color:var(--line)] bg-white px-3 py-2" href={routes.cart}>
                  Cart
                </Link>
                <Link className="rounded border border-[color:var(--line)] bg-white px-3 py-2" href={routes.orders}>
                  Orders
                </Link>
              </>
            ) : null}
            <Link className="rounded border border-[color:var(--line)] bg-white px-3 py-2" href={routes.notifications}>
              Notifications
            </Link>
            <Link className="rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white" href={routes.signOut}>
              Sign out
            </Link>
          </nav>
        </div>
      </header>
      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-8 sm:px-8">
        <div className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
            Lumera marketplace
          </p>
          <h1 className="mt-3 text-3xl font-semibold">{title}</h1>
          <p className="mt-3 max-w-3xl leading-7 text-[color:var(--muted)]">{description}</p>
        </div>
        {children}
      </section>
    </main>
  );
}
