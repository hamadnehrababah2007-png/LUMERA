# Production Readiness

This final QA pass verifies Lumera against the V1 MVP PRD.

## Completed MVP Requirements

- Private B2B cosmetics marketplace for Jordan
- Merchant, supplier, and admin roles
- Approval-gated wholesale prices, inventory, cart, and ordering
- Limited unverified product preview with image, name, brand, and category only
- Supabase Auth email/password authentication
- Merchant registration with store name, owner name, phone, city, area, business license, commercial registration, and optional Instagram page
- Supplier registration with company name, phone, business license, and commercial registration
- Pending, approved, and rejected application statuses
- Admin approval and rejection for merchants and suppliers
- Supplier product listing creation and management
- Product fields for name, image, brand, category, wholesale price, stock, MOQ, delivery ETA, and coverage areas
- Admin-managed categories
- Merchant catalog search by English name, Arabic name, brand, and supplier
- Merchant category and availability filters
- Product detail page for approved merchants
- Cart add, update, remove, MOQ validation, and stock validation
- Supplier-split order placement
- Supplier order acceptance, rejection, preparation, delivery, and delivered statuses
- Merchant order tracking
- Admin user, product, category, and order management
- Notification inbox with read state
- Supabase schema, RLS policies, storage buckets, views, and RPC workflows
- Responsive Next.js, TypeScript, Tailwind CSS application prepared for Vercel deployment

## Final QA Notes

- Route guards enforce role-specific access for merchant, supplier, and admin workspaces.
- RLS policies restrict wholesale product data to approved merchants, admins, and owning suppliers.
- Supplier-created order status notifications are restricted to merchants who have an order with that supplier.
- Checkout runs through a database RPC to keep order creation, stock decrementing, supplier splitting, cart clearing, and notifications consistent.
- Product images use the public product-images bucket; business documents use the private business-documents bucket.

## Deployment Checklist

- Configure Supabase project environment variables in Vercel.
- Apply all migrations in order.
- Confirm Supabase Storage buckets exist.
- Bootstrap the first admin user.
- Run `pnpm lint`, `pnpm typecheck`, and `pnpm build` before production release.
- Smoke test admin approval, supplier product creation, merchant checkout, supplier order response, and merchant notifications.

