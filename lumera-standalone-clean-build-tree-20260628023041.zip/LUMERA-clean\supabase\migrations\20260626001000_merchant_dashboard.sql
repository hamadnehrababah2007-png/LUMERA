create view public.merchant_product_catalog
with (security_invoker = true)
as
select
  products.id,
  products.name_en,
  products.name_ar,
  products.image_path,
  products.brand,
  products.wholesale_price,
  products.available_quantity,
  products.minimum_order_quantity,
  products.delivery_eta,
  products.custom_delivery_eta,
  products.is_active,
  products.created_at,
  categories.id as category_id,
  categories.name_en as category_name_en,
  categories.name_ar as category_name_ar,
  suppliers.id as supplier_id,
  suppliers.company_name as supplier_name,
  coalesce(
    array_agg(coverage_areas.label order by coverage_areas.label)
      filter (where coverage_areas.id is not null),
    array[]::text[]
  ) as coverage_area_labels
from public.products
join public.categories on categories.id = products.category_id
join public.suppliers on suppliers.id = products.supplier_id
left join public.product_coverage_areas on product_coverage_areas.product_id = products.id
left join public.coverage_areas on coverage_areas.id = product_coverage_areas.coverage_area_id
where products.is_active = true
and categories.is_active = true
group by products.id, categories.id, suppliers.id;

create policy "Approved merchants can view suppliers"
on public.suppliers for select
to authenticated
using (
  public.is_admin()
  or public.is_approved_merchant()
  or profile_id = auth.uid()
);

grant select on public.merchant_product_catalog to authenticated;
