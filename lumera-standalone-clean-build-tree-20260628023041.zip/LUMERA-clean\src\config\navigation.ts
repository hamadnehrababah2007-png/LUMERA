export const primaryNavigation = [
  { label: "Catalog", href: "#catalog" },
  { label: "Orders", href: "#orders" },
  { label: "Admin", href: "#admin" },
  { label: "Suppliers", href: "#suppliers" },
] as const;
