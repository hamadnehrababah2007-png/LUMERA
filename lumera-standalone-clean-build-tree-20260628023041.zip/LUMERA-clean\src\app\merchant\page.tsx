import Link from "next/link";
import type { ReactNode } from "react";

import { AuthMessage } from "@/components/auth/auth-message";
import { StatusPill } from "@/components/admin/status-pill";
import { requireRole } from "@/lib/auth/guards";
import { getAuthMessage } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";
import { getMerchantDashboardData } from "@/lib/merchant/queries";
import type {
  CategoryRow,
  MerchantCatalogProduct,
  MerchantOrder,
  PublicProductCard,
} from "@/lib/merchant/queries";

type MerchantDashboardPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

function readParam(params: Record<string, string | string[] | undefined> | undefined, key: string) {
  const value = params?.[key];

  return typeof value === "string" ? value.trim() : "";
}

function MerchantHeader({ email }: { email: string | null }) {
  return (
    <header className="border-b border-[color:var(--line)] bg-[color:var(--panel)]">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
        <div>
          <Link className="text-xl font-semibold" href={routes.home}>
            Lumera
          </Link>
          <p className="mt-1 text-sm text-[color:var(--muted)]">Merchant workspace</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <span className="rounded border border-[color:var(--line)] bg-white px-3 py-2">{email}</span>
          <Link className="rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white" href={routes.signOut}>
            Sign out
          </Link>
        </div>
      </div>
    </header>
  );
}

function MerchantSection({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5 shadow-sm">
      <div className="border-b border-[color:var(--line)] pb-4">
        <h2 className="text-xl font-semibold">{title}</h2>
        <p className="mt-2 text-sm leading-6 text-[color:var(--muted)]">{description}</p>
      </div>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded border border-dashed border-[color:var(--line)] bg-white px-4 py-8 text-center text-sm text-[color:var(--muted)]">
      {label}
    </div>
  );
}

function MerchantApprovalGate({
  approvalStatus,
  hasMerchantRecord,
}: {
  approvalStatus: string;
  hasMerchantRecord: boolean;
}) {
  if (approvalStatus === "approved" && hasMerchantRecord) {
    return null;
  }

  return (
    <section className="rounded border border-amber-200 bg-amber-50 p-5 text-amber-900">
      <h2 className="font-semibold">Wholesale prices are available only for verified cosmetics businesses.</h2>
      <p className="mt-2 text-sm leading-6">
        Complete your merchant application and wait for admin approval to unlock prices, inventory, supplier
        details, cart access, and ordering.
      </p>
      <Link className="mt-4 inline-flex rounded bg-[color:var(--brand)] px-4 py-2 text-sm font-semibold text-white" href={routes.merchantOnboarding}>
        Complete merchant application
      </Link>
    </section>
  );
}

function MerchantStats({
  products,
  orders,
}: {
  products: MerchantCatalogProduct[];
  orders: MerchantOrder[];
}) {
  const stats = [
    { label: "Available products", value: products.length },
    { label: "In stock", value: products.filter((product) => (product.available_quantity ?? 0) > 0).length },
    { label: "Suppliers", value: new Set(products.map((product) => product.supplier_id).filter(Boolean)).size },
    { label: "Open orders", value: orders.filter((order) => order.status !== "delivered" && order.status !== "rejected").length },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <article className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-4 shadow-sm" key={stat.label}>
          <p className="text-2xl font-semibold">{stat.value}</p>
          <p className="mt-1 text-sm text-[color:var(--muted)]">{stat.label}</p>
        </article>
      ))}
    </div>
  );
}

function LimitedProductPreview({ products }: { products: PublicProductCard[] }) {
  if (products.length === 0) {
    return <EmptyState label="No public product previews are available yet." />;
  }

  return (
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
      {products.map((product) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={product.id}>
          <p className="text-sm font-semibold text-[color:var(--accent)]">{product.category_name_en}</p>
          <h3 className="mt-2 font-semibold">{product.name_en}</h3>
          <p className="mt-1 text-sm text-[color:var(--muted)]">{product.brand}</p>
          <p className="mt-4 rounded bg-[#efe7dc] px-3 py-2 text-sm text-[color:var(--muted)]">
            Prices, inventory, cart, and orders unlock after verification.
          </p>
        </article>
      ))}
    </div>
  );
}

function CatalogFilters({
  categories,
  query,
  categoryId,
  availableOnly,
}: {
  categories: CategoryRow[];
  query: string;
  categoryId: string;
  availableOnly: boolean;
}) {
  return (
    <form className="grid gap-3 rounded border border-[color:var(--line)] bg-white p-4 md:grid-cols-[1fr_220px_auto_auto]" method="get">
      <input
        className="rounded border border-[color:var(--line)] px-3 py-2 text-sm"
        defaultValue={query}
        name="q"
        placeholder="Search product, Arabic name, brand, or supplier"
      />
      <select className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" defaultValue={categoryId} name="category">
        <option value="">All categories</option>
        {categories.map((category) => (
          <option key={category.id} value={category.id}>
            {category.name_en}
          </option>
        ))}
      </select>
      <label className="flex items-center gap-2 rounded border border-[color:var(--line)] px-3 py-2 text-sm">
        <input defaultChecked={availableOnly} name="available" type="checkbox" value="true" />
        <span>Available only</span>
      </label>
      <button className="rounded bg-[color:var(--brand)] px-4 py-2 text-sm font-semibold text-white">
        Search
      </button>
    </form>
  );
}

function ProductCatalog({ products }: { products: MerchantCatalogProduct[] }) {
  if (products.length === 0) {
    return <EmptyState label="No products match the selected filters." />;
  }

  return (
    <div className="grid gap-4">
      {products.map((product) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={product.id}>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-semibold text-[color:var(--accent)]">{product.category_name_en}</p>
              <h3 className="mt-2 text-lg font-semibold">{product.name_en}</h3>
              {product.name_ar ? <p className="mt-1 text-sm text-[color:var(--muted)]">{product.name_ar}</p> : null}
              <p className="mt-2 text-sm text-[color:var(--muted)]">
                {product.brand} - Supplier: {product.supplier_name}
              </p>
              <p className="mt-1 text-sm text-[color:var(--muted)]">
                Coverage: {product.coverage_area_labels?.join(", ") || "Not specified"}
              </p>
            </div>
            <div className="min-w-44 rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-4 text-sm">
              <p className="text-2xl font-semibold">{(product.wholesale_price ?? 0).toFixed(3)} JOD</p>
              <p className="mt-2 text-[color:var(--muted)]">Stock: {product.available_quantity ?? 0}</p>
              <p className="text-[color:var(--muted)]">MOQ: {product.minimum_order_quantity ?? 1}</p>
              <p className="text-[color:var(--muted)]">
                ETA: {product.delivery_eta?.replaceAll("_", " ") ?? "Not specified"}
              </p>
              {product.id ? (
                <Link
                  className="mt-4 inline-flex w-full justify-center rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white"
                  href={`${routes.products}/${product.id}`}
                >
                  View details
                </Link>
              ) : null}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

function OrderTracking({ orders }: { orders: MerchantOrder[] }) {
  if (orders.length === 0) {
    return <EmptyState label="No merchant orders yet." />;
  }

  return (
    <div className="grid gap-4">
      {orders.map((order) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={order.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">Order {order.id.slice(0, 8)}</h3>
                <StatusPill value={order.status} />
              </div>
              <p className="mt-2 text-sm text-[color:var(--muted)]">
                {order.delivery_city} / {order.delivery_area} - {order.total_amount.toFixed(3)} JOD
              </p>
              {order.items.length > 0 ? (
                <ul className="mt-3 grid gap-1 text-sm text-[color:var(--muted)]">
                  {order.items.map((item) => (
                    <li key={item.id}>
                      {item.quantity} x {item.product_name} - {item.line_total.toFixed(3)} JOD
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

export default async function MerchantDashboardPage({ searchParams }: MerchantDashboardPageProps) {
  const params = await searchParams;
  const profile = await requireRole("merchant");
  const query = readParam(params, "q");
  const categoryId = readParam(params, "category");
  const availableOnly = readParam(params, "available") === "true";
  const data = await getMerchantDashboardData(profile.id, {
    query,
    categoryId,
    availableOnly,
  });
  const approved = profile.approvalStatus === "approved" && Boolean(data.merchant);

  return (
    <main className="min-h-screen">
      <MerchantHeader email={profile.email} />
      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-8 sm:px-8">
        <div className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
            Merchant purchasing
          </p>
          <h1 className="mt-3 text-3xl font-semibold">Discover and compare wholesale cosmetics</h1>
          <p className="mt-3 max-w-3xl leading-7 text-[color:var(--muted)]">
            Search products, compare suppliers, review wholesale price and availability, and track orders from
            one verified business workspace.
          </p>
        </div>

        <AuthMessage error={getAuthMessage(params?.error)} status={getAuthMessage(params?.status)} />
        <MerchantApprovalGate approvalStatus={profile.approvalStatus} hasMerchantRecord={Boolean(data.merchant)} />

        {approved ? (
          <>
            <MerchantStats orders={data.orders} products={data.products} />
            <MerchantSection
              description="Search by product name, Arabic name, brand, or supplier. Filter by category and availability."
              title="Wholesale catalog"
            >
              <div className="grid gap-4">
                <CatalogFilters
                  availableOnly={availableOnly}
                  categories={data.categories}
                  categoryId={categoryId}
                  query={query}
                />
                <ProductCatalog products={data.products} />
              </div>
            </MerchantSection>
            <MerchantSection description="Review order status updates from suppliers." title="Order tracking">
              <OrderTracking orders={data.orders} />
            </MerchantSection>
          </>
        ) : (
          <MerchantSection
            description="Unverified users can browse only public product information."
            title="Limited product preview"
          >
            <LimitedProductPreview products={data.publicProducts} />
          </MerchantSection>
        )}
      </section>
    </main>
  );
}
