type AuthMessageProps = {
  error?: string | null;
  status?: string | null;
};

export function AuthMessage({ error, status }: AuthMessageProps) {
  if (!error && !status) {
    return null;
  }

  return (
    <div
      className={`rounded border px-4 py-3 text-sm ${
        error
          ? "border-red-200 bg-red-50 text-red-800"
          : "border-emerald-200 bg-emerald-50 text-emerald-800"
      }`}
      role="status"
    >
      {error ?? status}
    </div>
  );
}
