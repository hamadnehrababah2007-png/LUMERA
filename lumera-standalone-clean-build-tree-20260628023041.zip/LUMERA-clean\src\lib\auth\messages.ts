export function getAuthMessage(value: string | string[] | undefined) {
  if (!value || Array.isArray(value)) {
    return null;
  }

  return value;
}

export function authRedirect(path: string, messageKey: "error" | "status", message: string) {
  const params = new URLSearchParams({ [messageKey]: message });

  return `${path}?${params.toString()}`;
}
