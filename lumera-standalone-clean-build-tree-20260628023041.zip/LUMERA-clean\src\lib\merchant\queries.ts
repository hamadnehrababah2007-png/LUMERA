import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Database } from "@/types/database";

export type MerchantRow = Database["public"]["Tables"]["merchants"]["Row"];
export type CategoryRow = Database["public"]["Tables"]["categories"]["Row"];
export type MerchantCatalogProduct = Database["public"]["Views"]["merchant_product_catalog"]["Row"];
export type PublicProductCard = Database["public"]["Views"]["product_public_cards"]["Row"];
export type MerchantOrder = Database["public"]["Tables"]["orders"]["Row"] & {
  items: Database["public"]["Tables"]["order_items"]["Row"][];
};

export type MerchantCatalogFilters = {
  query?: string;
  categoryId?: string;
  availableOnly?: boolean;
};

function cleanSearchTerm(value: string) {
  return value.replace(/[%_,()]/g, " ").replace(/\s+/g, " ").trim();
}

async function unwrap<T>(promise: PromiseLike<{ data: T | null; error: { message: string } | null }>) {
  const { data, error } = await promise;

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function getMerchantDashboardData(profileId: string, filters: MerchantCatalogFilters = {}) {
  const supabase = await createSupabaseServerClient();
  const merchant = await unwrap(
    supabase.from("merchants").select("*").eq("profile_id", profileId).maybeSingle(),
  );
  const categories = await unwrap(
    supabase
      .from("categories")
      .select("*")
      .eq("is_active", true)
      .order("name_en", { ascending: true }),
  );
  const publicProducts = await unwrap(
    supabase
      .from("product_public_cards")
      .select("id,name_en,name_ar,image_path,brand,category_name_en,category_name_ar,created_at")
      .order("created_at", { ascending: false })
      .limit(12),
  );

  if (!merchant) {
    return {
      merchant: null,
      categories: categories ?? [],
      publicProducts: publicProducts ?? [],
      products: [],
      orders: [],
    };
  }

  let catalogQuery = supabase
    .from("merchant_product_catalog")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(40);

  const searchTerm = filters.query ? cleanSearchTerm(filters.query) : "";

  if (searchTerm) {
    catalogQuery = catalogQuery.or(
      `name_en.ilike.%${searchTerm}%,name_ar.ilike.%${searchTerm}%,brand.ilike.%${searchTerm}%,supplier_name.ilike.%${searchTerm}%`,
    );
  }

  if (filters.categoryId) {
    catalogQuery = catalogQuery.eq("category_id", filters.categoryId);
  }

  if (filters.availableOnly) {
    catalogQuery = catalogQuery.gt("available_quantity", 0);
  }

  const [products, orders] = await Promise.all([
    unwrap(catalogQuery),
    unwrap(
      supabase
        .from("orders")
        .select("*")
        .eq("merchant_id", merchant.id)
        .order("created_at", { ascending: false })
        .limit(20),
    ),
  ]);

  const orderRows = orders ?? [];
  const orderIds = orderRows.map((order) => order.id);
  const orderItems =
    orderIds.length > 0
      ? await unwrap(
          supabase
            .from("order_items")
            .select("*")
            .in("order_id", orderIds)
            .order("created_at", { ascending: true }),
        )
      : [];
  const itemsByOrder = new Map<string, Database["public"]["Tables"]["order_items"]["Row"][]>();

  for (const item of orderItems ?? []) {
    const existing = itemsByOrder.get(item.order_id) ?? [];
    existing.push(item);
    itemsByOrder.set(item.order_id, existing);
  }

  return {
    merchant,
    categories: categories ?? [],
    publicProducts: publicProducts ?? [],
    products: products ?? [],
    orders: orderRows.map((order) => ({
      ...order,
      items: itemsByOrder.get(order.id) ?? [],
    })),
  };
}
