# Lumera Database Setup

Milestone 3 adds the first Supabase schema for the MVP.

## Apply The Migration

Use the Supabase dashboard SQL editor or the Supabase CLI to apply:

```bash
supabase db push
```

The migration file is:

```text
supabase/migrations/20260625233000_initial_schema.sql
```

## Core Tables

- `profiles`
- `merchant_applications`
- `supplier_applications`
- `merchants`
- `suppliers`
- `categories`
- `coverage_areas`
- `products`
- `product_coverage_areas`
- `carts`
- `cart_items`
- `orders`
- `order_items`
- `notifications`

## Storage Buckets

- `product-images`: public bucket for supplier product images
- `business-documents`: private bucket for merchant and supplier verification documents

## Product Visibility

Full `products` rows include wholesale price, inventory, MOQ, and delivery details. Direct product access is limited to:

- approved merchants
- the supplier that owns the product
- admins

Unapproved authenticated users should read `product_public_cards`, which exposes only:

- image path
- product name
- brand
- category

Approved merchants read comparison-ready wholesale catalog data from `merchant_product_catalog`, a security-invoker view that includes supplier name, category, price, stock, MOQ, delivery ETA, and coverage labels while preserving Row Level Security.

## Checkout Function

`checkout_merchant_cart` performs the order placement workflow:

- verifies the current user is an approved merchant
- validates cart items against active products, MOQ, and available stock
- creates one order per supplier
- snapshots order items
- reduces product stock
- clears cart items
- notifies suppliers

## Auth Profile Source

Supabase Auth metadata remains useful during signup, but durable role and approval status now live in `profiles`.

The `on_auth_user_created` trigger creates a profile when a new Supabase Auth user is created.

## Admin Bootstrap

The first admin should be created manually in Supabase by updating a trusted user's profile:

```sql
update public.profiles
set role = 'admin', approval_status = 'approved'
where email = 'admin@example.com';
```

Replace the email before running this.
