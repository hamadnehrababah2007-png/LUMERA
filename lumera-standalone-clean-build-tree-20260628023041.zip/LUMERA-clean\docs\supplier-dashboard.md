# Supplier Dashboard

Milestone 5 implements the supplier workspace required by the PRD.

## Supplier Access

Supplier tools are available only after:

- the user role is `supplier`
- the profile approval status is `approved`
- a `suppliers` record exists for the account

Pending suppliers are routed to complete the supplier application.

## Product Management

Approved suppliers can:

- create product listings
- upload product images
- assign brand and category
- set wholesale price
- set available quantity
- set minimum order quantity
- set delivery ETA
- select coverage areas
- update price, stock, MOQ, ETA, and coverage
- deactivate or reactivate listings

Product images are uploaded to the `product-images` Supabase Storage bucket.

## Order Management

Approved suppliers can view incoming orders and update status to:

- Approved
- Rejected
- Preparing
- Out For Delivery
- Delivered

The dashboard displays order item summaries when available.
