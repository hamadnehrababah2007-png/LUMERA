import Link from "next/link";
import type { ReactNode } from "react";

import { routes } from "@/lib/routes";
import type { AuthProfile } from "@/types/domain";

type DashboardShellProps = {
  profile: AuthProfile;
  title: string;
  description: string;
  children: ReactNode;
};

export function DashboardShell({ profile, title, description, children }: DashboardShellProps) {
  return (
    <main className="min-h-screen">
      <header className="border-b border-[color:var(--line)] bg-[color:var(--panel)]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
          <Link className="text-xl font-semibold" href={routes.home}>
            Lumera
          </Link>
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <span className="rounded border border-[color:var(--line)] bg-white px-3 py-2">
              {profile.role} / {profile.approvalStatus}
            </span>
            <Link className="rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white" href={routes.signOut}>
              Sign out
            </Link>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
        <div className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
            {profile.email}
          </p>
          <h1 className="mt-3 text-3xl font-semibold">{title}</h1>
          <p className="mt-3 max-w-3xl leading-7 text-[color:var(--muted)]">{description}</p>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-3">{children}</div>
      </section>
    </main>
  );
}
