import type { User } from "@supabase/supabase-js";

import type { ApprovalStatus, AuthProfile, UserRole } from "@/types/domain";

const roles = new Set<UserRole>(["merchant", "supplier", "admin"]);
const approvalStatuses = new Set<ApprovalStatus>(["pending", "approved", "rejected"]);

export function normalizeRole(value: unknown): UserRole {
  return typeof value === "string" && roles.has(value as UserRole) ? (value as UserRole) : "merchant";
}

export function normalizeApprovalStatus(value: unknown): ApprovalStatus {
  return typeof value === "string" && approvalStatuses.has(value as ApprovalStatus)
    ? (value as ApprovalStatus)
    : "pending";
}

export function profileFromUser(user: User): AuthProfile {
  const metadata = user.user_metadata ?? {};

  return {
    id: user.id,
    email: user.email ?? null,
    role: normalizeRole(metadata.role),
    approvalStatus: normalizeApprovalStatus(metadata.approval_status),
    displayName:
      typeof metadata.display_name === "string"
        ? metadata.display_name
        : typeof metadata.full_name === "string"
          ? metadata.full_name
          : null,
  };
}
