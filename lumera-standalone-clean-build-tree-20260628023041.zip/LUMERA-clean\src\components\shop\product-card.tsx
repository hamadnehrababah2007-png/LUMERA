import Link from "next/link";

import { routes } from "@/lib/routes";
import { getPublicStorageUrl } from "@/lib/supabase/storage";
import type { MerchantCatalogProduct, PublicProductCard } from "@/lib/merchant/queries";

type ProductCardProps = {
  product: MerchantCatalogProduct | PublicProductCard;
  approved: boolean;
};

export function ProductCard({ product, approved }: ProductCardProps) {
  const name = product.name_en ?? "Unnamed product";
  const category = "category_name_en" in product ? product.category_name_en : null;
  const imageUrl = getPublicStorageUrl("product-images", product.image_path);
  const productId = product.id ?? "";

  return (
    <article className="rounded border border-[color:var(--line)] bg-white p-4 shadow-sm">
      <div className="mb-4 aspect-[4/3] overflow-hidden rounded border border-[color:var(--line)] bg-[color:var(--panel)]">
        {imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img alt={name} className="h-full w-full object-cover" src={imageUrl} />
        ) : (
          <div className="flex h-full items-center justify-center px-4 text-center text-sm text-[color:var(--muted)]">
            Product image
          </div>
        )}
      </div>
      <p className="text-sm font-semibold text-[color:var(--accent)]">{category ?? "Uncategorized"}</p>
      <h3 className="mt-2 text-lg font-semibold">{name}</h3>
      <p className="mt-1 text-sm text-[color:var(--muted)]">{product.brand}</p>
      {approved && "wholesale_price" in product ? (
        <div className="mt-4 rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-3 text-sm">
          <p className="text-xl font-semibold">{(product.wholesale_price ?? 0).toFixed(3)} JOD</p>
          <p className="mt-1 text-[color:var(--muted)]">Stock: {product.available_quantity ?? 0}</p>
          <p className="text-[color:var(--muted)]">MOQ: {product.minimum_order_quantity ?? 1}</p>
        </div>
      ) : (
        <p className="mt-4 rounded bg-[#efe7dc] px-3 py-2 text-sm text-[color:var(--muted)]">
          Wholesale prices are available only for verified cosmetics businesses.
        </p>
      )}
      {productId ? (
        <Link
          className="mt-4 inline-flex rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white"
          href={`${routes.products}/${productId}`}
        >
          View details
        </Link>
      ) : null}
    </article>
  );
}
