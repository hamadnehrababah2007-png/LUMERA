export function getPublicStorageUrl(bucket: string, path: string | null | undefined) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;

  if (!url || !path) {
    return null;
  }

  return `${url}/storage/v1/object/public/${bucket}/${path}`;
}
