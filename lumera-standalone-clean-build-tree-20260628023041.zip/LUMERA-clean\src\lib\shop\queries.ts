import { notFound } from "next/navigation";

import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Database } from "@/types/database";

export type MerchantRow = Database["public"]["Tables"]["merchants"]["Row"];
export type CategoryRow = Database["public"]["Tables"]["categories"]["Row"];
export type ProductDetail = Database["public"]["Views"]["merchant_product_catalog"]["Row"];
export type PublicProductCard = Database["public"]["Views"]["product_public_cards"]["Row"];
export type CartRow = Database["public"]["Tables"]["carts"]["Row"];
export type CartItemRow = Database["public"]["Tables"]["cart_items"]["Row"];
export type OrderRow = Database["public"]["Tables"]["orders"]["Row"];
export type OrderItemRow = Database["public"]["Tables"]["order_items"]["Row"];
export type NotificationRow = Database["public"]["Tables"]["notifications"]["Row"];

export type CartItemDetail = CartItemRow & {
  product: ProductDetail | null;
  lineTotal: number;
  belowMinimum: boolean;
  aboveStock: boolean;
};

export type OrderWithItems = OrderRow & {
  items: OrderItemRow[];
};

async function unwrap<T>(promise: PromiseLike<{ data: T | null; error: { message: string } | null }>) {
  const { data, error } = await promise;

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function getMerchantForProfile(profileId: string) {
  const supabase = await createSupabaseServerClient();

  return unwrap(supabase.from("merchants").select("*").eq("profile_id", profileId).maybeSingle());
}

export async function getProductDetail(productId: string, approved: boolean) {
  const supabase = await createSupabaseServerClient();

  if (approved) {
    const data = await unwrap(
      supabase
        .from("merchant_product_catalog")
        .select("*")
        .eq("id", productId)
        .maybeSingle(),
    );

    if (!data) {
      notFound();
    }

    return { product: data, limitedProduct: null };
  }

  const data = await unwrap(
    supabase
      .from("product_public_cards")
      .select("id,name_en,name_ar,image_path,brand,category_name_en,category_name_ar,created_at")
      .eq("id", productId)
      .maybeSingle(),
  );

  if (!data) {
    notFound();
  }

  return { product: null, limitedProduct: data };
}

export async function getCartDetails(merchantId: string) {
  const supabase = await createSupabaseServerClient();
  const cart = await unwrap(supabase.from("carts").select("*").eq("merchant_id", merchantId).maybeSingle());

  if (!cart) {
    return { cart: null, items: [], total: 0, hasInvalidItems: false };
  }

  const items = await unwrap(
    supabase
      .from("cart_items")
      .select("*")
      .eq("cart_id", cart.id)
      .order("created_at", { ascending: true }),
  );
  const productIds = (items ?? []).map((item) => item.product_id);
  const products =
    productIds.length > 0
      ? await unwrap(
          supabase
            .from("merchant_product_catalog")
            .select("*")
            .in("id", productIds),
        )
      : [];
  const productById = new Map((products ?? []).map((product) => [product.id, product]));
  const detailedItems: CartItemDetail[] = (items ?? []).map((item) => {
    const product = productById.get(item.product_id) ?? null;
    const lineTotal = item.quantity * (product?.wholesale_price ?? 0);
    const belowMinimum = product ? item.quantity < (product.minimum_order_quantity ?? 1) : true;
    const aboveStock = product ? item.quantity > (product.available_quantity ?? 0) : true;

    return { ...item, product, lineTotal, belowMinimum, aboveStock };
  });

  return {
    cart,
    items: detailedItems,
    total: detailedItems.reduce((sum, item) => sum + item.lineTotal, 0),
    hasInvalidItems: detailedItems.some((item) => item.belowMinimum || item.aboveStock || !item.product),
  };
}

export async function getMerchantOrders(merchantId: string) {
  const supabase = await createSupabaseServerClient();
  const orders = await unwrap(
    supabase
      .from("orders")
      .select("*")
      .eq("merchant_id", merchantId)
      .order("created_at", { ascending: false }),
  );
  const orderIds = (orders ?? []).map((order) => order.id);
  const orderItems =
    orderIds.length > 0
      ? await unwrap(
          supabase
            .from("order_items")
            .select("*")
            .in("order_id", orderIds)
            .order("created_at", { ascending: true }),
        )
      : [];
  const itemsByOrder = new Map<string, OrderItemRow[]>();

  for (const item of orderItems ?? []) {
    const existing = itemsByOrder.get(item.order_id) ?? [];
    existing.push(item);
    itemsByOrder.set(item.order_id, existing);
  }

  return (orders ?? []).map((order) => ({
    ...order,
    items: itemsByOrder.get(order.id) ?? [],
  }));
}

export async function getNotifications(profileId: string) {
  const supabase = await createSupabaseServerClient();

  return unwrap(
    supabase
      .from("notifications")
      .select("*")
      .eq("recipient_id", profileId)
      .order("created_at", { ascending: false })
      .limit(50),
  );
}
