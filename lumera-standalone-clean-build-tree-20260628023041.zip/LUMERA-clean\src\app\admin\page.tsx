import Link from "next/link";

import {
  approveMerchantApplicationAction,
  approveSupplierApplicationAction,
  createCategoryAction,
  rejectMerchantApplicationAction,
  rejectSupplierApplicationAction,
  toggleCategoryAction,
  toggleProductAction,
  updateAdminProductAction,
  updateOrderStatusAction,
} from "@/app/admin/actions";
import { AdminMessage } from "@/components/admin/admin-message";
import { AdminSection } from "@/components/admin/admin-section";
import { StatusPill } from "@/components/admin/status-pill";
import { requireRole } from "@/lib/auth/guards";
import { getAdminDashboardData } from "@/lib/admin/queries";
import { routes } from "@/lib/routes";
import type {
  CategoryRow,
  MerchantApplicationRow,
  OrderRow,
  ProductRow,
  ProfileRow,
  SupplierApplicationRow,
} from "@/lib/admin/queries";

type AdminDashboardPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

const orderStatuses = ["pending", "approved", "preparing", "out_for_delivery", "delivered", "rejected"] as const;
const productCategories = ["skincare", "haircare", "makeup", "fragrances", "beauty_tools", "other"] as const;
const deliveryEtas = ["same_day", "24_hours", "48_hours", "custom"] as const;

function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded border border-dashed border-[color:var(--line)] bg-white px-4 py-8 text-center text-sm text-[color:var(--muted)]">
      {label}
    </div>
  );
}

function AdminHeader({ email }: { email: string | null }) {
  return (
    <header className="border-b border-[color:var(--line)] bg-[color:var(--panel)]">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
        <div>
          <Link className="text-xl font-semibold" href={routes.home}>
            Lumera
          </Link>
          <p className="mt-1 text-sm text-[color:var(--muted)]">Admin workspace</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <span className="rounded border border-[color:var(--line)] bg-white px-3 py-2">{email}</span>
          <Link className="rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white" href={routes.signOut}>
            Sign out
          </Link>
        </div>
      </div>
    </header>
  );
}

function StatGrid({
  users,
  merchants,
  suppliers,
  products,
  orders,
}: {
  users: ProfileRow[];
  merchants: MerchantApplicationRow[];
  suppliers: SupplierApplicationRow[];
  products: ProductRow[];
  orders: OrderRow[];
}) {
  const stats = [
    { label: "Users", value: users.length },
    {
      label: "Pending applications",
      value:
        merchants.filter((item) => item.status === "pending").length +
        suppliers.filter((item) => item.status === "pending").length,
    },
    { label: "Products", value: products.length },
    { label: "Open orders", value: orders.filter((order) => order.status !== "delivered").length },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <article className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-4 shadow-sm" key={stat.label}>
          <p className="text-2xl font-semibold">{stat.value}</p>
          <p className="mt-1 text-sm text-[color:var(--muted)]">{stat.label}</p>
        </article>
      ))}
    </div>
  );
}

function MerchantApplications({ applications }: { applications: MerchantApplicationRow[] }) {
  if (applications.length === 0) {
    return <EmptyState label="No merchant applications yet." />;
  }

  return (
    <div className="grid gap-3">
      {applications.map((application) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={application.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">{application.store_name}</h3>
                <StatusPill value={application.status} />
              </div>
              <p className="mt-2 text-sm text-[color:var(--muted)]">
                {application.owner_name} - {application.phone_number}
              </p>
              <p className="mt-1 text-sm text-[color:var(--muted)]">
                {application.city} / {application.area}
              </p>
            </div>
            {application.status === "pending" ? (
              <div className="grid gap-2 sm:min-w-64">
                <form action={approveMerchantApplicationAction}>
                  <input name="applicationId" type="hidden" value={application.id} />
                  <button className="w-full rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
                    Approve
                  </button>
                </form>
                <form action={rejectMerchantApplicationAction} className="grid gap-2">
                  <input name="applicationId" type="hidden" value={application.id} />
                  <input
                    className="rounded border border-[color:var(--line)] px-3 py-2 text-sm"
                    name="rejectionReason"
                    placeholder="Rejection reason"
                  />
                  <button className="rounded border border-red-200 px-3 py-2 text-sm font-semibold text-red-700">
                    Reject
                  </button>
                </form>
              </div>
            ) : null}
          </div>
        </article>
      ))}
    </div>
  );
}

function SupplierApplications({ applications }: { applications: SupplierApplicationRow[] }) {
  if (applications.length === 0) {
    return <EmptyState label="No supplier applications yet." />;
  }

  return (
    <div className="grid gap-3">
      {applications.map((application) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={application.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">{application.company_name}</h3>
                <StatusPill value={application.status} />
              </div>
              <p className="mt-2 text-sm text-[color:var(--muted)]">{application.phone_number}</p>
            </div>
            {application.status === "pending" ? (
              <div className="grid gap-2 sm:min-w-64">
                <form action={approveSupplierApplicationAction}>
                  <input name="applicationId" type="hidden" value={application.id} />
                  <button className="w-full rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
                    Approve
                  </button>
                </form>
                <form action={rejectSupplierApplicationAction} className="grid gap-2">
                  <input name="applicationId" type="hidden" value={application.id} />
                  <input
                    className="rounded border border-[color:var(--line)] px-3 py-2 text-sm"
                    name="rejectionReason"
                    placeholder="Rejection reason"
                  />
                  <button className="rounded border border-red-200 px-3 py-2 text-sm font-semibold text-red-700">
                    Reject
                  </button>
                </form>
              </div>
            ) : null}
          </div>
        </article>
      ))}
    </div>
  );
}

function UserManagement({ users }: { users: ProfileRow[] }) {
  if (users.length === 0) {
    return <EmptyState label="No users found." />;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[680px] border-collapse text-left text-sm">
        <thead>
          <tr className="border-b border-[color:var(--line)] text-[color:var(--muted)]">
            <th className="py-3 pr-4 font-medium">User</th>
            <th className="py-3 pr-4 font-medium">Role</th>
            <th className="py-3 pr-4 font-medium">Status</th>
            <th className="py-3 pr-4 font-medium">Joined</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr className="border-b border-[color:var(--line)]" key={user.id}>
              <td className="py-3 pr-4">
                <p className="font-medium">{user.display_name ?? "Unnamed user"}</p>
                <p className="text-[color:var(--muted)]">{user.email}</p>
              </td>
              <td className="py-3 pr-4 capitalize">{user.role}</td>
              <td className="py-3 pr-4">
                <StatusPill value={user.approval_status} />
              </td>
              <td className="py-3 pr-4">{new Date(user.created_at).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CategoryManagement({ categories }: { categories: CategoryRow[] }) {
  return (
    <div className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
      <form action={createCategoryAction} className="grid gap-3 rounded border border-[color:var(--line)] bg-white p-4">
        <h3 className="font-semibold">Add category</h3>
        <input className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" name="nameEn" placeholder="English name" required />
        <input className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" name="nameAr" placeholder="Arabic name" />
        <input className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" name="slug" placeholder="Slug, optional" />
        <select className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" name="productCategory" required>
          {productCategories.map((category) => (
            <option key={category} value={category}>
              {category.replaceAll("_", " ")}
            </option>
          ))}
        </select>
        <button className="rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
          Add category
        </button>
      </form>

      <div className="grid gap-2">
        {categories.length === 0 ? <EmptyState label="No categories found." /> : null}
        {categories.map((category) => (
          <article className="flex flex-wrap items-center justify-between gap-3 rounded border border-[color:var(--line)] bg-white p-3" key={category.id}>
            <div>
              <p className="font-medium">{category.name_en}</p>
              <p className="text-sm text-[color:var(--muted)]">{category.slug}</p>
            </div>
            <div className="flex items-center gap-2">
              <StatusPill value={category.is_active ? "active" : "inactive"} />
              <form action={toggleCategoryAction}>
                <input name="categoryId" type="hidden" value={category.id} />
                <input name="isActive" type="hidden" value={String(category.is_active)} />
                <button className="rounded border border-[color:var(--line)] px-3 py-2 text-sm font-semibold">
                  {category.is_active ? "Disable" : "Enable"}
                </button>
              </form>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function ProductManagement({ categories, products }: { categories: CategoryRow[]; products: ProductRow[] }) {
  if (products.length === 0) {
    return <EmptyState label="No products found." />;
  }

  return (
    <div className="grid gap-3">
      {products.map((product) => (
        <article className="grid gap-4 rounded border border-[color:var(--line)] bg-white p-4" key={product.id}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-semibold">{product.name_en}</h3>
              <StatusPill value={product.is_active ? "active" : "inactive"} />
            </div>
            <form action={toggleProductAction}>
              <input name="productId" type="hidden" value={product.id} />
              <input name="isActive" type="hidden" value={String(product.is_active)} />
              <button className="rounded border border-[color:var(--line)] px-3 py-2 text-sm font-semibold">
                {product.is_active ? "Remove" : "Restore"}
              </button>
            </form>
          </div>
          <form action={updateAdminProductAction} className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <input name="productId" type="hidden" value={product.id} />
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Product name</span>
              <input className="rounded border border-[color:var(--line)] px-3 py-2" defaultValue={product.name_en} name="nameEn" required />
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Brand</span>
              <input className="rounded border border-[color:var(--line)] px-3 py-2" defaultValue={product.brand} name="brand" required />
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Category</span>
              <select className="rounded border border-[color:var(--line)] px-3 py-2" defaultValue={product.category_id} name="categoryId" required>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name_en}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Delivery ETA</span>
              <select className="rounded border border-[color:var(--line)] px-3 py-2" defaultValue={product.delivery_eta} name="deliveryEta" required>
                {deliveryEtas.map((eta) => (
                  <option key={eta} value={eta}>
                    {eta.replaceAll("_", " ")}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Wholesale price</span>
              <input
                className="rounded border border-[color:var(--line)] px-3 py-2"
                defaultValue={product.wholesale_price}
                min="0"
                name="wholesalePrice"
                required
                step="0.001"
                type="number"
              />
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Available quantity</span>
              <input
                className="rounded border border-[color:var(--line)] px-3 py-2"
                defaultValue={product.available_quantity}
                min="0"
                name="availableQuantity"
                required
                type="number"
              />
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">MOQ</span>
              <input
                className="rounded border border-[color:var(--line)] px-3 py-2"
                defaultValue={product.minimum_order_quantity}
                min="1"
                name="minimumOrderQuantity"
                required
                type="number"
              />
            </label>
            <label className="grid gap-1 text-sm">
              <span className="font-medium">Custom ETA</span>
              <input className="rounded border border-[color:var(--line)] px-3 py-2" defaultValue={product.custom_delivery_eta ?? ""} name="customDeliveryEta" />
            </label>
            <button className="rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white md:col-span-2 xl:col-span-4">
              Save product changes
            </button>
          </form>
        </article>
      ))}
    </div>
  );
}

function OrderManagement({ orders }: { orders: OrderRow[] }) {
  if (orders.length === 0) {
    return <EmptyState label="No orders found." />;
  }

  return (
    <div className="grid gap-3">
      {orders.map((order) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={order.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">Order {order.id.slice(0, 8)}</h3>
                <StatusPill value={order.status} />
              </div>
              <p className="mt-2 text-sm text-[color:var(--muted)]">
                {order.delivery_city} / {order.delivery_area} - {order.total_amount.toFixed(3)} JOD
              </p>
            </div>
            <form action={updateOrderStatusAction} className="flex flex-wrap gap-2">
              <input name="orderId" type="hidden" value={order.id} />
              <select className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" defaultValue={order.status} name="status">
                {orderStatuses.map((status) => (
                  <option key={status} value={status}>
                    {status.replaceAll("_", " ")}
                  </option>
                ))}
              </select>
              <button className="rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
                Update
              </button>
            </form>
          </div>
        </article>
      ))}
    </div>
  );
}

export default async function AdminDashboardPage({ searchParams }: AdminDashboardPageProps) {
  const params = await searchParams;
  const profile = await requireRole("admin");
  const data = await getAdminDashboardData();

  return (
    <main className="min-h-screen">
      <AdminHeader email={profile.email} />
      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-8 sm:px-8">
        <div className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
            Platform administration
          </p>
          <h1 className="mt-3 text-3xl font-semibold">Manage Lumera operations</h1>
          <p className="mt-3 max-w-3xl leading-7 text-[color:var(--muted)]">
            Review business applications, manage catalog categories, moderate products, and monitor orders.
          </p>
        </div>

        <AdminMessage searchParams={params} />

        <StatGrid
          merchants={data.merchantApplications}
          orders={data.orders}
          products={data.products}
          suppliers={data.supplierApplications}
          users={data.profiles}
        />

        <div className="grid gap-6 xl:grid-cols-2">
          <AdminSection
            description="Approve or reject cosmetics stores before they access wholesale prices and ordering."
            title="Merchant applications"
          >
            <MerchantApplications applications={data.merchantApplications} />
          </AdminSection>

          <AdminSection
            description="Approve suppliers before they can manage product listings and respond to orders."
            title="Supplier applications"
          >
            <SupplierApplications applications={data.supplierApplications} />
          </AdminSection>
        </div>

        <AdminSection description="Review registered users and their approval states." title="User management">
          <UserManagement users={data.profiles} />
        </AdminSection>

        <AdminSection description="Create and enable the categories used across the marketplace." title="Category management">
          <CategoryManagement categories={data.categories} />
        </AdminSection>

        <AdminSection description="Edit, remove, or restore supplier product listings from marketplace visibility." title="Product management">
          <ProductManagement categories={data.categories} products={data.products} />
        </AdminSection>

        <AdminSection description="Monitor and update order statuses across merchants and suppliers." title="Order management">
          <OrderManagement orders={data.orders} />
        </AdminSection>
      </section>
    </main>
  );
}
