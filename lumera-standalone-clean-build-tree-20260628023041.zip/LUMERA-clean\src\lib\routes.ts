export const routes = {
  home: "/",
  signIn: "/auth/sign-in",
  signUp: "/auth/sign-up",
  signOut: "/auth/sign-out",
  authCallback: "/auth/callback",
  pendingApproval: "/auth/pending-approval",
  merchant: "/merchant",
  supplier: "/supplier",
  admin: "/admin",
  merchantOnboarding: "/onboarding/merchant",
  supplierOnboarding: "/onboarding/supplier",
  products: "/products",
  cart: "/cart",
  orders: "/orders",
  notifications: "/notifications",
} as const;

export const roleHomeRoutes = {
  merchant: routes.merchant,
  supplier: routes.supplier,
  admin: routes.admin,
} as const;
