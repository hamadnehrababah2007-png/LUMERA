import Link from "next/link";

import { signUpAction } from "@/app/auth/actions";
import { AuthCard } from "@/components/auth/auth-card";
import { AuthMessage } from "@/components/auth/auth-message";
import { getAuthMessage } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";

type SignUpPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function SignUpPage({ searchParams }: SignUpPageProps) {
  const params = await searchParams;

  return (
    <AuthCard
      eyebrow="Choose the account type that matches your business. Admin approval is required before wholesale access is unlocked."
      title="Create a verified business account"
    >
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Business registration</h2>
          <p className="mt-2 text-sm text-[color:var(--muted)]">Merchant and supplier accounts start as pending.</p>
        </div>

        <AuthMessage error={getAuthMessage(params?.error)} />

        <form action={signUpAction} className="space-y-4">
          <label className="block">
            <span className="text-sm font-medium">Account type</span>
            <select
              className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 outline-none focus:border-[color:var(--brand)]"
              name="role"
              required
            >
              <option value="merchant">Merchant</option>
              <option value="supplier">Supplier</option>
            </select>
          </label>
          <label className="block">
            <span className="text-sm font-medium">Business or owner name</span>
            <input
              className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 outline-none focus:border-[color:var(--brand)]"
              name="displayName"
              required
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Email</span>
            <input
              className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 outline-none focus:border-[color:var(--brand)]"
              name="email"
              required
              type="email"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Password</span>
            <input
              className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 outline-none focus:border-[color:var(--brand)]"
              minLength={8}
              name="password"
              required
              type="password"
            />
          </label>
          <button className="w-full rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white transition hover:bg-[color:var(--brand-strong)]">
            Create account
          </button>
        </form>

        <p className="text-sm text-[color:var(--muted)]">
          Already registered?{" "}
          <Link className="font-semibold text-[color:var(--brand)]" href={routes.signIn}>
            Sign in
          </Link>
        </p>
      </div>
    </AuthCard>
  );
}
