import { AuthMessage } from "@/components/auth/auth-message";
import { getAuthMessage } from "@/lib/auth/messages";

type AdminMessageProps = {
  searchParams?: Record<string, string | string[] | undefined>;
};

export function AdminMessage({ searchParams }: AdminMessageProps) {
  return (
    <AuthMessage
      error={getAuthMessage(searchParams?.error)}
      status={getAuthMessage(searchParams?.status)}
    />
  );
}
