import Link from "next/link";
import type { ReactNode } from "react";

import {
  createSupplierProductAction,
  toggleSupplierProductAction,
  updateSupplierOrderStatusAction,
  updateSupplierProductAction,
} from "@/app/supplier/actions";
import { AuthMessage } from "@/components/auth/auth-message";
import { StatusPill } from "@/components/admin/status-pill";
import { requireRole } from "@/lib/auth/guards";
import { getAuthMessage } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";
import { getSupplierDashboardData } from "@/lib/supplier/queries";
import type {
  CategoryRow,
  CoverageAreaRow,
  SupplierOrder,
  SupplierProduct,
} from "@/lib/supplier/queries";

type SupplierDashboardPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

const deliveryEtas = [
  { label: "Same Day", value: "same_day" },
  { label: "24 Hours", value: "24_hours" },
  { label: "48 Hours", value: "48_hours" },
  { label: "Custom ETA", value: "custom" },
] as const;

const supplierOrderStatuses = [
  { label: "Accept", value: "approved" },
  { label: "Reject", value: "rejected" },
  { label: "Preparing", value: "preparing" },
  { label: "Out For Delivery", value: "out_for_delivery" },
  { label: "Delivered", value: "delivered" },
] as const;

function SupplierHeader({ email }: { email: string | null }) {
  return (
    <header className="border-b border-[color:var(--line)] bg-[color:var(--panel)]">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
        <div>
          <Link className="text-xl font-semibold" href={routes.home}>
            Lumera
          </Link>
          <p className="mt-1 text-sm text-[color:var(--muted)]">Supplier workspace</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <span className="rounded border border-[color:var(--line)] bg-white px-3 py-2">{email}</span>
          <Link className="rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white" href={routes.signOut}>
            Sign out
          </Link>
        </div>
      </div>
    </header>
  );
}

function SupplierSection({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5 shadow-sm">
      <div className="border-b border-[color:var(--line)] pb-4">
        <h2 className="text-xl font-semibold">{title}</h2>
        <p className="mt-2 text-sm leading-6 text-[color:var(--muted)]">{description}</p>
      </div>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded border border-dashed border-[color:var(--line)] bg-white px-4 py-8 text-center text-sm text-[color:var(--muted)]">
      {label}
    </div>
  );
}

function SupplierApprovalGate({
  approvalStatus,
  hasSupplierRecord,
}: {
  approvalStatus: string;
  hasSupplierRecord: boolean;
}) {
  if (approvalStatus === "approved" && hasSupplierRecord) {
    return null;
  }

  return (
    <section className="rounded border border-amber-200 bg-amber-50 p-5 text-amber-900">
      <h2 className="font-semibold">Supplier tools are waiting for approval</h2>
      <p className="mt-2 text-sm leading-6">
        Product management and order response tools unlock after admin approval creates your supplier record.
      </p>
      <Link className="mt-4 inline-flex rounded bg-[color:var(--brand)] px-4 py-2 text-sm font-semibold text-white" href={routes.supplierOnboarding}>
        Complete supplier application
      </Link>
    </section>
  );
}

function SupplierStats({ products, orders }: { products: SupplierProduct[]; orders: SupplierOrder[] }) {
  const stats = [
    { label: "Products", value: products.length },
    { label: "Active listings", value: products.filter((product) => product.is_active).length },
    { label: "Incoming orders", value: orders.filter((order) => order.status === "pending").length },
    { label: "Open orders", value: orders.filter((order) => order.status !== "delivered" && order.status !== "rejected").length },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <article className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-4 shadow-sm" key={stat.label}>
          <p className="text-2xl font-semibold">{stat.value}</p>
          <p className="mt-1 text-sm text-[color:var(--muted)]">{stat.label}</p>
        </article>
      ))}
    </div>
  );
}

function CoverageCheckboxes({
  coverageAreas,
  selectedIds = [],
}: {
  coverageAreas: CoverageAreaRow[];
  selectedIds?: string[];
}) {
  if (coverageAreas.length === 0) {
    return <p className="text-sm text-[color:var(--muted)]">No coverage areas configured yet.</p>;
  }

  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {coverageAreas.map((area) => (
        <label className="flex items-center gap-2 rounded border border-[color:var(--line)] bg-white px-3 py-2 text-sm" key={area.id}>
          <input defaultChecked={selectedIds.includes(area.id)} name="coverageAreaIds" type="checkbox" value={area.id} />
          <span>{area.label}</span>
        </label>
      ))}
    </div>
  );
}

function ProductCreateForm({
  categories,
  coverageAreas,
}: {
  categories: CategoryRow[];
  coverageAreas: CoverageAreaRow[];
}) {
  return (
    <form action={createSupplierProductAction} className="grid gap-4" encType="multipart/form-data">
      <div className="grid gap-4 md:grid-cols-2">
        <label className="block">
          <span className="text-sm font-medium">Product Name</span>
          <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="nameEn" required />
        </label>
        <label className="block">
          <span className="text-sm font-medium">Arabic Name</span>
          <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="nameAr" />
        </label>
        <label className="block">
          <span className="text-sm font-medium">Brand</span>
          <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="brand" required />
        </label>
        <label className="block">
          <span className="text-sm font-medium">Category</span>
          <select className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="categoryId" required>
            <option value="">Select category</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name_en}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="text-sm font-medium">Wholesale Price</span>
          <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" min="0" name="wholesalePrice" required step="0.001" type="number" />
        </label>
        <label className="block">
          <span className="text-sm font-medium">Available Quantity</span>
          <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" min="0" name="availableQuantity" required type="number" />
        </label>
        <label className="block">
          <span className="text-sm font-medium">Minimum Order Quantity</span>
          <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" min="1" name="minimumOrderQuantity" required type="number" />
        </label>
        <label className="block">
          <span className="text-sm font-medium">Delivery ETA</span>
          <select className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="deliveryEta" required>
            {deliveryEtas.map((eta) => (
              <option key={eta.value} value={eta.value}>
                {eta.label}
              </option>
            ))}
          </select>
        </label>
      </div>
      <label className="block">
        <span className="text-sm font-medium">Custom ETA</span>
        <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="customDeliveryEta" placeholder="Required only when Custom ETA is selected" />
      </label>
      <label className="block">
        <span className="text-sm font-medium">Product Image</span>
        <input accept="image/jpeg,image/png,image/webp" className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="image" required type="file" />
      </label>
      <div>
        <p className="mb-2 text-sm font-medium">Coverage Areas</p>
        <CoverageCheckboxes coverageAreas={coverageAreas} />
      </div>
      <button className="rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white">
        Create product listing
      </button>
    </form>
  );
}

function ProductManagement({
  products,
  coverageAreas,
}: {
  products: SupplierProduct[];
  coverageAreas: CoverageAreaRow[];
}) {
  if (products.length === 0) {
    return <EmptyState label="No supplier products yet." />;
  }

  return (
    <div className="grid gap-4">
      {products.map((product) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={product.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">{product.name_en}</h3>
                <StatusPill value={product.is_active ? "active" : "inactive"} />
              </div>
              <p className="mt-1 text-sm text-[color:var(--muted)]">
                {product.brand} - {product.category?.name_en ?? "Uncategorized"}
              </p>
              <p className="mt-1 text-sm text-[color:var(--muted)]">
                {product.available_quantity} units - MOQ {product.minimum_order_quantity} - {product.wholesale_price.toFixed(3)} JOD
              </p>
            </div>
            <form action={toggleSupplierProductAction}>
              <input name="productId" type="hidden" value={product.id} />
              <input name="isActive" type="hidden" value={String(product.is_active)} />
              <button className="rounded border border-[color:var(--line)] px-3 py-2 text-sm font-semibold">
                {product.is_active ? "Deactivate" : "Reactivate"}
              </button>
            </form>
          </div>
          <form action={updateSupplierProductAction} className="mt-4 grid gap-3 rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-4">
            <input name="productId" type="hidden" value={product.id} />
            <div className="grid gap-3 md:grid-cols-4">
              <label className="block">
                <span className="text-xs font-semibold uppercase text-[color:var(--muted)]">Price</span>
                <input className="mt-1 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 text-sm" defaultValue={product.wholesale_price} min="0" name="wholesalePrice" required step="0.001" type="number" />
              </label>
              <label className="block">
                <span className="text-xs font-semibold uppercase text-[color:var(--muted)]">Stock</span>
                <input className="mt-1 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 text-sm" defaultValue={product.available_quantity} min="0" name="availableQuantity" required type="number" />
              </label>
              <label className="block">
                <span className="text-xs font-semibold uppercase text-[color:var(--muted)]">MOQ</span>
                <input className="mt-1 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 text-sm" defaultValue={product.minimum_order_quantity} min="1" name="minimumOrderQuantity" required type="number" />
              </label>
              <label className="block">
                <span className="text-xs font-semibold uppercase text-[color:var(--muted)]">ETA</span>
                <select className="mt-1 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 text-sm" defaultValue={product.delivery_eta} name="deliveryEta">
                  {deliveryEtas.map((eta) => (
                    <option key={eta.value} value={eta.value}>
                      {eta.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <input className="rounded border border-[color:var(--line)] bg-white px-3 py-2 text-sm" defaultValue={product.custom_delivery_eta ?? ""} name="customDeliveryEta" placeholder="Custom ETA" />
            <CoverageCheckboxes coverageAreas={coverageAreas} selectedIds={product.coverage_area_ids} />
            <button className="w-fit rounded bg-[color:var(--brand)] px-4 py-2 text-sm font-semibold text-white">
              Save product changes
            </button>
          </form>
        </article>
      ))}
    </div>
  );
}

function IncomingOrders({ orders }: { orders: SupplierOrder[] }) {
  if (orders.length === 0) {
    return <EmptyState label="No supplier orders yet." />;
  }

  return (
    <div className="grid gap-4">
      {orders.map((order) => (
        <article className="rounded border border-[color:var(--line)] bg-white p-4" key={order.id}>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="font-semibold">Order {order.id.slice(0, 8)}</h3>
                <StatusPill value={order.status} />
              </div>
              <p className="mt-2 text-sm text-[color:var(--muted)]">
                {order.delivery_city} / {order.delivery_area} - {order.total_amount.toFixed(3)} JOD
              </p>
              {order.items.length > 0 ? (
                <ul className="mt-3 grid gap-1 text-sm text-[color:var(--muted)]">
                  {order.items.map((item) => (
                    <li key={item.id}>
                      {item.quantity} x {item.product_name} - {item.line_total.toFixed(3)} JOD
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
            <form action={updateSupplierOrderStatusAction} className="flex flex-wrap gap-2">
              <input name="orderId" type="hidden" value={order.id} />
              <select className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" defaultValue={order.status === "pending" ? "approved" : order.status} name="status">
                {supplierOrderStatuses.map((status) => (
                  <option key={status.value} value={status.value}>
                    {status.label}
                  </option>
                ))}
              </select>
              <button className="rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
                Update order
              </button>
            </form>
          </div>
        </article>
      ))}
    </div>
  );
}

export default async function SupplierDashboardPage({ searchParams }: SupplierDashboardPageProps) {
  const params = await searchParams;
  const profile = await requireRole("supplier");
  const data = await getSupplierDashboardData(profile.id);
  const approved = profile.approvalStatus === "approved" && Boolean(data.supplier);

  return (
    <main className="min-h-screen">
      <SupplierHeader email={profile.email} />
      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-8 sm:px-8">
        <div className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
            Supplier operations
          </p>
          <h1 className="mt-3 text-3xl font-semibold">Manage wholesale supply</h1>
          <p className="mt-3 max-w-3xl leading-7 text-[color:var(--muted)]">
            Create product listings, update stock and prices, define coverage areas, and respond to merchant
            orders.
          </p>
        </div>

        <AuthMessage error={getAuthMessage(params?.error)} status={getAuthMessage(params?.status)} />
        <SupplierApprovalGate approvalStatus={profile.approvalStatus} hasSupplierRecord={Boolean(data.supplier)} />

        {approved ? (
          <>
            <SupplierStats orders={data.orders} products={data.products} />
            <SupplierSection
              description="Create wholesale product listings with image, category, price, stock, MOQ, ETA, and coverage areas."
              title="Create product listing"
            >
              <ProductCreateForm categories={data.categories} coverageAreas={data.coverageAreas} />
            </SupplierSection>
            <SupplierSection
              description="Update prices, inventory, delivery ETAs, coverage areas, and listing visibility."
              title="Product management"
            >
              <ProductManagement coverageAreas={data.coverageAreas} products={data.products} />
            </SupplierSection>
            <SupplierSection
              description="Accept, reject, and progress merchant orders through fulfillment statuses."
              title="Incoming orders"
            >
              <IncomingOrders orders={data.orders} />
            </SupplierSection>
          </>
        ) : null}
      </section>
    </main>
  );
}
