import { submitMerchantApplicationAction } from "@/app/onboarding/actions";
import { AuthMessage } from "@/components/auth/auth-message";
import { getAuthMessage } from "@/lib/auth/messages";
import { requireRole } from "@/lib/auth/guards";

type MerchantOnboardingPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function MerchantOnboardingPage({ searchParams }: MerchantOnboardingPageProps) {
  const params = await searchParams;
  await requireRole("merchant");

  return (
    <main className="mx-auto max-w-3xl px-5 py-10">
      <section className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
        <AuthMessage error={getAuthMessage(params?.error)} />
        <p className="text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
          Merchant application
        </p>
        <h1 className="mt-3 text-3xl font-semibold">Merchant approval details</h1>
        <p className="mt-3 leading-7 text-[color:var(--muted)]">
          Submit the required business details for admin review. Wholesale prices and ordering stay locked
          until your store is approved.
        </p>
        <form action={submitMerchantApplicationAction} className="mt-6 grid gap-4" encType="multipart/form-data">
          <label className="block">
            <span className="text-sm font-medium">Store Name</span>
            <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="storeName" required />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Owner Name</span>
            <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="ownerName" required />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Phone Number</span>
            <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="phoneNumber" required />
          </label>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="text-sm font-medium">City</span>
              <select className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="city" required>
                <option value="amman">Amman</option>
                <option value="irbid">Irbid</option>
                <option value="zarqa">Zarqa</option>
                <option value="other">Other city</option>
              </select>
            </label>
            <label className="block">
              <span className="text-sm font-medium">Area</span>
              <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="area" required />
            </label>
          </div>
          <label className="block">
            <span className="text-sm font-medium">Business License Upload</span>
            <input accept="application/pdf,image/jpeg,image/png,image/webp" className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="businessLicense" required type="file" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Commercial Registration Upload</span>
            <input accept="application/pdf,image/jpeg,image/png,image/webp" className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="commercialRegistration" required type="file" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Instagram Page</span>
            <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="instagramPage" placeholder="Optional" />
          </label>
          <button className="rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white">
            Submit merchant application
          </button>
        </form>
      </section>
    </main>
  );
}
