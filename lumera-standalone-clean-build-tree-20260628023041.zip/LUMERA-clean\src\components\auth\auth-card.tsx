import Link from "next/link";
import type { ReactNode } from "react";

import { routes } from "@/lib/routes";

type AuthCardProps = {
  title: string;
  eyebrow: string;
  children: ReactNode;
};

export function AuthCard({ title, eyebrow, children }: AuthCardProps) {
  return (
    <main className="flex min-h-screen items-center justify-center px-5 py-10">
      <section className="grid w-full max-w-5xl overflow-hidden rounded border border-[color:var(--line)] bg-[color:var(--panel)] shadow-sm md:grid-cols-[0.9fr_1.1fr]">
        <aside className="bg-[color:var(--brand)] p-8 text-white">
          <Link className="text-xl font-semibold" href={routes.home}>
            Lumera
          </Link>
          <h1 className="mt-16 max-w-sm text-3xl font-semibold leading-tight">{title}</h1>
          <p className="mt-4 max-w-sm text-sm leading-6 text-white/80">{eyebrow}</p>
        </aside>
        <div className="p-6 sm:p-8">{children}</div>
      </section>
    </main>
  );
}
