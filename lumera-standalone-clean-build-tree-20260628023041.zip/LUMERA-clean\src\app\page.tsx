import {
  BadgeCheck,
  Boxes,
  ClipboardList,
  Search,
  ShieldCheck,
  Store,
  Truck,
} from "lucide-react";
import Link from "next/link";

import { primaryNavigation } from "@/config/navigation";
import { routes } from "@/lib/routes";
import { productDecisions } from "@/lib/product-decisions";

const metrics = [
  { label: "Applications pending", value: "12" },
  { label: "Active suppliers", value: "8" },
  { label: "Wholesale SKUs", value: "240" },
  { label: "Open orders", value: "31" },
];

const roleCards = [
  {
    title: "Merchants",
    body: "Approved cosmetics stores browse prices, compare supplier coverage, and place wholesale orders.",
    icon: Store,
  },
  {
    title: "Suppliers",
    body: "Suppliers maintain products, stock, delivery ETAs, and respond to merchant orders.",
    icon: Boxes,
  },
  {
    title: "Admin",
    body: "Admins review applications, manage categories, monitor products, and oversee order status.",
    icon: ShieldCheck,
  },
];

const workflow = [
  { label: "Verify business", icon: BadgeCheck },
  { label: "Search catalog", icon: Search },
  { label: "Place wholesale order", icon: ClipboardList },
  { label: "Track delivery", icon: Truck },
];

export default function Home() {
  return (
    <main className="min-h-screen">
      <header className="border-b border-[color:var(--line)] bg-[color:var(--panel)]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded bg-[color:var(--brand)] text-sm font-bold text-white">
              L
            </div>
            <div>
              <p className="text-lg font-semibold">Lumera</p>
              <p className="text-sm text-[color:var(--muted)]">B2B cosmetics wholesale</p>
            </div>
          </div>
          <nav className="flex flex-wrap items-center gap-2 text-sm text-[color:var(--muted)]">
            {primaryNavigation.map((item) => (
              <a
                className="rounded px-3 py-2 transition hover:bg-[#ece5da] hover:text-[color:var(--foreground)]"
                href={item.href}
                key={item.href}
              >
                {item.label}
              </a>
            ))}
            <Link
              className="rounded border border-[color:var(--line)] px-3 py-2 font-semibold text-[color:var(--foreground)]"
              href={routes.signIn}
            >
              Sign in
            </Link>
            <Link
              className="rounded bg-[color:var(--brand)] px-3 py-2 font-semibold text-white"
              href={routes.signUp}
            >
              Register
            </Link>
          </nav>
        </div>
      </header>

      <section className="mx-auto grid max-w-7xl gap-6 px-5 py-8 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:py-12">
        <div className="flex min-h-[420px] flex-col justify-between rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-6 shadow-sm sm:p-8">
          <div>
            <p className="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--accent)]">
              Jordan wholesale marketplace
            </p>
            <h1 className="max-w-3xl text-4xl font-semibold leading-tight sm:text-5xl">
              Private cosmetics sourcing for verified stores and suppliers.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-7 text-[color:var(--muted)] sm:text-lg">
              Lumera centralizes supplier discovery, wholesale pricing, product availability, and order
              tracking for cosmetics businesses.
            </p>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-4">
            {metrics.map((metric) => (
              <div className="rounded border border-[color:var(--line)] bg-white p-4" key={metric.label}>
                <p className="text-2xl font-semibold">{metric.value}</p>
                <p className="mt-1 text-sm text-[color:var(--muted)]">{metric.label}</p>
              </div>
            ))}
          </div>
        </div>

        <aside className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5 shadow-sm sm:p-6">
          <h2 className="text-xl font-semibold">MVP operating model</h2>
          <div className="mt-5 grid gap-3">
            {roleCards.map((card) => {
              const Icon = card.icon;

              return (
                <article className="rounded border border-[color:var(--line)] bg-white p-4" key={card.title}>
                  <div className="flex items-start gap-3">
                    <Icon className="mt-1 size-5 text-[color:var(--brand)]" />
                    <div>
                      <h3 className="font-semibold">{card.title}</h3>
                      <p className="mt-1 text-sm leading-6 text-[color:var(--muted)]">{card.body}</p>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </aside>
      </section>

      <section className="border-y border-[color:var(--line)] bg-[#efe7dc]">
        <div className="mx-auto grid max-w-7xl gap-4 px-5 py-6 sm:grid-cols-4 sm:px-8">
          {workflow.map((step) => {
            const Icon = step.icon;

            return (
              <div className="flex items-center gap-3 rounded bg-[color:var(--panel)] p-4" key={step.label}>
                <Icon className="size-5 text-[color:var(--brand)]" />
                <span className="text-sm font-medium">{step.label}</span>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
        <div className="grid gap-4 md:grid-cols-3">
          {productDecisions.map((decision) => (
            <article className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5" key={decision.title}>
              <p className="text-sm font-semibold uppercase tracking-[0.14em] text-[color:var(--accent)]">
                {decision.area}
              </p>
              <h3 className="mt-2 text-lg font-semibold">{decision.title}</h3>
              <p className="mt-3 text-sm leading-6 text-[color:var(--muted)]">{decision.summary}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
