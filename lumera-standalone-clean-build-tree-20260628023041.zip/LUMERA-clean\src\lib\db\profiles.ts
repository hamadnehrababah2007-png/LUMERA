import type { SupabaseClient, User } from "@supabase/supabase-js";

import { profileFromUser } from "@/lib/auth/profile";
import type { Database } from "@/types/database";
import type { AuthProfile } from "@/types/domain";

type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"];

export function profileFromRow(row: ProfileRow): AuthProfile {
  return {
    id: row.id,
    email: row.email,
    role: row.role,
    approvalStatus: row.approval_status,
    displayName: row.display_name,
  };
}

export async function getProfileForUser(
  supabase: SupabaseClient<Database>,
  user: User,
): Promise<AuthProfile> {
  const { data, error } = await supabase
    .from("profiles")
    .select("id,email,role,approval_status,display_name,created_at,updated_at")
    .eq("id", user.id)
    .maybeSingle();

  if (error || !data) {
    return profileFromUser(user);
  }

  return profileFromRow(data);
}
