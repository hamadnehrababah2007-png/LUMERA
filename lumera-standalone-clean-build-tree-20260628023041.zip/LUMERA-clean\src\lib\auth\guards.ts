import { redirect } from "next/navigation";

import { roleHomeRoutes, routes } from "@/lib/routes";
import { getCurrentProfile } from "@/lib/auth/session";
import type { UserRole } from "@/types/domain";

export async function requireAuth() {
  const profile = await getCurrentProfile();

  if (!profile) {
    redirect(routes.signIn);
  }

  return profile;
}

export async function requireRole(role: UserRole) {
  const profile = await requireAuth();

  if (profile.role !== role) {
    redirect(roleHomeRoutes[profile.role]);
  }

  return profile;
}

export async function requireApprovedRole(role: UserRole) {
  const profile = await requireRole(role);

  if (profile.approvalStatus !== "approved") {
    redirect(routes.pendingApproval);
  }

  return profile;
}
