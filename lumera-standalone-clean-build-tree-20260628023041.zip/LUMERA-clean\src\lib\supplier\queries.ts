import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Database } from "@/types/database";

export type SupplierRow = Database["public"]["Tables"]["suppliers"]["Row"];
export type ProductRow = Database["public"]["Tables"]["products"]["Row"];
export type CategoryRow = Database["public"]["Tables"]["categories"]["Row"];
export type CoverageAreaRow = Database["public"]["Tables"]["coverage_areas"]["Row"];
export type OrderRow = Database["public"]["Tables"]["orders"]["Row"];
export type OrderItemRow = Database["public"]["Tables"]["order_items"]["Row"];

export type SupplierProduct = ProductRow & {
  category?: Pick<CategoryRow, "id" | "name_en" | "name_ar"> | null;
  coverage_area_ids: string[];
};

export type SupplierOrder = OrderRow & {
  items: OrderItemRow[];
};

async function unwrap<T>(promise: PromiseLike<{ data: T | null; error: { message: string } | null }>) {
  const { data, error } = await promise;

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function getSupplierDashboardData(profileId: string) {
  const supabase = await createSupabaseServerClient();
  const supplier = await unwrap(
    supabase.from("suppliers").select("*").eq("profile_id", profileId).maybeSingle(),
  );

  const [categories, coverageAreas] = await Promise.all([
    unwrap(
      supabase
        .from("categories")
        .select("*")
        .eq("is_active", true)
        .order("name_en", { ascending: true }),
    ),
    unwrap(
      supabase
        .from("coverage_areas")
        .select("*")
        .eq("is_active", true)
        .order("label", { ascending: true }),
    ),
  ]);

  if (!supplier) {
    return {
      supplier: null,
      categories: categories ?? [],
      coverageAreas: coverageAreas ?? [],
      products: [],
      orders: [],
    };
  }

  const [products, orders] = await Promise.all([
    unwrap(
      supabase
        .from("products")
        .select("*")
        .eq("supplier_id", supplier.id)
        .order("created_at", { ascending: false }),
    ),
    unwrap(
      supabase
        .from("orders")
        .select("*")
        .eq("supplier_id", supplier.id)
        .order("created_at", { ascending: false })
        .limit(30),
    ),
  ]);

  const productRows = products ?? [];
  const productIds = productRows.map((product) => product.id);
  const coverageRows =
    productIds.length > 0
      ? await unwrap(
          supabase
            .from("product_coverage_areas")
            .select("*")
            .in("product_id", productIds),
        )
      : [];
  const orderRows = orders ?? [];
  const orderIds = orderRows.map((order) => order.id);
  const orderItems =
    orderIds.length > 0
      ? await unwrap(
          supabase
            .from("order_items")
            .select("*")
            .in("order_id", orderIds)
            .order("created_at", { ascending: true }),
        )
      : [];
  const categoryById = new Map((categories ?? []).map((category) => [category.id, category]));
  const coverageByProduct = new Map<string, string[]>();
  const itemsByOrder = new Map<string, OrderItemRow[]>();

  for (const row of coverageRows ?? []) {
    const existing = coverageByProduct.get(row.product_id) ?? [];
    existing.push(row.coverage_area_id);
    coverageByProduct.set(row.product_id, existing);
  }

  for (const item of orderItems ?? []) {
    const existing = itemsByOrder.get(item.order_id) ?? [];
    existing.push(item);
    itemsByOrder.set(item.order_id, existing);
  }

  return {
    supplier,
    categories: categories ?? [],
    coverageAreas: coverageAreas ?? [],
    products: productRows.map((product) => ({
      ...product,
      category: categoryById.get(product.category_id) ?? null,
      coverage_area_ids: coverageByProduct.get(product.id) ?? [],
    })),
    orders: orderRows.map((order) => ({
      ...order,
      items: itemsByOrder.get(order.id) ?? [],
    })),
  };
}
