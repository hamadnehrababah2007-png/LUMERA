import { markNotificationReadAction } from "@/app/shop/actions";
import { StatusPill } from "@/components/admin/status-pill";
import { EmptyState } from "@/components/shop/empty-state";
import { ShopShell } from "@/components/shop/shop-shell";
import { requireAuth } from "@/lib/auth/guards";
import { getNotifications } from "@/lib/shop/queries";

export default async function NotificationsPage() {
  const profile = await requireAuth();
  const notifications = await getNotifications(profile.id);

  return (
    <ShopShell
      description="Review account, application, and order updates."
      profile={profile}
      title="Notifications"
    >
      {notifications && notifications.length === 0 ? <EmptyState label="No notifications yet." /> : null}
      <div className="grid gap-4">
        {(notifications ?? []).map((notification) => (
          <article className="rounded border border-[color:var(--line)] bg-white p-4" key={notification.id}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="font-semibold">{notification.title}</h2>
                  <StatusPill value={notification.read_at ? "read" : "pending"} />
                </div>
                <p className="mt-2 text-sm leading-6 text-[color:var(--muted)]">{notification.body}</p>
                <p className="mt-2 text-xs text-[color:var(--muted)]">
                  {new Date(notification.created_at).toLocaleString()}
                </p>
              </div>
              {!notification.read_at ? (
                <form action={markNotificationReadAction}>
                  <input name="notificationId" type="hidden" value={notification.id} />
                  <button className="rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
                    Mark read
                  </button>
                </form>
              ) : null}
            </div>
          </article>
        ))}
      </div>
    </ShopShell>
  );
}
