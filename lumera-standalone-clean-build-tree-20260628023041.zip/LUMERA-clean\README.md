# Lumera

Lumera is a private B2B wholesale cosmetics marketplace for verified cosmetics businesses in Jordan. Merchants can discover wholesale products, compare suppliers, build carts, place orders, and track order progress. Suppliers can manage product listings and incoming orders. Admins review applications, moderate marketplace data, and monitor orders.

## MVP Status

The MVP includes:

- Merchant, supplier, and admin roles
- Email/password authentication with Supabase Auth
- Merchant and supplier onboarding applications
- Admin approval and rejection workflows
- Private approved-merchant product catalog
- Limited public product preview for unapproved authenticated users
- Supplier product management with pricing, stock, MOQ, delivery ETA, image upload, and coverage areas
- Merchant catalog search and filtering
- Product detail pages
- Shopping cart with MOQ and stock validation
- Checkout flow that splits orders by supplier
- Merchant and supplier order tracking
- Admin order monitoring and status updates
- Notification inbox with read state
- Supabase database schema, RLS policies, storage buckets, and workflow RPCs
- Vercel-ready Next.js application structure

## Tech Stack

- Next.js 15 App Router
- React 19
- TypeScript
- Tailwind CSS
- Supabase Auth, Postgres, RLS, Storage, and RPC functions
- Vercel deployment

## Project Structure

```text
src/app                    App routes, pages, and server actions
src/components             Shared UI components
src/config                 Navigation configuration
src/lib                    Auth, Supabase, data access, routes, and product decisions
src/types                  Shared domain and Supabase database types
supabase/migrations        Database schema, RLS, views, and RPC functions
docs                       Architecture and feature documentation
```

## Environment Variables

Create `.env.local` from `.env.example`:

```bash
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

Use the Supabase anon key for `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Use the Supabase service role key only on trusted server environments such as Vercel server runtime; never expose it in client code.

## Local Setup

Install dependencies:

```bash
pnpm install
```

Start the development server:

```bash
pnpm dev
```

Run quality checks:

```bash
pnpm lint
pnpm typecheck
pnpm build
```

## Supabase Setup

1. Create a Supabase project.
2. Add the environment variables above to `.env.local`.
3. Apply migrations in order from `supabase/migrations`.
4. Confirm these Storage buckets exist:
   - `business-documents`
   - `product-images`
5. Create the first admin user:
   - Sign up in the app.
   - In Supabase SQL editor, update that user's profile role to `admin` and approval status to `approved`.

Example admin bootstrap:

```sql
update public.profiles
set role = 'admin',
    approval_status = 'approved'
where email = 'admin@example.com';
```

## Role Workflows

### Merchant

1. Sign up as a merchant.
2. Submit the merchant onboarding application.
3. Wait for admin approval.
4. Browse products, view product details, add items to cart, place orders, track orders, and read notifications.

### Supplier

1. Sign up as a supplier.
2. Submit the supplier onboarding application.
3. Wait for admin approval.
4. Create and manage products, update stock and availability, and respond to incoming orders.

### Admin

1. Review merchant and supplier applications.
2. Approve or reject applications.
3. Manage categories.
4. Moderate products.
5. Monitor and update orders.

## Production Deployment on Vercel

1. Import the GitHub repository into Vercel.
2. Select the Next.js framework preset.
3. Add these environment variables in Vercel:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
4. Apply all Supabase migrations to the production Supabase project.
5. Confirm Storage buckets and policies are present.
6. Deploy.
7. Run a smoke test:
   - Sign in as admin.
   - Approve a merchant and supplier.
   - Create a supplier product.
   - View the product as a merchant.
   - Add the product to cart.
   - Place an order.
   - Update the order status.
   - Confirm the merchant sees a notification.

## Database and Security Notes

- RLS is enabled on all marketplace tables.
- Approved merchants can access full wholesale catalog data.
- Unapproved authenticated users only see limited product previews.
- Suppliers can manage only their own products and related orders.
- Admins have broad operational access for application review, moderation, categories, and order monitoring.
- Checkout is handled by a database RPC so supplier-split order creation, stock validation, stock decrementing, cart clearing, and merchant notifications happen consistently.

## Useful Documentation

- `docs/architecture.md`
- `docs/database.md`
- `docs/admin.md`
- `docs/supplier-dashboard.md`
- `docs/merchant-dashboard.md`
- `docs/shop-orders-notifications.md`
- `docs/production-readiness.md`

