# Product Catalog, Cart, Orders, and Notifications

This milestone completes the remaining PRD shopping workflows.

## Product Catalog

- `/products` lists product cards.
- `/products/[productId]` shows the product details page.
- Unapproved merchants see only limited product details and the required wholesale access message.
- Approved merchants see supplier, wholesale price, stock, MOQ, delivery ETA, and coverage details.
- Product images render from the public `product-images` Supabase Storage bucket.

## Cart

- `/cart` lets approved merchants review selected products.
- Merchants can update quantities.
- Merchants can remove products.
- The cart highlights quantities below MOQ or above stock.
- Checkout is disabled while invalid cart items exist.

## Order Placement

- Checkout calls `checkout_merchant_cart`.
- The database function validates approved merchant access, stock, MOQ, and active products.
- Orders are split by supplier.
- Order items snapshot product name, brand, unit price, quantity, and line total.
- Product stock is reduced during checkout.
- Supplier notifications are created for new orders.

## Order Tracking

- `/orders` lists merchant orders and order items.
- Suppliers can update order status from their dashboard.
- Admins can update order status from the admin dashboard.
- Merchant notifications are created when order status changes.

## Notifications

- `/notifications` is available for signed-in users.
- Users can mark notifications as read.
- Notifications currently cover application status, new supplier orders, and order status updates.
