# Lumera MVP Milestones

## 1. Project Setup and Architecture

- Establish the Next.js, TypeScript, and Tailwind CSS baseline.
- Add shared domain types and route constants.
- Document the MVP architecture and implementation sequence.

## 2. Authentication and User Roles

- Add Supabase Auth.
- Create role-aware profile handling.
- Add merchant, supplier, and admin route protection.
- Add role-specific sign-up, sign-in, callback, and sign-out flows.
- Keep application persistence for Milestone 3.

## 3. Database Schema and Supabase Integration

- Add schema migrations for users, applications, products, categories, carts, orders, and notifications.
- Add Supabase clients and storage buckets.
- Add Row Level Security policies.
- Add typed database contracts.
- Wire profile loading to Postgres.
- Persist merchant and supplier applications with document uploads.

## 4. Admin Dashboard

- Review and approve or reject merchants and suppliers.
- Manage categories.
- View products and orders.
- Create merchant or supplier records after approval.
- Moderate product visibility.
- Update order statuses.
- Review registered users and approval states.

## 5. Supplier Dashboard

- Manage product listings.
- Update price, stock, MOQ, delivery ETA, and coverage areas.
- Accept or reject orders.
- Upload product images to Supabase Storage.
- View incoming orders and progress fulfillment status.
- Gate dashboard tools behind supplier approval.

## 6. Merchant Dashboard

- Browse the catalog.
- Search and filter products.
- View product details after approval.
- Show limited product previews to unapproved merchants.
- Compare suppliers, wholesale prices, stock, MOQ, delivery ETA, and coverage areas.
- Track merchant order statuses.

## 7. Products

- Build product listing and detail pages.
- Enforce verified and unverified visibility rules.
- Support Arabic and English search.
- Render product images from Supabase Storage.

## 8. Orders

- Add cart management.
- Validate minimum order quantities.
- Submit orders and track statuses.
- Split checkout by supplier.
- Reduce stock when orders are placed.

## 9. Notifications

- Notify users about approvals and order changes.
- Add signed-in notification inbox and read state.

## 10. Final Polish, Testing, and Deployment Preparation

- Complete responsive QA.
- Add production readiness checks.
- Prepare Vercel deployment configuration.
