import Link from "next/link";

import { signInAction } from "@/app/auth/actions";
import { AuthCard } from "@/components/auth/auth-card";
import { AuthMessage } from "@/components/auth/auth-message";
import { getAuthMessage } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";

type SignInPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function SignInPage({ searchParams }: SignInPageProps) {
  const params = await searchParams;

  return (
    <AuthCard
      eyebrow="Access wholesale prices, inventory, carts, and orders after your business account is approved."
      title="Sign in to your Lumera workspace"
    >
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Welcome back</h2>
          <p className="mt-2 text-sm text-[color:var(--muted)]">Use your approved business account.</p>
        </div>

        <AuthMessage error={getAuthMessage(params?.error)} status={getAuthMessage(params?.status)} />

        <form action={signInAction} className="space-y-4">
          <label className="block">
            <span className="text-sm font-medium">Email</span>
            <input
              className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 outline-none focus:border-[color:var(--brand)]"
              name="email"
              required
              type="email"
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Password</span>
            <input
              className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2 outline-none focus:border-[color:var(--brand)]"
              minLength={8}
              name="password"
              required
              type="password"
            />
          </label>
          <button className="w-full rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white transition hover:bg-[color:var(--brand-strong)]">
            Sign in
          </button>
        </form>

        <p className="text-sm text-[color:var(--muted)]">
          Need an account?{" "}
          <Link className="font-semibold text-[color:var(--brand)]" href={routes.signUp}>
            Register your business
          </Link>
        </p>
      </div>
    </AuthCard>
  );
}
