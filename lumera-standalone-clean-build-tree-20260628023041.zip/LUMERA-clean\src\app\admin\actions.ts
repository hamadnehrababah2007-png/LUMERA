"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { requireRole } from "@/lib/auth/guards";
import { authRedirect } from "@/lib/auth/messages";
import { routes } from "@/lib/routes";
import type { Database } from "@/types/database";
import { createSupabaseServerClient } from "@/lib/supabase/server";

type OrderStatus = Database["public"]["Enums"]["order_status"];
type ProductCategory = Database["public"]["Enums"]["product_category"];
type DeliveryEta = Database["public"]["Enums"]["delivery_eta"];

const orderStatuses = new Set<OrderStatus>([
  "pending",
  "approved",
  "preparing",
  "out_for_delivery",
  "delivered",
  "rejected",
]);

const productCategories = new Set<ProductCategory>([
  "skincare",
  "haircare",
  "makeup",
  "fragrances",
  "beauty_tools",
  "other",
]);
const deliveryEtas = new Set<DeliveryEta>(["same_day", "24_hours", "48_hours", "custom"]);

function readRequired(formData: FormData, key: string) {
  const value = formData.get(key);

  return typeof value === "string" ? value.trim() : "";
}

function readOptional(formData: FormData, key: string) {
  const value = readRequired(formData, key);

  return value ? value : null;
}

function readNumber(formData: FormData, key: string) {
  const raw = readRequired(formData, key);
  const value = Number(raw);

  return Number.isFinite(value) ? value : null;
}

function adminError(message: string): never {
  redirect(authRedirect(routes.admin, "error", message));
}

async function ensureAdminContext() {
  await requireRole("admin");
  const supabase = await createSupabaseServerClient();

  return { supabase };
}

export async function approveMerchantApplicationAction(formData: FormData) {
  const applicationId = readRequired(formData, "applicationId");
  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.rpc("admin_approve_merchant_application", {
    p_application_id: applicationId,
  });

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function rejectMerchantApplicationAction(formData: FormData) {
  const applicationId = readRequired(formData, "applicationId");
  const rejectionReason = readOptional(formData, "rejectionReason");
  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.rpc("admin_reject_merchant_application", {
    p_application_id: applicationId,
    p_rejection_reason: rejectionReason,
  });

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function approveSupplierApplicationAction(formData: FormData) {
  const applicationId = readRequired(formData, "applicationId");
  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.rpc("admin_approve_supplier_application", {
    p_application_id: applicationId,
  });

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function rejectSupplierApplicationAction(formData: FormData) {
  const applicationId = readRequired(formData, "applicationId");
  const rejectionReason = readOptional(formData, "rejectionReason");
  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.rpc("admin_reject_supplier_application", {
    p_application_id: applicationId,
    p_rejection_reason: rejectionReason,
  });

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function createCategoryAction(formData: FormData) {
  const nameEn = readRequired(formData, "nameEn");
  const nameAr = readOptional(formData, "nameAr");
  const category = readRequired(formData, "productCategory");
  const slug =
    readOptional(formData, "slug") ??
    nameEn
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

  if (!nameEn || !slug || !productCategories.has(category as ProductCategory)) {
    adminError("Category name and type are required.");
  }

  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.from("categories").insert({
    slug,
    name_en: nameEn,
    name_ar: nameAr,
    product_category: category as ProductCategory,
  });

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function toggleCategoryAction(formData: FormData) {
  const categoryId = readRequired(formData, "categoryId");
  const isActive = readRequired(formData, "isActive") === "true";
  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.from("categories").update({ is_active: !isActive }).eq("id", categoryId);

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function toggleProductAction(formData: FormData) {
  const productId = readRequired(formData, "productId");
  const isActive = readRequired(formData, "isActive") === "true";
  const { supabase } = await ensureAdminContext();
  const { error } = await supabase.from("products").update({ is_active: !isActive }).eq("id", productId);

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function updateAdminProductAction(formData: FormData) {
  const productId = readRequired(formData, "productId");
  const nameEn = readRequired(formData, "nameEn");
  const brand = readRequired(formData, "brand");
  const categoryId = readRequired(formData, "categoryId");
  const wholesalePrice = readNumber(formData, "wholesalePrice");
  const availableQuantity = readNumber(formData, "availableQuantity");
  const minimumOrderQuantity = readNumber(formData, "minimumOrderQuantity");
  const deliveryEtaValue = readRequired(formData, "deliveryEta");
  const deliveryEta = deliveryEtas.has(deliveryEtaValue as DeliveryEta) ? (deliveryEtaValue as DeliveryEta) : null;
  const customDeliveryEta = readOptional(formData, "customDeliveryEta");

  if (
    !productId ||
    !nameEn ||
    !brand ||
    !categoryId ||
    wholesalePrice === null ||
    availableQuantity === null ||
    minimumOrderQuantity === null ||
    !deliveryEta
  ) {
    adminError("Product name, brand, category, price, stock, MOQ, and ETA are required.");
  }

  if (wholesalePrice < 0 || availableQuantity < 0 || minimumOrderQuantity <= 0) {
    adminError("Price, stock, and minimum order quantity must be valid positive values.");
  }

  const { supabase } = await ensureAdminContext();
  const { error } = await supabase
    .from("products")
    .update({
      name_en: nameEn,
      brand,
      category_id: categoryId,
      wholesale_price: wholesalePrice,
      available_quantity: availableQuantity,
      minimum_order_quantity: minimumOrderQuantity,
      delivery_eta: deliveryEta,
      custom_delivery_eta: deliveryEta === "custom" ? customDeliveryEta : null,
    })
    .eq("id", productId);

  if (error) {
    adminError(error.message);
  }

  revalidatePath(routes.admin);
}

export async function updateOrderStatusAction(formData: FormData) {
  const orderId = readRequired(formData, "orderId");
  const status = readRequired(formData, "status");

  if (!orderStatuses.has(status as OrderStatus)) {
    adminError("Invalid order status.");
  }

  const { supabase } = await ensureAdminContext();
  const timestamp = new Date().toISOString();
  const { data: order, error: fetchError } = await supabase
    .from("orders")
    .select("id,merchant_id,supplier_id")
    .eq("id", orderId)
    .single();

  if (fetchError || !order) {
    adminError("Order could not be found.");
  }

  const { error } = await supabase
    .from("orders")
    .update({
      status: status as OrderStatus,
      accepted_at: status === "approved" ? timestamp : undefined,
      rejected_at: status === "rejected" ? timestamp : undefined,
    })
    .eq("id", orderId);

  if (error) {
    adminError(error.message);
  }

  const { data: merchant } = await supabase
    .from("merchants")
    .select("profile_id")
    .eq("id", order.merchant_id)
    .single();

  if (merchant) {
    await supabase.from("notifications").insert({
      recipient_id: merchant.profile_id,
      type: "order_status",
      title: "Order status updated",
      body: `Your order ${order.id.slice(0, 8)} is now ${(status as OrderStatus).replaceAll("_", " ")}.`,
    });
  }

  revalidatePath(routes.admin);
}
