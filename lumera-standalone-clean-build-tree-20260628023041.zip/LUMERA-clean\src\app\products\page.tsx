import { AuthMessage } from "@/components/auth/auth-message";
import { ProductCard } from "@/components/shop/product-card";
import { ShopShell } from "@/components/shop/shop-shell";
import { requireRole } from "@/lib/auth/guards";
import { getAuthMessage } from "@/lib/auth/messages";
import { getMerchantDashboardData } from "@/lib/merchant/queries";

type ProductsPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

function readParam(params: Record<string, string | string[] | undefined> | undefined, key: string) {
  const value = params?.[key];

  return typeof value === "string" ? value.trim() : "";
}

export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const params = await searchParams;
  const profile = await requireRole("merchant");
  const query = readParam(params, "q");
  const categoryId = readParam(params, "category");
  const availableOnly = readParam(params, "available") === "true";
  const data = await getMerchantDashboardData(profile.id, { query, categoryId, availableOnly });
  const approved = profile.approvalStatus === "approved" && Boolean(data.merchant);
  const products = approved ? data.products : data.publicProducts;

  return (
    <ShopShell
      description="Browse cosmetics products, search by name or brand, filter by category, and inspect wholesale details after approval."
      profile={profile}
      title="Product catalog"
    >
      <AuthMessage error={getAuthMessage(params?.error)} status={getAuthMessage(params?.status)} />
      <form className="grid gap-3 rounded border border-[color:var(--line)] bg-white p-4 md:grid-cols-[1fr_220px_auto_auto]" method="get">
        <input
          className="rounded border border-[color:var(--line)] px-3 py-2 text-sm"
          defaultValue={query}
          name="q"
          placeholder="Search product, Arabic name, brand, or supplier"
        />
        <select className="rounded border border-[color:var(--line)] px-3 py-2 text-sm" defaultValue={categoryId} name="category">
          <option value="">All categories</option>
          {data.categories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name_en}
            </option>
          ))}
        </select>
        <label className="flex items-center gap-2 rounded border border-[color:var(--line)] px-3 py-2 text-sm">
          <input defaultChecked={availableOnly} name="available" type="checkbox" value="true" />
          <span>Available only</span>
        </label>
        <button className="rounded bg-[color:var(--brand)] px-4 py-2 text-sm font-semibold text-white">
          Search
        </button>
      </form>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {products.map((product) => (
          <ProductCard approved={approved} key={product.id ?? product.name_en} product={product} />
        ))}
      </div>
    </ShopShell>
  );
}
