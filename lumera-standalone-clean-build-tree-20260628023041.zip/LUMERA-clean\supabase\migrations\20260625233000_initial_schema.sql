create extension if not exists "pgcrypto";
create extension if not exists "pg_trgm";

create type public.user_role as enum ('merchant', 'supplier', 'admin');
create type public.approval_status as enum ('pending', 'approved', 'rejected');
create type public.delivery_eta as enum ('same_day', '24_hours', '48_hours', 'custom');
create type public.order_status as enum (
  'pending',
  'approved',
  'preparing',
  'out_for_delivery',
  'delivered',
  'rejected'
);
create type public.product_category as enum (
  'skincare',
  'haircare',
  'makeup',
  'fragrances',
  'beauty_tools',
  'other'
);
create type public.coverage_city as enum ('amman', 'irbid', 'zarqa', 'other');
create type public.notification_type as enum (
  'application_status',
  'order_status',
  'supplier_order',
  'admin_alert'
);

create function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create function public.current_user_role()
returns public.user_role
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

create function public.current_approval_status()
returns public.approval_status
language sql
stable
security definer
set search_path = public
as $$
  select approval_status from public.profiles where id = auth.uid()
$$;

create function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(public.current_user_role() = 'admin', false)
$$;

create function public.is_approved_merchant()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    public.current_user_role() = 'merchant'
    and public.current_approval_status() = 'approved',
    false
  )
$$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role public.user_role not null default 'merchant',
  approval_status public.approval_status not null default 'pending',
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.merchant_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  store_name text not null,
  owner_name text not null,
  phone_number text not null,
  city public.coverage_city not null,
  area text not null,
  business_license_path text not null,
  commercial_registration_path text not null,
  instagram_page text,
  status public.approval_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.supplier_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  company_name text not null,
  phone_number text not null,
  business_license_path text not null,
  commercial_registration_path text not null,
  status public.approval_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.merchants (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles(id) on delete cascade,
  application_id uuid unique references public.merchant_applications(id),
  store_name text not null,
  owner_name text not null,
  phone_number text not null,
  city public.coverage_city not null,
  area text not null,
  instagram_page text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles(id) on delete cascade,
  application_id uuid unique references public.supplier_applications(id),
  company_name text not null,
  phone_number text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_en text not null,
  name_ar text,
  product_category public.product_category not null default 'other',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.coverage_areas (
  id uuid primary key default gen_random_uuid(),
  city public.coverage_city not null,
  area text,
  label text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (city, area)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid not null references public.suppliers(id) on delete cascade,
  category_id uuid not null references public.categories(id),
  name_en text not null,
  name_ar text,
  image_path text not null,
  brand text not null,
  wholesale_price numeric(12, 3) not null check (wholesale_price >= 0),
  available_quantity integer not null default 0 check (available_quantity >= 0),
  minimum_order_quantity integer not null default 1 check (minimum_order_quantity > 0),
  delivery_eta public.delivery_eta not null default '24_hours',
  custom_delivery_eta text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_coverage_areas (
  product_id uuid not null references public.products(id) on delete cascade,
  coverage_area_id uuid not null references public.coverage_areas(id) on delete cascade,
  primary key (product_id, coverage_area_id)
);

create table public.carts (
  id uuid primary key default gen_random_uuid(),
  merchant_id uuid not null unique references public.merchants(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null references public.carts(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  quantity integer not null check (quantity > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (cart_id, product_id)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  merchant_id uuid not null references public.merchants(id),
  supplier_id uuid not null references public.suppliers(id),
  status public.order_status not null default 'pending',
  delivery_city public.coverage_city not null,
  delivery_area text not null,
  delivery_address text,
  notes text,
  total_amount numeric(12, 3) not null default 0 check (total_amount >= 0),
  accepted_at timestamptz,
  rejected_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  product_name text not null,
  brand text not null,
  unit_price numeric(12, 3) not null check (unit_price >= 0),
  quantity integer not null check (quantity > 0),
  line_total numeric(12, 3) not null check (line_total >= 0),
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  type public.notification_type not null,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create view public.product_public_cards as
select
  products.id,
  products.name_en,
  products.name_ar,
  products.image_path,
  products.brand,
  categories.name_en as category_name_en,
  categories.name_ar as category_name_ar,
  products.created_at
from public.products
join public.categories on categories.id = products.category_id
where products.is_active = true
and categories.is_active = true;

create index profiles_role_idx on public.profiles(role);
create index profiles_approval_status_idx on public.profiles(approval_status);
create index products_supplier_id_idx on public.products(supplier_id);
create index products_category_id_idx on public.products(category_id);
create index products_brand_idx on public.products(brand);
create index products_name_en_trgm_idx on public.products using gin (name_en gin_trgm_ops);
create index products_name_ar_trgm_idx on public.products using gin (name_ar gin_trgm_ops);
create index orders_merchant_id_idx on public.orders(merchant_id);
create index orders_supplier_id_idx on public.orders(supplier_id);
create index orders_status_idx on public.orders(status);
create index notifications_recipient_id_idx on public.notifications(recipient_id);

create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create trigger merchant_applications_set_updated_at
before update on public.merchant_applications
for each row execute function public.set_updated_at();

create trigger supplier_applications_set_updated_at
before update on public.supplier_applications
for each row execute function public.set_updated_at();

create trigger merchants_set_updated_at
before update on public.merchants
for each row execute function public.set_updated_at();

create trigger suppliers_set_updated_at
before update on public.suppliers
for each row execute function public.set_updated_at();

create trigger categories_set_updated_at
before update on public.categories
for each row execute function public.set_updated_at();

create trigger products_set_updated_at
before update on public.products
for each row execute function public.set_updated_at();

create trigger carts_set_updated_at
before update on public.carts
for each row execute function public.set_updated_at();

create trigger cart_items_set_updated_at
before update on public.cart_items
for each row execute function public.set_updated_at();

create trigger orders_set_updated_at
before update on public.orders
for each row execute function public.set_updated_at();

create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_role public.user_role;
begin
  requested_role := case new.raw_user_meta_data ->> 'role'
    when 'supplier' then 'supplier'::public.user_role
    when 'admin' then 'admin'::public.user_role
    else 'merchant'::public.user_role
  end;

  insert into public.profiles (id, email, role, approval_status, display_name)
  values (
    new.id,
    new.email,
    requested_role,
    'pending',
    coalesce(new.raw_user_meta_data ->> 'display_name', new.raw_user_meta_data ->> 'full_name')
  )
  on conflict (id) do update set
    email = excluded.email,
    role = excluded.role,
    display_name = excluded.display_name;

  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.merchant_applications enable row level security;
alter table public.supplier_applications enable row level security;
alter table public.merchants enable row level security;
alter table public.suppliers enable row level security;
alter table public.categories enable row level security;
alter table public.coverage_areas enable row level security;
alter table public.products enable row level security;
alter table public.product_coverage_areas enable row level security;
alter table public.carts enable row level security;
alter table public.cart_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.notifications enable row level security;

create policy "Users can read their own profile"
on public.profiles for select
to authenticated
using (id = auth.uid() or public.is_admin());

create policy "Users can update their own display name"
on public.profiles for update
to authenticated
using (id = auth.uid())
with check (
  id = auth.uid()
  and role = (select role from public.profiles where id = auth.uid())
  and approval_status = (select approval_status from public.profiles where id = auth.uid())
);

create policy "Admins can manage profiles"
on public.profiles for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Merchants can create their application"
on public.merchant_applications for insert
to authenticated
with check (user_id = auth.uid() and public.current_user_role() = 'merchant');

create policy "Merchants can read their application"
on public.merchant_applications for select
to authenticated
using (user_id = auth.uid() or public.is_admin());

create policy "Merchants can update pending application"
on public.merchant_applications for update
to authenticated
using (user_id = auth.uid() and status = 'pending')
with check (user_id = auth.uid() and status = 'pending');

create policy "Admins can manage merchant applications"
on public.merchant_applications for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Suppliers can create their application"
on public.supplier_applications for insert
to authenticated
with check (user_id = auth.uid() and public.current_user_role() = 'supplier');

create policy "Suppliers can read their application"
on public.supplier_applications for select
to authenticated
using (user_id = auth.uid() or public.is_admin());

create policy "Suppliers can update pending application"
on public.supplier_applications for update
to authenticated
using (user_id = auth.uid() and status = 'pending')
with check (user_id = auth.uid() and status = 'pending');

create policy "Admins can manage supplier applications"
on public.supplier_applications for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Merchants can read their merchant record"
on public.merchants for select
to authenticated
using (profile_id = auth.uid() or public.is_admin());

create policy "Admins can manage merchants"
on public.merchants for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Suppliers can read their supplier record"
on public.suppliers for select
to authenticated
using (profile_id = auth.uid() or public.is_admin());

create policy "Admins can manage suppliers"
on public.suppliers for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Everyone authenticated can read active categories"
on public.categories for select
to authenticated
using (is_active = true or public.is_admin());

create policy "Admins can manage categories"
on public.categories for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Everyone authenticated can read active coverage areas"
on public.coverage_areas for select
to authenticated
using (is_active = true or public.is_admin());

create policy "Admins can manage coverage areas"
on public.coverage_areas for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Approved merchants and owners can read full products"
on public.products for select
to authenticated
using (
  public.is_admin()
  or public.is_approved_merchant()
  or exists (
    select 1 from public.suppliers
    where suppliers.id = products.supplier_id
    and suppliers.profile_id = auth.uid()
  )
);

create policy "Suppliers can manage their products"
on public.products for all
to authenticated
using (
  exists (
    select 1 from public.suppliers
    where suppliers.id = products.supplier_id
    and suppliers.profile_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from public.suppliers
    where suppliers.id = products.supplier_id
    and suppliers.profile_id = auth.uid()
  )
);

create policy "Admins can manage products"
on public.products for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Authenticated users can read product coverage"
on public.product_coverage_areas for select
to authenticated
using (true);

create policy "Suppliers can manage product coverage"
on public.product_coverage_areas for all
to authenticated
using (
  exists (
    select 1
    from public.products
    join public.suppliers on suppliers.id = products.supplier_id
    where products.id = product_coverage_areas.product_id
    and suppliers.profile_id = auth.uid()
  )
)
with check (
  exists (
    select 1
    from public.products
    join public.suppliers on suppliers.id = products.supplier_id
    where products.id = product_coverage_areas.product_id
    and suppliers.profile_id = auth.uid()
  )
);

create policy "Admins can manage product coverage"
on public.product_coverage_areas for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Merchants can manage their cart"
on public.carts for all
to authenticated
using (
  exists (
    select 1 from public.merchants
    where merchants.id = carts.merchant_id
    and merchants.profile_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from public.merchants
    where merchants.id = carts.merchant_id
    and merchants.profile_id = auth.uid()
  )
);

create policy "Merchants can manage their cart items"
on public.cart_items for all
to authenticated
using (
  exists (
    select 1
    from public.carts
    join public.merchants on merchants.id = carts.merchant_id
    where carts.id = cart_items.cart_id
    and merchants.profile_id = auth.uid()
  )
)
with check (
  exists (
    select 1
    from public.carts
    join public.merchants on merchants.id = carts.merchant_id
    where carts.id = cart_items.cart_id
    and merchants.profile_id = auth.uid()
  )
);

create policy "Order participants can read orders"
on public.orders for select
to authenticated
using (
  public.is_admin()
  or exists (
    select 1 from public.merchants
    where merchants.id = orders.merchant_id
    and merchants.profile_id = auth.uid()
  )
  or exists (
    select 1 from public.suppliers
    where suppliers.id = orders.supplier_id
    and suppliers.profile_id = auth.uid()
  )
);

create policy "Approved merchants can create orders"
on public.orders for insert
to authenticated
with check (
  public.is_approved_merchant()
  and exists (
    select 1 from public.merchants
    where merchants.id = orders.merchant_id
    and merchants.profile_id = auth.uid()
  )
);

create policy "Suppliers can update their orders"
on public.orders for update
to authenticated
using (
  exists (
    select 1 from public.suppliers
    where suppliers.id = orders.supplier_id
    and suppliers.profile_id = auth.uid()
  )
)
with check (
  exists (
    select 1 from public.suppliers
    where suppliers.id = orders.supplier_id
    and suppliers.profile_id = auth.uid()
  )
);

create policy "Admins can manage orders"
on public.orders for all
to authenticated
using (public.is_admin())
with check (public.is_admin());

create policy "Order participants can read order items"
on public.order_items for select
to authenticated
using (
  exists (
    select 1 from public.orders
    where orders.id = order_items.order_id
    and (
      public.is_admin()
      or exists (
        select 1 from public.merchants
        where merchants.id = orders.merchant_id
        and merchants.profile_id = auth.uid()
      )
      or exists (
        select 1 from public.suppliers
        where suppliers.id = orders.supplier_id
        and suppliers.profile_id = auth.uid()
      )
    )
  )
);

create policy "Approved merchants can create order items"
on public.order_items for insert
to authenticated
with check (
  public.is_approved_merchant()
  and exists (
    select 1
    from public.orders
    join public.merchants on merchants.id = orders.merchant_id
    where orders.id = order_items.order_id
    and merchants.profile_id = auth.uid()
  )
);

create policy "Users can read their notifications"
on public.notifications for select
to authenticated
using (recipient_id = auth.uid() or public.is_admin());

create policy "Users can mark notifications read"
on public.notifications for update
to authenticated
using (recipient_id = auth.uid())
with check (recipient_id = auth.uid());

create policy "Admins can create notifications"
on public.notifications for insert
to authenticated
with check (public.is_admin());

insert into public.categories (slug, name_en, product_category)
values
  ('skincare', 'Skincare', 'skincare'),
  ('haircare', 'Haircare', 'haircare'),
  ('makeup', 'Makeup', 'makeup'),
  ('fragrances', 'Fragrances', 'fragrances'),
  ('beauty-tools', 'Beauty Tools', 'beauty_tools')
on conflict (slug) do nothing;

insert into public.coverage_areas (city, area, label)
values
  ('amman', null, 'Amman'),
  ('irbid', null, 'Irbid'),
  ('zarqa', null, 'Zarqa'),
  ('other', null, 'Other cities')
on conflict (city, area) do nothing;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-images', 'product-images', true, 5242880, array['image/jpeg', 'image/png', 'image/webp']),
  (
    'business-documents',
    'business-documents',
    false,
    10485760,
    array['application/pdf', 'image/jpeg', 'image/png', 'image/webp']
  )
on conflict (id) do nothing;

create policy "Authenticated users can view product images"
on storage.objects for select
to authenticated
using (bucket_id = 'product-images');

create policy "Suppliers can upload product images"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'product-images'
  and public.current_user_role() = 'supplier'
);

create policy "Users can upload their business documents"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'business-documents'
  and owner = auth.uid()
);

create policy "Users can view their business documents"
on storage.objects for select
to authenticated
using (
  bucket_id = 'business-documents'
  and (owner = auth.uid() or public.is_admin())
);

grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant select on public.product_public_cards to authenticated;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.current_approval_status() to authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_approved_merchant() to authenticated;
