type StatusCardProps = {
  title: string;
  body: string;
};

export function StatusCard({ title, body }: StatusCardProps) {
  return (
    <article className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5 shadow-sm">
      <h2 className="font-semibold">{title}</h2>
      <p className="mt-2 text-sm leading-6 text-[color:var(--muted)]">{body}</p>
    </article>
  );
}
