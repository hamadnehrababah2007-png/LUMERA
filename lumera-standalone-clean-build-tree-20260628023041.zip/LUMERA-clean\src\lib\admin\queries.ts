import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Database } from "@/types/database";

export type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"];
export type MerchantApplicationRow = Database["public"]["Tables"]["merchant_applications"]["Row"];
export type SupplierApplicationRow = Database["public"]["Tables"]["supplier_applications"]["Row"];
export type CategoryRow = Database["public"]["Tables"]["categories"]["Row"];
export type ProductRow = Database["public"]["Tables"]["products"]["Row"];
export type OrderRow = Database["public"]["Tables"]["orders"]["Row"];

async function unwrap<T>(promise: PromiseLike<{ data: T | null; error: { message: string } | null }>) {
  const { data, error } = await promise;

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function getAdminDashboardData() {
  const supabase = await createSupabaseServerClient();

  const [
    profiles,
    merchantApplications,
    supplierApplications,
    categories,
    products,
    orders,
  ] = await Promise.all([
    unwrap(
      supabase
        .from("profiles")
        .select("id,email,role,approval_status,display_name,created_at,updated_at")
        .order("created_at", { ascending: false })
        .limit(20),
    ),
    unwrap(
      supabase
        .from("merchant_applications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20),
    ),
    unwrap(
      supabase
        .from("supplier_applications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20),
    ),
    unwrap(
      supabase
        .from("categories")
        .select("*")
        .order("name_en", { ascending: true }),
    ),
    unwrap(
      supabase
        .from("products")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20),
    ),
    unwrap(
      supabase
        .from("orders")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20),
    ),
  ]);

  return {
    profiles: profiles ?? [],
    merchantApplications: merchantApplications ?? [],
    supplierApplications: supplierApplications ?? [],
    categories: categories ?? [],
    products: products ?? [],
    orders: orders ?? [],
  };
}
