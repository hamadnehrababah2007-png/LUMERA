import type { ReactNode } from "react";

type AdminSectionProps = {
  title: string;
  description: string;
  children: ReactNode;
};

export function AdminSection({ title, description, children }: AdminSectionProps) {
  return (
    <section className="rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5 shadow-sm">
      <div className="border-b border-[color:var(--line)] pb-4">
        <h2 className="text-xl font-semibold">{title}</h2>
        <p className="mt-2 text-sm leading-6 text-[color:var(--muted)]">{description}</p>
      </div>
      <div className="mt-5">{children}</div>
    </section>
  );
}
