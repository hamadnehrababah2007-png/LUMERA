import { NextResponse, type NextRequest } from "next/server";

import { profileFromUser } from "@/lib/auth/profile";
import { roleHomeRoutes, routes } from "@/lib/routes";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");

  if (code) {
    const supabase = await createSupabaseServerClient();
    await supabase.auth.exchangeCodeForSession(code);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (user) {
      const profile = profileFromUser(user);
      return NextResponse.redirect(new URL(roleHomeRoutes[profile.role], requestUrl.origin));
    }
  }

  return NextResponse.redirect(new URL(routes.signIn, requestUrl.origin));
}
