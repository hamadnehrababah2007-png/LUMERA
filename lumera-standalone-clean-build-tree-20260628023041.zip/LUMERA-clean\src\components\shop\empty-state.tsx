export function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded border border-dashed border-[color:var(--line)] bg-white px-4 py-8 text-center text-sm text-[color:var(--muted)]">
      {label}
    </div>
  );
}
