import type { SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@/types/database";

export type PublicProductCard = Database["public"]["Views"]["product_public_cards"]["Row"];
export type ProductRow = Database["public"]["Tables"]["products"]["Row"];

export async function listPublicProductCards(supabase: SupabaseClient<Database>) {
  return supabase
    .from("product_public_cards")
    .select("id,name_en,name_ar,image_path,brand,category_name_en,category_name_ar,created_at")
    .order("created_at", { ascending: false });
}

export async function listFullProducts(supabase: SupabaseClient<Database>) {
  return supabase
    .from("products")
    .select(
      "id,supplier_id,category_id,name_en,name_ar,image_path,brand,wholesale_price,available_quantity,minimum_order_quantity,delivery_eta,custom_delivery_eta,is_active,created_at,updated_at",
    )
    .eq("is_active", true)
    .order("created_at", { ascending: false });
}
