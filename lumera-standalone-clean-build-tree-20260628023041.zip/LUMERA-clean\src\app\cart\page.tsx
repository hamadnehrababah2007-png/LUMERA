import { checkoutCartAction, removeCartItemAction, updateCartItemAction } from "@/app/shop/actions";
import { AuthMessage } from "@/components/auth/auth-message";
import { StatusPill } from "@/components/admin/status-pill";
import { EmptyState } from "@/components/shop/empty-state";
import { ShopShell } from "@/components/shop/shop-shell";
import { requireRole } from "@/lib/auth/guards";
import { getAuthMessage } from "@/lib/auth/messages";
import { getCartDetails, getMerchantForProfile } from "@/lib/shop/queries";

type CartPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function CartPage({ searchParams }: CartPageProps) {
  const params = await searchParams;
  const profile = await requireRole("merchant");
  const merchant = await getMerchantForProfile(profile.id);
  const approved = profile.approvalStatus === "approved" && Boolean(merchant);
  const cart = merchant ? await getCartDetails(merchant.id) : { cart: null, items: [], total: 0, hasInvalidItems: false };

  return (
    <ShopShell
      description="Review cart quantities, validate minimum order quantities, and submit wholesale orders to suppliers."
      profile={profile}
      title="Shopping cart"
    >
      <AuthMessage error={getAuthMessage(params?.error)} status={getAuthMessage(params?.status)} />
      {!approved ? (
        <section className="rounded border border-amber-200 bg-amber-50 p-5 text-amber-900">
          Wholesale prices are available only for verified cosmetics businesses.
        </section>
      ) : null}
      {approved && cart.items.length === 0 ? <EmptyState label="Your cart is empty." /> : null}
      {approved && cart.items.length > 0 ? (
        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          <section className="grid gap-4">
            {cart.items.map((item) => (
              <article className="rounded border border-[color:var(--line)] bg-white p-4" key={item.id}>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <h2 className="font-semibold">{item.product?.name_en ?? "Unavailable product"}</h2>
                    <p className="mt-1 text-sm text-[color:var(--muted)]">{item.product?.brand}</p>
                    <p className="mt-2 text-sm text-[color:var(--muted)]">
                      MOQ {item.product?.minimum_order_quantity ?? "-"} - Stock {item.product?.available_quantity ?? "-"}
                    </p>
                    {(item.belowMinimum || item.aboveStock) ? (
                      <div className="mt-3">
                        <StatusPill value={item.belowMinimum ? "below moq" : "above stock"} />
                      </div>
                    ) : null}
                  </div>
                  <p className="text-lg font-semibold">{item.lineTotal.toFixed(3)} JOD</p>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <form action={updateCartItemAction} className="flex gap-2">
                    <input name="cartItemId" type="hidden" value={item.id} />
                    <input
                      className="w-24 rounded border border-[color:var(--line)] px-3 py-2 text-sm"
                      defaultValue={item.quantity}
                      min="1"
                      name="quantity"
                      required
                      type="number"
                    />
                    <button className="rounded bg-[color:var(--brand)] px-3 py-2 text-sm font-semibold text-white">
                      Update
                    </button>
                  </form>
                  <form action={removeCartItemAction}>
                    <input name="cartItemId" type="hidden" value={item.id} />
                    <button className="rounded border border-red-200 px-3 py-2 text-sm font-semibold text-red-700">
                      Remove
                    </button>
                  </form>
                </div>
              </article>
            ))}
          </section>
          <aside className="h-fit rounded border border-[color:var(--line)] bg-[color:var(--panel)] p-5 shadow-sm">
            <h2 className="text-xl font-semibold">Checkout</h2>
            <p className="mt-2 text-sm text-[color:var(--muted)]">
              Orders are split by supplier and sent as pending requests.
            </p>
            <p className="mt-5 text-3xl font-semibold">{cart.total.toFixed(3)} JOD</p>
            <form action={checkoutCartAction} className="mt-5 grid gap-3">
              <label className="block">
                <span className="text-sm font-medium">Delivery city</span>
                <select className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="deliveryCity" required>
                  <option value="amman">Amman</option>
                  <option value="irbid">Irbid</option>
                  <option value="zarqa">Zarqa</option>
                  <option value="other">Other city</option>
                </select>
              </label>
              <label className="block">
                <span className="text-sm font-medium">Delivery area</span>
                <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="deliveryArea" required />
              </label>
              <label className="block">
                <span className="text-sm font-medium">Address</span>
                <input className="mt-2 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="deliveryAddress" />
              </label>
              <label className="block">
                <span className="text-sm font-medium">Notes</span>
                <textarea className="mt-2 min-h-24 w-full rounded border border-[color:var(--line)] bg-white px-3 py-2" name="notes" />
              </label>
              <button
                className="rounded bg-[color:var(--brand)] px-4 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
                disabled={cart.hasInvalidItems}
              >
                Place order
              </button>
            </form>
          </aside>
        </div>
      ) : null}
    </ShopShell>
  );
}
