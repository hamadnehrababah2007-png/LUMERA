type StatusPillProps = {
  value: string;
};

export function StatusPill({ value }: StatusPillProps) {
  const tone =
    value === "approved" || value === "delivered" || value === "active"
      ? "border-emerald-200 bg-emerald-50 text-emerald-800"
      : value === "rejected" || value === "inactive"
        ? "border-red-200 bg-red-50 text-red-800"
        : "border-amber-200 bg-amber-50 text-amber-800";

  return (
    <span className={`inline-flex rounded border px-2 py-1 text-xs font-semibold capitalize ${tone}`}>
      {value.replaceAll("_", " ")}
    </span>
  );
}
