create type public.user_role as enum ('merchant', 'supplier', 'admin');
create type public.application_status as enum ('pending', 'approved', 'rejected');
create type public.order_status as enum ('pending', 'approved', 'preparing', 'out_for_delivery', 'delivered', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role user_role not null,
  display_name text not null,
  phone text,
  status application_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.merchants (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  store_name text not null,
  owner_name text not null,
  city text not null,
  area text not null,
  business_license_url text not null,
  commercial_registration_url text not null,
  instagram_page text,
  status application_status not null default 'pending'
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  company_name text not null,
  phone text not null,
  business_license_url text not null,
  commercial_registration_url text not null,
  status application_status not null default 'pending'
);

create table public.application_documents (
  id uuid primary key default gen_random_uuid(),
  application_kind text not null check (application_kind in ('merchant', 'supplier')),
  merchant_id uuid references public.merchants(id) on delete cascade,
  supplier_id uuid references public.suppliers(id) on delete cascade,
  label text not null,
  file_name text not null,
  file_type text not null,
  file_size integer not null,
  storage_path text not null,
  created_at timestamptz not null default now(),
  check (
    (application_kind = 'merchant' and merchant_id is not null and supplier_id is null)
    or
    (application_kind = 'supplier' and supplier_id is not null and merchant_id is null)
  )
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name_en text not null,
  name_ar text,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid not null references public.suppliers(id) on delete cascade,
  category_id uuid not null references public.categories(id),
  name_en text not null,
  name_ar text,
  brand text not null,
  image_url text not null,
  images text[] not null default '{}',
  wholesale_price numeric(10,2) not null,
  available_quantity integer not null,
  minimum_order_quantity integer not null,
  delivery_eta text not null,
  coverage_areas text[] not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  merchant_id uuid not null references public.merchants(id),
  supplier_id uuid not null references public.suppliers(id),
  status order_status not null default 'pending',
  total numeric(10,2) not null,
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null,
  unit_price numeric(10,2) not null
);

alter table public.profiles enable row level security;
alter table public.merchants enable row level security;
alter table public.suppliers enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.application_documents enable row level security;

create policy "Profiles are readable by signed in users" on public.profiles for select to authenticated using (true);
create policy "Categories are readable by everyone" on public.categories for select using (true);
create policy "Products public preview" on public.products for select using (active = true);
create policy "Users manage own profile" on public.profiles for update using (auth.uid() = id);

create policy "Admins read application documents" on public.application_documents
  for select to authenticated
  using (
    exists (
      select 1 from public.profiles
      where profiles.id = auth.uid()
      and profiles.role = 'admin'
    )
  );

create policy "Applicants add merchant documents" on public.application_documents
  for insert to authenticated
  with check (
    application_kind = 'merchant'
    and exists (
      select 1 from public.merchants
      where merchants.id = application_documents.merchant_id
      and merchants.profile_id = auth.uid()
    )
  );

create policy "Applicants add supplier documents" on public.application_documents
  for insert to authenticated
  with check (
    application_kind = 'supplier'
    and exists (
      select 1 from public.suppliers
      where suppliers.id = application_documents.supplier_id
      and suppliers.profile_id = auth.uid()
    )
  );

insert into storage.buckets (id, name, public)
values ('verification-documents', 'verification-documents', false)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "Applicants upload verification documents" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'verification-documents'
    and (storage.foldername(name))[1] in ('merchant', 'supplier')
    and (storage.foldername(name))[2] = auth.uid()::text
  );

create policy "Admins read verification documents" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'verification-documents'
    and exists (
      select 1 from public.profiles
      where profiles.id = auth.uid()
      and profiles.role = 'admin'
    )
  );

create policy "Suppliers upload product images" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'product-images');

create policy "Product images are publicly readable" on storage.objects
  for select
  using (bucket_id = 'product-images');
