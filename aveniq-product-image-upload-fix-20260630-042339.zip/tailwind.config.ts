import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "rgb(var(--color-ink) / <alpha-value>)",
        moss: "rgb(var(--color-moss) / <alpha-value>)",
        mint: "rgb(var(--color-mint) / <alpha-value>)",
        rose: "rgb(var(--color-rose) / <alpha-value>)",
        apricot: "rgb(var(--color-apricot) / <alpha-value>)",
        porcelain: "rgb(var(--color-porcelain) / <alpha-value>)",
        panel: "rgb(var(--color-panel) / <alpha-value>)",
        line: "rgb(var(--color-line) / <alpha-value>)"
      },
      boxShadow: {
        soft: "0 18px 50px rgb(var(--shadow-soft) / 0.14)",
        glow: "0 24px 80px rgb(var(--color-rose) / 0.22)"
      }
    }
  },
  plugins: []
};

export default config;
