import Image from "next/image";
import { cn } from "@/lib/utils";

export function AveniqBrand({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-4", className)}>
      <span className="relative grid size-[3.25rem] place-items-center overflow-hidden rounded-2xl bg-[#111827] shadow-glow ring-1 ring-white/10">
        <Image src="/aveniq-favicon.png" alt="" fill className="object-cover" sizes="52px" priority />
      </span>
      {!compact ? (
        <span>
          <span className="block text-xl font-semibold leading-tight tracking-normal text-ink">Aveniq</span>
        </span>
      ) : null}
    </span>
  );
}
