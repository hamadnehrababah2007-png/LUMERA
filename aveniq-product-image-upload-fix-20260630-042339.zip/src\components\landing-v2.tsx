"use client";

import Link from "next/link";
import {
  ArrowRight,
  Boxes,
  CircleDollarSign,
  Clock3,
  Factory,
  LineChart,
  PackageCheck,
  RadioTower,
  Search,
  ShieldCheck,
  Sparkles,
  Store,
  Truck,
  Users
} from "lucide-react";
import { AveniqBrand } from "@/components/brand";

const activity = [
  ["Order #4821 approved", "Amman Supply Co.", "now"],
  ["24 products synced", "Levant Distributor", "18s"],
  ["Supplier ETA updated", "North Trade Hub", "42s"],
  ["Retailer verification passed", "Irbid Market", "1m"]
];

const bars = [36, 58, 44, 72, 64, 86, 76, 94];

const audiences = [
  {
    icon: Store,
    title: "Built for Retailers",
    text: "Find trusted suppliers, compare availability, and move from discovery to purchase without fragmented conversations."
  },
  {
    icon: Factory,
    title: "Built for Suppliers",
    text: "Manage products, pricing, stock, coverage, and orders from a single operating layer built for B2B trade."
  },
  {
    icon: Truck,
    title: "Built for Distributors",
    text: "Coordinate demand, fulfillment, and partner visibility across a network that scales with every relationship."
  }
];

const stats = [
  ["3.8x", "faster product discovery"],
  ["91%", "verified network visibility"],
  ["24h", "average supplier response"],
  ["1", "system of record"]
];

const metricCards = [
  { icon: PackageCheck, value: "182", label: "active SKUs" },
  { icon: Users, value: "47", label: "verified buyers" },
  { icon: Clock3, value: "24h", label: "avg. ETA" }
];

const platformItems = [
  { icon: ShieldCheck, label: "Verified trust layer" },
  { icon: Search, label: "Instant discovery" },
  { icon: Boxes, label: "Supplier operations" },
  { icon: LineChart, label: "Commercial visibility" }
];

export function LandingV2() {
  return (
    <div
      className="landing-v2 relative isolate overflow-hidden bg-[#070812] text-white"
      onMouseMove={(event) => {
        const target = event.currentTarget;
        target.style.setProperty("--mouse-x", `${event.clientX}px`);
        target.style.setProperty("--mouse-y", `${event.clientY}px`);
      }}
    >
      <div className="pointer-events-none fixed inset-0 z-0 bg-[radial-gradient(circle_at_var(--mouse-x,50%)_var(--mouse-y,20%),rgba(167,139,250,0.18),transparent_24rem)] transition-[background] duration-300" />
      <div className="pointer-events-none absolute inset-0 z-0 bg-[radial-gradient(circle_at_18%_8%,rgba(124,58,237,0.34),transparent_30rem),radial-gradient(circle_at_78%_12%,rgba(79,70,229,0.22),transparent_28rem),linear-gradient(rgba(255,255,255,0.045)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.045)_1px,transparent_1px)] bg-[size:100%_100%,100%_100%,56px_56px,56px_56px]" />
      <div className="pointer-events-none absolute inset-0 z-0 bg-[linear-gradient(180deg,transparent,rgba(7,8,18,0.72)_58%,#070812)]" />

      <section className="relative z-10 mx-auto grid min-h-[86vh] max-w-7xl items-center gap-12 px-4 pb-16 pt-10 sm:px-6 lg:grid-cols-[1fr_1.05fr] lg:pt-4">
        <div className="animate-rise max-w-3xl">
          <AveniqBrand className="mb-10 [&_span:last-child_span]:text-white [&_span:first-child]:size-14" />
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-4 py-2 text-sm font-medium text-white/78 shadow-2xl backdrop-blur-xl">
            <Sparkles className="size-4 text-violet-300" />
            Intelligent commerce infrastructure
          </div>
          <h1 className="text-6xl font-semibold tracking-[-0.03em] text-white sm:text-7xl lg:text-8xl">
            The Future of Wholesale Commerce.
          </h1>
          <p className="mt-7 max-w-2xl text-lg leading-8 text-white/68 sm:text-xl">
            Aveniq connects retailers, suppliers, and distributors through one intelligent operating system.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link className="group inline-flex min-h-12 items-center rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-[#0b0c16] shadow-[0_20px_70px_rgba(255,255,255,0.18)] transition duration-300 hover:-translate-y-1" href="/join">
              Join Aveniq <ArrowRight className="ml-2 size-4 transition group-hover:translate-x-0.5" />
            </Link>
            <Link className="inline-flex min-h-12 items-center rounded-2xl border border-white/12 bg-white/[0.06] px-5 py-3 text-sm font-semibold text-white shadow-2xl backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:bg-white/[0.1]" href="/products">
              Watch Demo
            </Link>
          </div>
        </div>

        <LivingDashboard />
      </section>

      <StorySection />
      <AudienceSection />
      <WhyAveniq />
      <StatsSection />
      <Testimonials />
      <FinalCta />
    </div>
  );
}

function LivingDashboard() {
  return (
    <div className="animate-rise relative rounded-[2rem] border border-white/10 bg-white/[0.055] p-3 shadow-[0_34px_120px_rgba(0,0,0,0.55)] backdrop-blur-2xl lg:translate-y-4" style={{ animationDelay: "140ms" }}>
      <div className="absolute -inset-1 rounded-[2.2rem] bg-gradient-to-br from-violet-500/25 via-transparent to-indigo-500/15 blur-xl" />
      <div className="relative overflow-hidden rounded-[1.6rem] border border-white/10 bg-[#0d0f1d]">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div>
            <p className="text-sm text-white/50">Live commerce network</p>
            <p className="mt-1 font-semibold text-white">Aveniq Command</p>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-xs text-emerald-200">
            <span className="size-2 animate-pulse rounded-full bg-emerald-300" />
            Live
          </div>
        </div>

        <div className="grid gap-4 p-5 lg:grid-cols-[1fr_0.82fr]">
          <div className="space-y-4">
            <div className="rounded-3xl border border-white/10 bg-white/[0.045] p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm text-white/50">Network GMV</p>
                  <p className="mt-2 text-4xl font-semibold tracking-tight text-white">JOD 248,920</p>
                </div>
                <CircleDollarSign className="size-7 text-violet-300" />
              </div>
              <div className="mt-8 grid h-28 grid-cols-8 items-end gap-2">
                {bars.map((height, index) => (
                  <div key={height} className="rounded-full bg-white/[0.07] p-1">
                    <div
                      className="dashboard-bar rounded-full bg-gradient-to-t from-violet-600 via-indigo-400 to-violet-200 shadow-[0_0_24px_rgba(167,139,250,0.45)]"
                      style={{ height: `${height}%`, animationDelay: `${index * 140}ms` }}
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              {metricCards.map(({ icon: Icon, value, label }) => (
                <div key={label} className="rounded-3xl border border-white/10 bg-white/[0.045] p-4">
                  <Icon className="size-5 text-violet-300" />
                  <p className="mt-4 text-2xl font-semibold">{value}</p>
                  <p className="mt-1 text-sm text-white/48">{label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/[0.045] p-4">
            <div className="mb-4 flex items-center justify-between">
              <p className="font-medium text-white">Activity stream</p>
              <RadioTower className="size-4 text-violet-300" />
            </div>
            <div className="space-y-3">
              {activity.map(([title, source, time], index) => (
                <div key={title} className="activity-row rounded-2xl border border-white/10 bg-[#11131f] p-3" style={{ animationDelay: `${index * 260}ms` }}>
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-sm font-medium text-white">{title}</p>
                    <span className="text-xs text-white/36">{time}</span>
                  </div>
                  <p className="mt-1 text-xs text-white/46">{source}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-2xl border border-violet-300/20 bg-violet-400/10 p-3 text-sm text-violet-100">
              Supplier response time improved by 31% this week.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StorySection() {
  const steps = [
    ["Current Wholesale Problems", "Pricing, availability, approvals, and delivery promises live across disconnected channels."],
    ["Disconnected Tools", "Retailers and suppliers lose time reconciling conversations instead of growing trade."],
    ["Aveniq Platform", "One verified operating layer brings discovery, ordering, fulfillment, and visibility together."],
    ["Future of Commerce", "A trusted B2B network where every relationship moves faster with better intelligence."]
  ];

  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="grid gap-4 lg:grid-cols-4">
        {steps.map(([title, text], index) => (
          <div key={title} className="group rounded-[1.75rem] border border-white/10 bg-white/[0.045] p-6 backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-violet-300/40 hover:bg-white/[0.07]">
            <span className="text-sm text-violet-200/70">0{index + 1}</span>
            <h2 className="mt-5 text-xl font-semibold tracking-tight">{title}</h2>
            <p className="mt-3 text-sm leading-6 text-white/55">{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function AudienceSection() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="mb-10 max-w-3xl">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-violet-300">One network, every operator</p>
        <h2 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">Built for the teams moving wholesale forward.</h2>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        {audiences.map(({ icon: Icon, title, text }) => (
          <div key={title} className="rounded-[2rem] border border-white/10 bg-white/[0.05] p-7 shadow-2xl backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-violet-300/40 hover:bg-white/[0.075]">
            <span className="grid size-12 place-items-center rounded-2xl bg-violet-400/12 text-violet-200 ring-1 ring-violet-300/20">
              <Icon className="size-6" />
            </span>
            <h3 className="mt-8 text-2xl font-semibold">{title}</h3>
            <p className="mt-3 leading-7 text-white/58">{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function WhyAveniq() {
  return (
    <section className="relative z-10 mx-auto grid max-w-7xl gap-8 px-4 py-16 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-violet-300">Why Aveniq</p>
        <h2 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">A modern operating system for verified trade.</h2>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {platformItems.map(({ icon: Icon, label }) => (
          <div key={label} className="flex items-center gap-4 rounded-3xl border border-white/10 bg-white/[0.045] p-5 backdrop-blur-xl transition hover:-translate-y-1 hover:bg-white/[0.07]">
            <span className="grid size-11 place-items-center rounded-2xl bg-violet-400/12 text-violet-200 ring-1 ring-violet-300/20">
              <Icon className="size-5" />
            </span>
            <p className="font-medium">{label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function StatsSection() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="grid gap-4 rounded-[2rem] border border-white/10 bg-white/[0.05] p-5 backdrop-blur-xl sm:grid-cols-4">
        {stats.map(([value, label]) => (
          <div key={label} className="rounded-3xl bg-[#101221] p-6">
            <p className="text-4xl font-semibold tracking-tight text-white">{value}</p>
            <p className="mt-2 text-sm text-white/48">{label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="grid gap-4 lg:grid-cols-3">
        {[
          ["Aveniq turns supplier discovery into an operating advantage.", "Retail Director"],
          ["The network model finally matches how B2B trade actually works.", "Wholesale Supplier"],
          ["It feels less like a marketplace and more like infrastructure.", "Distribution Lead"]
        ].map(([quote, role]) => (
          <figure key={quote} className="rounded-[2rem] border border-white/10 bg-white/[0.045] p-6 backdrop-blur-xl">
            <blockquote className="text-lg leading-8 text-white/82">&ldquo;{quote}&rdquo;</blockquote>
            <figcaption className="mt-5 text-sm text-violet-200/70">{role}</figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="overflow-hidden rounded-[2.25rem] border border-white/10 bg-[radial-gradient(circle_at_50%_0%,rgba(167,139,250,0.26),transparent_38%),rgba(255,255,255,0.055)] p-8 text-center shadow-[0_30px_120px_rgba(0,0,0,0.45)] backdrop-blur-xl sm:p-14">
        <h2 className="mx-auto max-w-3xl text-4xl font-semibold tracking-tight sm:text-6xl">Build the next layer of B2B commerce with Aveniq.</h2>
        <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-white/58">Join the intelligent network connecting verified businesses with trusted suppliers.</p>
        <div className="mt-8 flex justify-center">
          <Link href="/join" className="inline-flex min-h-12 items-center rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-[#0b0c16] shadow-[0_20px_70px_rgba(255,255,255,0.18)] transition hover:-translate-y-1">
            Get Started <ArrowRight className="ml-2 size-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
