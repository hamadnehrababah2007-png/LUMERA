"use client";

import { useEffect, useState } from "react";
import { resolveProductImageUrl } from "@/lib/product-images";

export function ProductImage({ src, alt, className }: { src: string; alt: string; className?: string }) {
  const [resolvedSrc, setResolvedSrc] = useState(src);

  useEffect(() => {
    let active = true;
    resolveProductImageUrl(src)
      .then((url) => {
        if (active) setResolvedSrc(url);
      })
      .catch(() => {
        if (active) setResolvedSrc(src);
      });
    return () => {
      active = false;
    };
  }, [src]);

  // eslint-disable-next-line @next/next/no-img-element
  return <img src={resolvedSrc} alt={alt} className={className} />;
}
