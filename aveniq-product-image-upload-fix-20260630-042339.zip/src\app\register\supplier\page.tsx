"use client";

import { useState } from "react";
import Link from "next/link";
import { FileCheck2, Upload } from "lucide-react";
import { PageHeader, buttonClass, inputClass, secondaryButtonClass } from "@/components/ui";
import { createVerificationDocument, formatFileSize } from "@/lib/documents";
import { useMarketplace } from "@/lib/store";
import { VerificationDocument } from "@/lib/types";

const requiredDocuments = ["Business License", "Commercial Registration"];

export default function SupplierRegistrationPage() {
  const { registerSupplier, loginAs } = useMarketplace();
  const [submitted, setSubmitted] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [documentError, setDocumentError] = useState("");
  const [documents, setDocuments] = useState<VerificationDocument[]>([]);
  const [form, setForm] = useState({ companyName: "", phone: "" });

  const upsertDocument = (document: VerificationDocument) => {
    setDocuments((current) => [document, ...current.filter((item) => item.label !== document.label)]);
    setDocumentError("");
  };

  return (
    <>
      <PageHeader eyebrow="Supplier registration" title="Request supplier access to Aveniq." />
      <section className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        {submitted ? (
          <div className="rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur">
            <h2 className="text-xl font-bold">Application submitted</h2>
            <p className="mt-2 text-ink/65">Your supplier application is pending admin approval.</p>
            <Link href="/products" className={secondaryButtonClass + " mt-5"}>Return to catalog</Link>
          </div>
        ) : (
          <form
            className="grid gap-4 rounded-2xl border border-line bg-panel/88 p-6 shadow-sm backdrop-blur"
            onSubmit={(event) => {
              event.preventDefault();
              const hasRequiredDocument = requiredDocuments.some((label) => documents.some((document) => document.label === label));
              if (!hasRequiredDocument) {
                setDocumentError("Please upload a Business License or Commercial Registration.");
                return;
              }
              registerSupplier({ ...form, documents });
              loginAs("supplier", "pending");
              setSubmitted(true);
            }}
          >
            <input required className={inputClass} placeholder="Company Name" value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
            <input required className={inputClass} placeholder="Phone Number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <div className="rounded-2xl border border-line bg-porcelain/45 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-sm font-semibold text-ink">Verification documents</h2>
                  <p className="mt-1 text-xs text-ink/55">Upload one required document, then add optional proof if available.</p>
                </div>
                <span className="rounded-full bg-rose/10 px-3 py-1 text-xs font-semibold text-rose">Required</span>
              </div>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <FileField label="Business License" requirement="Required" document={documents.find((item) => item.label === "Business License")} onUpload={upsertDocument} setUploading={setIsUploading} />
                <FileField label="Commercial Registration" requirement="Required" document={documents.find((item) => item.label === "Commercial Registration")} onUpload={upsertDocument} setUploading={setIsUploading} />
              </div>
              <div className="mt-4 border-t border-line pt-4">
                <p className="mb-3 text-xs font-semibold uppercase tracking-[0.16em] text-ink/45">Optional</p>
                <div className="grid gap-3 sm:grid-cols-2">
                  <FileField label="Warehouse License" requirement="Optional" document={documents.find((item) => item.label === "Warehouse License")} onUpload={upsertDocument} setUploading={setIsUploading} />
                  <FileField label="Other Verification Document" requirement="Optional" document={documents.find((item) => item.label === "Other Verification Document")} onUpload={upsertDocument} setUploading={setIsUploading} />
                </div>
              </div>
            </div>
            {documentError ? <p className="text-sm font-medium text-rose">{documentError}</p> : null}
            <button className={buttonClass} disabled={isUploading}>{isUploading ? "Preparing documents..." : "Submit supplier application"}</button>
          </form>
        )}
      </section>
    </>
  );
}

function FileField({
  label,
  requirement,
  document,
  onUpload,
  setUploading
}: {
  label: string;
  requirement: "Required" | "Optional";
  document?: VerificationDocument;
  onUpload: (document: VerificationDocument) => void;
  setUploading: (value: boolean) => void;
}) {
  return (
    <label className="group flex min-h-20 cursor-pointer items-center gap-3 rounded-xl border border-dashed border-line bg-panel/80 px-4 py-3 text-sm font-medium transition hover:-translate-y-0.5 hover:border-violet/45 hover:bg-mint">
      {document ? <FileCheck2 className="size-5 text-emerald" /> : <Upload className="size-5 text-violet" />}
      <span className="min-w-0">
        <span className="flex flex-wrap items-center gap-2 text-ink">
          {label}
          <span className="rounded-full bg-mint px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink/55">{requirement}</span>
        </span>
        <span className="mt-1 block truncate text-xs font-normal text-ink/55">{document ? `${document.fileName} - ${formatFileSize(document.size)}` : "Upload image or document"}</span>
      </span>
      <input
        type="file"
        accept="image/*,.pdf,.doc,.docx"
        className="sr-only"
        onChange={async (event) => {
          const file = event.target.files?.[0];
          if (!file) return;
          setUploading(true);
          try {
            onUpload(await createVerificationDocument(file, label, "supplier"));
          } finally {
            setUploading(false);
          }
        }}
      />
    </label>
  );
}
