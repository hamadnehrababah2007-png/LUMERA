"use client";

import { createContext, ReactNode, useContext, useEffect, useMemo, useState } from "react";
import { categories as seedCategories, merchants as seedMerchants, orders as seedOrders, products as seedProducts, suppliers as seedSuppliers } from "@/lib/demo-data";
import { sanitizeProductImages } from "@/lib/product-images";
import { CartLine, Merchant, Order, OrderStatus, Product, Role, SessionUser, Status, Supplier, VerificationDocument } from "@/lib/types";

type MarketplaceState = {
  user: SessionUser;
  products: Product[];
  categories: typeof seedCategories;
  suppliers: Supplier[];
  merchants: Merchant[];
  orders: Order[];
  cart: CartLine[];
  loginAs: (role: Role, status?: Status) => void;
  addProduct: (product: Omit<Product, "id" | "supplierId" | "supplierName" | "active">) => void;
  updateProduct: (product: Product) => void;
  removeProduct: (id: string) => void;
  addToCart: (productId: string, quantity: number) => string | null;
  updateCart: (productId: string, quantity: number) => string | null;
  removeFromCart: (productId: string) => void;
  submitOrder: () => string | null;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  updateApplication: (kind: "merchant" | "supplier", id: string, status: Status) => void;
  registerMerchant: (merchant: Omit<Merchant, "id" | "status">) => void;
  registerSupplier: (supplier: Omit<Supplier, "id" | "status">) => void;
};

const StoreContext = createContext<MarketplaceState | null>(null);

const defaultUser: SessionUser = { role: "guest", name: "Visitor", status: "pending" };
const storageKey = "aveniq-market-state";

type PersistedState = Partial<Pick<MarketplaceState, "user" | "products" | "suppliers" | "merchants" | "orders" | "cart">>;

function sanitizeDocument(document: VerificationDocument): VerificationDocument {
  return {
    id: document.id,
    label: document.label,
    fileName: document.fileName,
    fileType: document.fileType,
    size: document.size,
    uploadedAt: document.uploadedAt,
    storagePath: document.storagePath
  };
}

function normalizeSuppliers(suppliers: Supplier[]) {
  return suppliers.map((supplier) => ({
    ...supplier,
    documents: (supplier.documents ?? []).map(sanitizeDocument)
  }));
}

function normalizeMerchants(merchants: Merchant[]) {
  return merchants.map((merchant) => ({
    ...merchant,
    documents: (merchant.documents ?? []).map(sanitizeDocument)
  }));
}

function normalizeProducts(products: Product[]) {
  return products.map(sanitizeProductImages);
}

function getPersistedState(state: Pick<MarketplaceState, "user" | "products" | "suppliers" | "merchants" | "orders" | "cart">): PersistedState {
  return {
    user: state.user,
    products: normalizeProducts(state.products),
    suppliers: normalizeSuppliers(state.suppliers),
    merchants: normalizeMerchants(state.merchants),
    orders: state.orders,
    cart: state.cart
  };
}

function clearPersistedState() {
  try {
    window.localStorage.removeItem(storageKey);
  } catch {
    // Storage may be unavailable in private browsing or restricted contexts.
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser>(defaultUser);
  const [products, setProducts] = useState(normalizeProducts(seedProducts));
  const [suppliers, setSuppliers] = useState(seedSuppliers);
  const [merchants, setMerchants] = useState(seedMerchants);
  const [orders, setOrders] = useState(seedOrders);
  const [cart, setCart] = useState<CartLine[]>([]);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (!stored) return;
      const parsed = JSON.parse(stored) as PersistedState;
      setUser(parsed.user ?? defaultUser);
      setProducts(normalizeProducts(parsed.products ?? seedProducts));
      setSuppliers(normalizeSuppliers(parsed.suppliers ?? seedSuppliers));
      setMerchants(normalizeMerchants(parsed.merchants ?? seedMerchants));
      setOrders(parsed.orders ?? seedOrders);
      setCart(parsed.cart ?? []);
    } catch {
      clearPersistedState();
      setUser(defaultUser);
      setProducts(normalizeProducts(seedProducts));
      setSuppliers(seedSuppliers);
      setMerchants(seedMerchants);
      setOrders(seedOrders);
      setCart([]);
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(getPersistedState({ user, products, suppliers, merchants, orders, cart })));
    } catch {
      clearPersistedState();
      try {
        window.localStorage.setItem(storageKey, JSON.stringify({ user, cart }));
      } catch {
        clearPersistedState();
      }
    }
  }, [user, products, suppliers, merchants, orders, cart]);

  const value = useMemo<MarketplaceState>(() => ({
    user,
    products,
    categories: seedCategories,
    suppliers,
    merchants,
    orders,
    cart,
    loginAs: (role, status = role === "guest" ? "pending" : "approved") => {
      const names: Record<Role, string> = {
        guest: "Visitor",
        merchant: status === "approved" ? "Lina Beauty Store" : "Pending Merchant",
        supplier: status === "approved" ? "Amman Beauty Distribution" : "Pending Supplier",
        admin: "Platform Admin"
      };
      setUser({ role, status, name: names[role] });
    },
    addProduct: (product) => {
      setProducts((current) => [
        {
          ...product,
          id: `p-${Date.now()}`,
          supplierId: "s-1",
          supplierName: "Amman Beauty Distribution",
          active: true
        },
        ...current
      ]);
    },
    updateProduct: (product) => setProducts((current) => current.map((item) => (item.id === product.id ? product : item))),
    removeProduct: (id) => setProducts((current) => current.filter((product) => product.id !== id)),
    addToCart: (productId, quantity) => {
      const product = products.find((item) => item.id === productId);
      if (!product) return "Product not found.";
      if (quantity < product.minimumOrderQuantity) return `Minimum order quantity is ${product.minimumOrderQuantity}.`;
      if (quantity > product.availableQuantity) return "Quantity exceeds available stock.";
      setCart((current) => {
        const existing = current.find((line) => line.productId === productId);
        if (existing) return current.map((line) => (line.productId === productId ? { ...line, quantity } : line));
        return [...current, { productId, quantity }];
      });
      return null;
    },
    updateCart: (productId, quantity) => {
      const product = products.find((item) => item.id === productId);
      if (!product) return "Product not found.";
      if (quantity < product.minimumOrderQuantity) return `Minimum order quantity is ${product.minimumOrderQuantity}.`;
      if (quantity > product.availableQuantity) return "Quantity exceeds available stock.";
      setCart((current) => current.map((line) => (line.productId === productId ? { ...line, quantity } : line)));
      return null;
    },
    removeFromCart: (productId) => setCart((current) => current.filter((line) => line.productId !== productId)),
    submitOrder: () => {
      if (!cart.length) return "Cart is empty.";
      const groupedBySupplier = cart.reduce<Record<string, CartLine[]>>((groups, line) => {
        const product = products.find((item) => item.id === line.productId);
        if (!product) return groups;
        groups[product.supplierId] = [...(groups[product.supplierId] ?? []), line];
        return groups;
      }, {});
      const newOrders = Object.entries(groupedBySupplier).map(([supplierId, lines]) => {
        const supplier = suppliers.find((item) => item.id === supplierId);
        const items = lines.map((line) => {
          const product = products.find((item) => item.id === line.productId)!;
          return { productId: product.id, productName: product.nameEn, quantity: line.quantity, unitPrice: product.wholesalePrice };
        });
        return {
          id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
          merchantId: "m-1",
          merchantName: "Lina Beauty Store",
          supplierId,
          supplierName: supplier?.companyName ?? "Supplier",
          status: "pending" as OrderStatus,
          createdAt: new Date().toISOString().slice(0, 10),
          total: items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0),
          items
        };
      });
      setOrders((current) => [...newOrders, ...current]);
      setCart([]);
      return null;
    },
    updateOrderStatus: (orderId, status) => setOrders((current) => current.map((order) => (order.id === orderId ? { ...order, status } : order))),
    updateApplication: (kind, id, status) => {
      if (kind === "merchant") setMerchants((current) => current.map((item) => (item.id === id ? { ...item, status } : item)));
      if (kind === "supplier") setSuppliers((current) => current.map((item) => (item.id === id ? { ...item, status } : item)));
    },
    registerMerchant: (merchant) => setMerchants((current) => [{ ...merchant, id: `m-${Date.now()}`, status: "pending" }, ...current]),
    registerSupplier: (supplier) => setSuppliers((current) => [{ ...supplier, id: `s-${Date.now()}`, status: "pending" }, ...current])
  }), [cart, merchants, orders, products, suppliers, user]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useMarketplace() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useMarketplace must be used within StoreProvider");
  return context;
}
