import { hasSupabaseEnv, supabase } from "@/lib/supabase/client";
import { VerificationDocument } from "@/lib/types";

type ApplicationKind = "merchant" | "supplier";

const DOCUMENT_BUCKET = "verification-documents";

export function formatFileSize(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export function isImageDocument(document: VerificationDocument) {
  return document.fileType.startsWith("image/");
}

export function storageObjectUrl(storagePath?: string) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!supabaseUrl || !storagePath) return undefined;
  return `${supabaseUrl}/storage/v1/object/authenticated/${DOCUMENT_BUCKET}/${storagePath}`;
}

export async function createVerificationDocument(file: File, label: string, applicationKind: ApplicationKind): Promise<VerificationDocument> {
  const id = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const previewUrl = await readFileAsDataUrl(file);
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
  let storagePath: string | undefined;

  if (hasSupabaseEnv && supabase) {
    const { data } = await supabase.auth.getUser();
    const ownerId = data.user?.id ?? "pending-user";
    const candidatePath = `${applicationKind}/${ownerId}/${id}-${safeName}`;
    const { error } = await supabase.storage.from(DOCUMENT_BUCKET).upload(candidatePath, file, {
      cacheControl: "3600",
      contentType: file.type || "application/octet-stream",
      upsert: true
    });

    if (!error) storagePath = candidatePath;
  }

  return {
    id,
    label,
    fileName: file.name,
    fileType: file.type || "application/octet-stream",
    size: file.size,
    uploadedAt: new Date().toISOString(),
    previewUrl,
    storagePath
  };
}

function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
