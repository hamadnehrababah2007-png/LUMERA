"use client";

import Link from "next/link";
import { useState } from "react";
import {
  ArrowRight,
  BarChart3,
  Box,
  CheckCircle2,
  Globe2,
  Package,
  PlayCircle,
  ShoppingCart,
  X
} from "lucide-react";
import { AveniqBrand } from "@/components/brand";

const supplierBenefits = ["List unlimited products", "Manage orders easily", "Grow your distribution network", "Get paid securely"];
const merchantBenefits = ["Access verified suppliers", "Order with ease", "Track orders in real-time", "Secure payments and invoices"];

export default function JoinPage() {
  const [phase, setPhase] = useState<"intro" | "selection">("intro");
  const [hovered, setHovered] = useState<"supplier" | "merchant" | null>(null);

  return (
    <main className="join-experience min-h-screen overflow-hidden bg-[#050610] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(124,58,237,0.18),transparent_30rem),linear-gradient(180deg,#050610,#09091a_48%,#050610)]" />

      <section className={phase === "intro" ? "join-panel join-panel-active" : "join-panel join-panel-exit"}>
        <div className="vortex-wrap" aria-hidden="true">
          <div className="vortex-image-stage">
            <div className="vortex-image" />
          </div>
          <div className="vortex-subtle-particles" />
          <div className="vortex-core" />
        </div>

        <div className="relative z-10 flex min-h-screen items-center justify-center px-4">
          <div className="animate-rise max-w-xl text-center">
            <AveniqBrand className="justify-center [&_span:first-child]:size-16 [&_span:last-child_span]:text-3xl [&_span:last-child_span]:text-white" />
            <h1 className="mt-10 text-5xl font-semibold tracking-[-0.03em] sm:text-6xl">Join Aveniq</h1>
            <p className="mx-auto mt-5 max-w-md text-base leading-7 text-white/62">
              Choose how you&apos;d like to connect with the future of commerce.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <button
                type="button"
                className="group inline-flex min-h-12 items-center rounded-2xl bg-violet-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_20px_80px_rgba(124,58,237,0.45)] transition duration-300 hover:-translate-y-1 hover:bg-violet-500"
                onClick={() => setPhase("selection")}
              >
                Join Aveniq <ArrowRight className="ml-3 size-4 transition group-hover:translate-x-0.5" />
              </button>
              <Link
                href="/products"
                className="inline-flex min-h-12 items-center rounded-2xl border border-white/12 bg-white/[0.055] px-6 py-3 text-sm font-semibold text-white shadow-2xl backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:bg-white/[0.09]"
              >
                Watch Demo <PlayCircle className="ml-3 size-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={phase === "selection" ? "join-panel join-panel-active" : "join-panel join-panel-hidden"}>
        <div className="relative z-10 min-h-screen p-4 sm:p-6">
          <div className="relative min-h-[calc(100vh-2rem)] overflow-hidden rounded-[2rem] border border-white/14 bg-white/[0.035] shadow-[0_30px_120px_rgba(0,0,0,0.55)] backdrop-blur-xl sm:min-h-[calc(100vh-3rem)]">
            <div className="absolute left-6 top-6 z-20">
              <AveniqBrand className="[&_span:first-child]:size-9 [&_span:last-child_span]:text-white" />
            </div>
            <button
              type="button"
              aria-label="Back to join intro"
              className="absolute right-6 top-6 z-20 grid size-10 place-items-center rounded-xl border border-white/12 bg-white/[0.05] text-white/80 transition hover:bg-white/[0.1]"
              onClick={() => setPhase("intro")}
            >
              <X className="size-4" />
            </button>

            <div className="grid min-h-[calc(100vh-2rem)] sm:min-h-[calc(100vh-3rem)] lg:grid-cols-2">
              <AccessSide
                kind="supplier"
                eyebrow="For Suppliers and Distributors"
                title="Supplier Access"
                text="Grow your business by reaching thousands of verified retailers."
                benefits={supplierBenefits}
                href="/register/supplier"
                cta="Join as Supplier"
                active={hovered === "supplier"}
                dimmed={hovered === "merchant"}
                onHover={() => setHovered("supplier")}
                onLeave={() => setHovered(null)}
              />
              <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 hidden size-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-white/14 bg-[#0d0f1d]/90 text-xl font-semibold text-white shadow-2xl lg:grid">
                or
              </div>
              <AccessSide
                kind="merchant"
                eyebrow="For Retailers and Merchants"
                title="Merchant Access"
                text="Source the best products from trusted suppliers in one place."
                benefits={merchantBenefits}
                href="/register/merchant"
                cta="Join as Merchant"
                active={hovered === "merchant"}
                dimmed={hovered === "supplier"}
                onHover={() => setHovered("merchant")}
                onLeave={() => setHovered(null)}
              />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function AccessSide({
  kind,
  eyebrow,
  title,
  text,
  benefits,
  href,
  cta,
  active,
  dimmed,
  onHover,
  onLeave
}: {
  kind: "supplier" | "merchant";
  eyebrow: string;
  title: string;
  text: string;
  benefits: string[];
  href: string;
  cta: string;
  active: boolean;
  dimmed: boolean;
  onHover: () => void;
  onLeave: () => void;
}) {
  const purple = kind === "supplier";

  return (
    <div
      className={[
        "group relative flex min-h-[50vh] items-center overflow-hidden px-8 py-24 transition duration-500 sm:px-14 lg:min-h-full lg:px-16",
        purple ? "bg-[radial-gradient(circle_at_65%_50%,rgba(124,58,237,0.28),transparent_34rem),#090817]" : "bg-[radial-gradient(circle_at_72%_50%,rgba(14,165,233,0.24),transparent_34rem),#06101d]",
        active ? "scale-[1.015] brightness-110" : "",
        dimmed ? "brightness-75" : ""
      ].join(" ")}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.035)_1px,transparent_1px)] bg-[size:48px_48px]" />
      {purple ? <SupplierVisual /> : <MerchantVisual />}

      <div className="relative z-10 max-w-md">
        <p className={purple ? "inline-flex rounded-full border border-violet-300/20 bg-violet-400/10 px-4 py-2 text-sm font-medium text-violet-200" : "inline-flex rounded-full border border-sky-300/20 bg-sky-400/10 px-4 py-2 text-sm font-medium text-sky-200"}>
          {eyebrow}
        </p>
        <h2 className={purple ? "mt-6 text-4xl font-semibold tracking-[-0.03em] text-violet-300 sm:text-5xl" : "mt-6 text-4xl font-semibold tracking-[-0.03em] text-sky-300 sm:text-5xl"}>
          {title}
        </h2>
        <p className="mt-5 text-lg leading-8 text-white/66">{text}</p>
        <ul className="mt-8 space-y-4">
          {benefits.map((benefit) => (
            <li key={benefit} className="flex items-center gap-3 text-sm text-white/74">
              <CheckCircle2 className={purple ? "size-5 text-violet-300" : "size-5 text-sky-300"} />
              {benefit}
            </li>
          ))}
        </ul>
        <Link
          href={href}
          className={purple ? "mt-9 inline-flex min-h-12 items-center rounded-2xl bg-violet-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_20px_80px_rgba(124,58,237,0.42)] transition duration-300 group-hover:-translate-y-1 group-hover:bg-violet-500" : "mt-9 inline-flex min-h-12 items-center rounded-2xl bg-sky-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_20px_80px_rgba(14,165,233,0.35)] transition duration-300 group-hover:-translate-y-1 group-hover:bg-sky-500"}
        >
          {cta} <ArrowRight className="ml-3 size-4" />
        </Link>
      </div>
    </div>
  );
}

function SupplierVisual() {
  return (
    <div className="pointer-events-none absolute inset-y-0 right-0 hidden w-[58%] items-center justify-center lg:flex">
      <div className="network-globe">
        <Globe2 className="size-40 text-violet-300/35" />
        <span className="node node-one" />
        <span className="node node-two" />
        <span className="node node-three" />
      </div>
      <div className="shipment shipment-one"><Package className="size-7" /></div>
      <div className="shipment shipment-two"><Box className="size-8" /></div>
      <div className="holo-card supplier-card-one">New Order<br /><b>JOD 1,250</b></div>
      <div className="holo-card supplier-card-two">Payment Received<br /><b>JOD 3,450</b></div>
    </div>
  );
}

function MerchantVisual() {
  return (
    <div className="pointer-events-none absolute inset-y-0 right-0 hidden w-[58%] items-center justify-center lg:flex">
      <div className="cart-platform">
        <ShoppingCart className="size-32 text-sky-300/50" />
      </div>
      <div className="product-holo product-one">Hair Serum<br /><b>JOD 4.50</b></div>
      <div className="product-holo product-two">Moisturizer<br /><b>JOD 3.25</b></div>
      <div className="product-holo product-three">
        <BarChart3 className="mb-2 size-5 text-sky-200" />
        Demand +18%
      </div>
      <div className="merchant-orbit" />
    </div>
  );
}
