import { LandingV2 } from "@/components/landing-v2";

export default function Home() {
  return <LandingV2 />;
}
