import { hasSupabaseEnv, supabase } from "@/lib/supabase/client";
import { Product } from "@/lib/types";

const PRODUCT_IMAGE_BUCKET = "product-images";
const fallbackProductImage = "https://images.unsplash.com/photo-1596462502278-27bfdc403348?q=80&w=1200&auto=format&fit=crop";
const LOCAL_IMAGE_PREFIX = "aveniq-local-image:";
const LOCAL_DB_NAME = "aveniq-product-images";
const LOCAL_STORE_NAME = "images";
const objectUrlCache = new Map<string, string>();

export type ProductImageAsset = {
  id: string;
  name: string;
  previewUrl: string;
  url: string;
  storagePath?: string;
};

export function getProductImages(product: Pick<Product, "imageUrl" | "images">) {
  const images = [product.images ?? [], product.imageUrl ? [product.imageUrl] : []]
    .flat()
    .filter(Boolean);
  return Array.from(new Set(images.length ? images : [fallbackProductImage]));
}

export function getProductImage(product: Pick<Product, "imageUrl" | "images">) {
  return getProductImages(product)[0];
}

export function sanitizeProductImages(product: Product): Product {
  const safeImages = getProductImages(product).filter((url) => !isTemporaryImageUrl(url));
  const images = safeImages.length ? safeImages : [fallbackProductImage];
  return { ...product, imageUrl: images[0], images };
}

export async function createProductImageAsset(file: File): Promise<ProductImageAsset> {
  const id = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const previewUrl = URL.createObjectURL(file);
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
  let storagePath: string | undefined;
  let url = previewUrl;

  if (hasSupabaseEnv && supabase) {
    const { data } = await supabase.auth.getUser();
    const ownerId = data.user?.id ?? "pending-supplier";
    const candidatePath = `${ownerId}/${id}-${safeName}`;
    const { error } = await supabase.storage.from(PRODUCT_IMAGE_BUCKET).upload(candidatePath, file, {
      cacheControl: "3600",
      contentType: file.type || "image/jpeg",
      upsert: true
    });

    if (!error) {
      storagePath = candidatePath;
      const { data: publicUrl } = supabase.storage.from(PRODUCT_IMAGE_BUCKET).getPublicUrl(candidatePath);
      url = publicUrl.publicUrl;
    }
  } else {
    const localId = `${id}-${safeName}`;
    try {
      await storeLocalImage(localId, file);
      url = `${LOCAL_IMAGE_PREFIX}${localId}`;
    } catch {
      url = previewUrl;
    }
  }

  return { id, name: file.name, previewUrl, url, storagePath };
}

export function isLocalProductImage(url: string) {
  return url.startsWith(LOCAL_IMAGE_PREFIX);
}

export async function resolveProductImageUrl(url: string) {
  if (!isLocalProductImage(url)) return url;
  const cached = objectUrlCache.get(url);
  if (cached) return cached;
  const blob = await getLocalImage(url.slice(LOCAL_IMAGE_PREFIX.length));
  if (!blob) return fallbackProductImage;
  const objectUrl = URL.createObjectURL(blob);
  objectUrlCache.set(url, objectUrl);
  return objectUrl;
}

function isTemporaryImageUrl(url: string) {
  return url.startsWith("blob:") || url.startsWith("data:");
}

function openLocalImageDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(LOCAL_DB_NAME, 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(LOCAL_STORE_NAME);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function storeLocalImage(id: string, file: File) {
  if (typeof indexedDB === "undefined") throw new Error("Local image storage is unavailable.");
  const db = await openLocalImageDb();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(LOCAL_STORE_NAME, "readwrite");
    transaction.objectStore(LOCAL_STORE_NAME).put(file, id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  db.close();
}

async function getLocalImage(id: string) {
  if (typeof indexedDB === "undefined") return null;
  const db = await openLocalImageDb();
  const blob = await new Promise<Blob | null>((resolve, reject) => {
    const transaction = db.transaction(LOCAL_STORE_NAME, "readonly");
    const request = transaction.objectStore(LOCAL_STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error);
  });
  db.close();
  return blob;
}
