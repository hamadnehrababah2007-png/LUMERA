"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ClipboardList, Moon, PackageSearch, ShieldCheck, ShoppingCart, Store, Sun, UserRoundCheck } from "lucide-react";
import { useMarketplace } from "@/lib/store";
import { cn, statusLabel } from "@/lib/utils";
import { AveniqBrand } from "@/components/brand";
import { useTheme } from "@/lib/theme";

const links = [
  { href: "/products", label: "Products", icon: PackageSearch },
  { href: "/cart", label: "Cart", icon: ShoppingCart },
  { href: "/orders", label: "Orders", icon: ClipboardList },
  { href: "/supplier", label: "Supplier", icon: Store },
  { href: "/admin", label: "Admin", icon: ShieldCheck }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, cart, loginAs } = useMarketplace();
  const { theme, toggleTheme } = useTheme();
  const immersiveRoute = pathname === "/join";

  if (immersiveRoute) {
    return <main>{children}</main>;
  }

  return (
    <div className="premium-shell min-h-screen">
      <header className="sticky top-0 z-40 border-b border-line/70 bg-panel/72 shadow-sm backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link href="/" className="flex items-center">
            <AveniqBrand />
          </Link>
          <nav className="flex max-w-full gap-2 overflow-x-auto rounded-2xl border border-line/70 bg-panel/62 p-1.5 shadow-sm">
            {links.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className={cn(
                  "flex min-h-11 items-center gap-2 rounded-xl px-4 text-sm font-medium text-ink/70 transition duration-200 hover:-translate-y-0.5 hover:bg-mint hover:text-ink",
                  pathname === href && "bg-ink text-porcelain shadow-sm hover:bg-ink hover:text-porcelain"
                )}
              >
                <Icon className="size-4" />
                <span>{label}</span>
                {href === "/cart" && cart.length > 0 ? (
                  <span className="rounded bg-rose px-1.5 text-xs text-white">{cart.length}</span>
                ) : null}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <div className="hidden rounded-2xl border border-line/70 bg-panel/70 px-3.5 py-2.5 text-xs shadow-sm sm:block">
              <span className="font-semibold">{user.name}</span>
              <span className="ml-2 text-ink/55">{statusLabel(user.role)} - {statusLabel(user.status)}</span>
            </div>
            <select
              aria-label="Demo role"
              className="focus-ring rounded-2xl border border-line/70 bg-panel/90 px-3.5 py-2.5 text-sm text-ink shadow-sm"
              value={`${user.role}:${user.status}`}
              onChange={(event) => {
                const [role, status] = event.target.value.split(":");
                loginAs(role as Parameters<typeof loginAs>[0], status as Parameters<typeof loginAs>[1]);
              }}
            >
              <option value="guest:pending">Guest preview</option>
              <option value="merchant:pending">Pending merchant</option>
              <option value="merchant:approved">Approved merchant</option>
              <option value="supplier:approved">Supplier</option>
              <option value="admin:approved">Admin</option>
            </select>
            <button
              type="button"
              aria-label="Toggle theme"
              className="focus-ring grid size-11 place-items-center rounded-2xl border border-line/70 bg-panel/90 text-ink shadow-sm transition duration-200 hover:-translate-y-0.5 hover:bg-mint"
              onClick={toggleTheme}
            >
              {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </button>
            <Link href="/register/merchant" className="focus-ring hidden min-h-11 items-center rounded-2xl bg-rose px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition duration-200 hover:-translate-y-0.5 hover:bg-moss sm:inline-flex">
              <UserRoundCheck className="mr-2 size-4" /> Request Access
            </Link>
          </div>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}

