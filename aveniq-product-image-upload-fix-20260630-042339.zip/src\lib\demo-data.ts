import { Category, Merchant, Order, Product, Supplier } from "@/lib/types";

export const categories: Category[] = [
  { id: "skincare", nameEn: "Skincare", nameAr: "العناية بالبشرة" },
  { id: "haircare", nameEn: "Haircare", nameAr: "العناية بالشعر" },
  { id: "makeup", nameEn: "Makeup", nameAr: "مكياج" },
  { id: "fragrances", nameEn: "Fragrances", nameAr: "عطور" },
  { id: "tools", nameEn: "Beauty Tools", nameAr: "أدوات تجميل" }
];

export const suppliers: Supplier[] = [
  { id: "s-1", companyName: "Amman Beauty Distribution", phone: "+962 79 100 2200", documents: [], status: "approved" },
  { id: "s-2", companyName: "Levant Supply Network", phone: "+962 78 400 1188", documents: [], status: "pending" }
];

export const merchants: Merchant[] = [
  {
    id: "m-1",
    storeName: "Lina Beauty Store",
    ownerName: "Lina Haddad",
    phone: "+962 79 555 1010",
    city: "Amman",
    area: "Sweifieh",
    instagram: "@linabeautyjo",
    documents: [],
    status: "approved"
  },
  {
    id: "m-2",
    storeName: "Irbid Glow",
    ownerName: "Maya Saleh",
    phone: "+962 77 200 9090",
    city: "Irbid",
    area: "University Street",
    documents: [],
    status: "pending"
  }
];

export const products: Product[] = [
  {
    id: "p-1",
    supplierId: "s-1",
    supplierName: "Amman Beauty Distribution",
    categoryId: "skincare",
    nameEn: "Hydrating Vitamin C Serum",
    nameAr: "سيروم فيتامين سي مرطب",
    brand: "DermaGlow",
    imageUrl: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1612817288484-6f916006741a?q=80&w=1200&auto=format&fit=crop"
    ],
    wholesalePrice: 4.75,
    availableQuantity: 420,
    minimumOrderQuantity: 24,
    deliveryEta: "24 Hours",
    coverageAreas: ["Amman", "Zarqa", "Irbid"],
    active: true
  },
  {
    id: "p-2",
    supplierId: "s-1",
    supplierName: "Amman Beauty Distribution",
    categoryId: "makeup",
    nameEn: "Matte Liquid Lipstick Set",
    nameAr: "مجموعة أحمر شفاه مطفي",
    brand: "ColorHaus",
    imageUrl: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?q=80&w=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1586495777744-4413f21062fa?q=80&w=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?q=80&w=1200&auto=format&fit=crop"
    ],
    wholesalePrice: 2.2,
    availableQuantity: 900,
    minimumOrderQuantity: 48,
    deliveryEta: "Same Day",
    coverageAreas: ["Amman"],
    active: true
  },
  {
    id: "p-3",
    supplierId: "s-1",
    supplierName: "Amman Beauty Distribution",
    categoryId: "haircare",
    nameEn: "Argan Repair Hair Mask",
    nameAr: "ماسك الأرغان لإصلاح الشعر",
    brand: "Nourish Lab",
    imageUrl: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop",
    images: ["https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop"],
    wholesalePrice: 3.6,
    availableQuantity: 150,
    minimumOrderQuantity: 18,
    deliveryEta: "48 Hours",
    coverageAreas: ["Amman", "Irbid", "Other cities"],
    active: true
  },
  {
    id: "p-4",
    supplierId: "s-1",
    supplierName: "Amman Beauty Distribution",
    categoryId: "fragrances",
    nameEn: "Amber Rose Body Mist",
    nameAr: "بخاخ جسم عنبر ورد",
    brand: "Scent Yard",
    imageUrl: "https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=1200&auto=format&fit=crop",
    images: ["https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=1200&auto=format&fit=crop"],
    wholesalePrice: 3.1,
    availableQuantity: 260,
    minimumOrderQuantity: 30,
    deliveryEta: "Custom ETA",
    coverageAreas: ["Amman", "Zarqa"],
    active: true
  }
];

export const orders: Order[] = [
  {
    id: "ORD-1008",
    merchantId: "m-1",
    merchantName: "Lina Beauty Store",
    supplierId: "s-1",
    supplierName: "Amman Beauty Distribution",
    status: "pending",
    createdAt: "2026-06-27",
    total: 219,
    items: [
      { productId: "p-1", productName: "Hydrating Vitamin C Serum", quantity: 24, unitPrice: 4.75 },
      { productId: "p-2", productName: "Matte Liquid Lipstick Set", quantity: 48, unitPrice: 2.2 }
    ]
  }
];
