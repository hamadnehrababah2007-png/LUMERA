import { cn } from "@/lib/utils";

export function PageHeader({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: React.ReactNode }) {
  return (
    <section className="border-b border-line/80 bg-panel/82 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        {eyebrow ? <p className="mb-2 text-sm font-semibold uppercase tracking-[0.18em] text-rose">{eyebrow}</p> : null}
        <h1 className="max-w-4xl text-3xl font-semibold tracking-normal text-ink sm:text-5xl">{title}</h1>
        {children ? <div className="mt-4 max-w-3xl text-base leading-7 text-ink/70">{children}</div> : null}
      </div>
    </section>
  );
}

export function Badge({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "good" | "warn" | "bad" }) {
  return (
    <span
      className={cn(
        "inline-flex rounded px-2 py-1 text-xs font-semibold",
        tone === "neutral" && "bg-mint text-ink",
        tone === "good" && "bg-emerald-100 text-emerald-800",
        tone === "warn" && "bg-apricot/30 text-amber-900",
        tone === "bad" && "bg-rose/15 text-rose"
      )}
    >
      {children}
    </span>
  );
}

export function EmptyState({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-line bg-panel/86 p-8 text-center shadow-sm backdrop-blur">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mt-2 text-sm leading-6 text-ink/65">{children}</p>
    </div>
  );
}

export const inputClass = "focus-ring w-full rounded-xl border border-line bg-panel px-3 py-2 text-sm text-ink shadow-sm transition placeholder:text-ink/35";
export const buttonClass = "focus-ring inline-flex min-h-11 items-center justify-center rounded-2xl bg-rose px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition duration-200 hover:-translate-y-0.5 hover:bg-moss";
export const secondaryButtonClass = "focus-ring inline-flex min-h-11 items-center justify-center rounded-2xl border border-line bg-panel/88 px-5 py-2.5 text-sm font-semibold text-ink shadow-sm transition duration-200 hover:-translate-y-0.5 hover:bg-mint";
