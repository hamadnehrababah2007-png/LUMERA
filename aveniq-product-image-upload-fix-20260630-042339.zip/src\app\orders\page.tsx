"use client";

import { EmptyState, PageHeader, Badge } from "@/components/ui";
import { useMarketplace } from "@/lib/store";
import { money, statusLabel } from "@/lib/utils";

export default function OrdersPage() {
  const { orders, user } = useMarketplace();
  const visibleOrders = user.role === "supplier" ? orders.filter((order) => order.supplierId === "s-1") : orders;

  return (
    <>
      <PageHeader eyebrow="Orders" title="Track wholesale orders from pending through delivery." />
      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        {visibleOrders.length === 0 ? (
          <EmptyState title="No orders yet">Submitted orders will appear here with supplier and delivery status.</EmptyState>
        ) : (
          <div className="space-y-4">
            {visibleOrders.map((order) => (
              <article key={order.id} className="rounded-2xl border border-line bg-panel/88 p-5 shadow-sm backdrop-blur">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h2 className="text-xl font-bold">{order.id}</h2>
                    <p className="text-sm text-ink/60">{order.merchantName} → {order.supplierName} · {order.createdAt}</p>
                  </div>
                  <Badge tone={order.status === "rejected" ? "bad" : order.status === "delivered" ? "good" : "warn"}>{statusLabel(order.status)}</Badge>
                </div>
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full min-w-[560px] text-left text-sm">
                    <thead className="border-b border-line text-ink/50">
                      <tr><th className="py-2">Product</th><th>Qty</th><th>Unit</th><th className="text-right">Line total</th></tr>
                    </thead>
                    <tbody>
                      {order.items.map((item) => (
                        <tr key={item.productId} className="border-b border-line/60">
                          <td className="py-3 font-medium">{item.productName}</td>
                          <td>{item.quantity}</td>
                          <td>{money(item.unitPrice)}</td>
                          <td className="text-right font-semibold">{money(item.quantity * item.unitPrice)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="mt-4 text-right text-lg font-bold">{money(order.total)}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
